import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import dotenv from 'dotenv';
import { InterviewController } from './src/server/interviewController';
import { CandidateService } from './src/server/candidateService';
import { CurriculumService } from './src/server/curriculumService';
import { interviewStateManager } from './src/server/interviewState';

dotenv.config();

function apiServerPlugin(): Plugin {
  return {
    name: 'interview-api-server',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url?.startsWith('/api/')) {
          return next();
        }

        // Set common JSON headers
        res.setHeader('Content-Type', 'application/json');

        if (req.url === '/api/health' && req.method === 'GET') {
          res.statusCode = 200;
          res.end(JSON.stringify({ status: 'ok', time: new Date().toISOString() }));
          return;
        }

        if (req.url === '/api/candidates' && req.method === 'GET') {
          res.statusCode = 200;
          res.end(JSON.stringify(CandidateService.getAllCandidates()));
          return;
        }

        if (req.url === '/api/curriculum' && req.method === 'GET') {
          res.statusCode = 200;
          res.end(JSON.stringify(CurriculumService.getCurriculum()));
          return;
        }

        if (req.url === '/api/sessions' && req.method === 'GET') {
          res.statusCode = 200;
          res.end(JSON.stringify(interviewStateManager.getAllSessions()));
          return;
        }

        if (req.url?.startsWith('/api/session/') && req.method === 'GET') {
          const sessionId = req.url.replace('/api/session/', '').split('?')[0];
          const session = interviewStateManager.getSession(sessionId);
          if (!session) {
            res.statusCode = 404;
            res.end(JSON.stringify({ error: 'Session not found' }));
            return;
          }
          res.statusCode = 200;
          res.end(JSON.stringify(session));
          return;
        }

        // Primary Technical Specification Endpoint: POST /api/interview
        if (req.url === '/api/interview' && req.method === 'POST') {
          let bodyStr = '';
          req.on('data', (chunk) => {
            bodyStr += chunk;
          });
          req.on('end', async () => {
            try {
              const parsedBody = bodyStr ? JSON.parse(bodyStr) : {};
              const result = await InterviewController.handleInterview(parsedBody);
              res.statusCode = result.status;
              res.end(JSON.stringify(result.data));
            } catch (err: any) {
              console.error('Error in POST /api/interview:', err);
              res.statusCode = 500;
              res.end(JSON.stringify({ error: err?.message || 'Server error' }));
            }
          });
          return;
        }

        res.statusCode = 404;
        res.end(JSON.stringify({ error: 'API route not found' }));
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), apiServerPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
