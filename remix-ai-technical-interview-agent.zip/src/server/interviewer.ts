import {
  CandidateProfile,
  DifficultyLevel,
  InterviewSessionState,
  QuestionType,
  AnswerEvaluation,
} from './types';
import { CurriculumService } from './curriculumService';
import { CandidateService } from './candidateService';
import { generateContentWithGemini } from './geminiClient';

interface GeneratedQuestion {
  question: string;
  day: number;
  topic: string;
  questionType: QuestionType;
  difficulty: DifficultyLevel;
  isFollowUp: boolean;
}

export class InterviewerService {
  /**
   * Generates the initial welcome greeting and first technical warm-up question
   */
  public static async generateOpening(
    candidate: CandidateProfile
  ): Promise<{ greeting: string; question: string; day: number; topic: string }> {
    const insight = CandidateService.analyzeCandidate(candidate);

    // Pick first topic from completed days
    const startingDayNumber = insight.recommendedOpeningTopics[0] || 7;
    const dayData = CurriculumService.getDay(startingDayNumber) || {
      day: 7,
      title: 'Embeddings Explained',
      tools: ['Sentence Transformers', 'OpenAI Embeddings'],
      objectives: ['Understand how text is converted into vector embeddings'],
      type: 'AI_CORE',
    };

    const candidateRole = candidate.member.jobRole;
    const candidateName = candidate.member.name;

    const openingQuestion = `Welcome ${candidateName}. Let's begin your technical interview. Looking at your cohort journey and background as a ${candidateRole}, let's start with Day ${dayData.day} (${dayData.title}). Could you explain how you converted your unstructured healthcare dataset into vector embeddings, and what distance metric you selected for semantic similarity search?`;

    return {
      greeting: `Welcome, ${candidateName}. We are ready to begin your technical interview.`,
      question: openingQuestion,
      day: dayData.day,
      topic: dayData.title,
    };
  }

  /**
   * Generates the next question adaptively based on candidate progress,
   * previous evaluation, curriculum coverage, and difficulty.
   */
  public static async generateNextQuestion(
    session: InterviewSessionState
  ): Promise<GeneratedQuestion> {
    const latestEval = session.answerEvaluations[session.answerEvaluations.length - 1];
    const candidateInsight = CandidateService.analyzeCandidate(session.candidate);

    // Track how many questions and days covered so far
    const questionsAsked = session.questionCount;
    const daysCovered = session.curriculumDaysCovered;
    const currentDifficulty = session.difficulty;

    // Check if we should ask an intelligent follow-up
    // Follow up when:
    // 1) Latest answer was partial/had missing concepts or was very strong and warrants a deeper trade-off probe
    // 2) We haven't done consecutive follow-ups without expanding curriculum days
    const shouldFollowUp =
      latestEval &&
      !session.isCurrentFollowUp &&
      (latestEval.followUpNeeded || latestEval.score >= 8.5 || latestEval.score <= 4.5);

    if (shouldFollowUp && latestEval) {
      const followUp = await this.generateFollowUpQuestion(
        session,
        latestEval,
        currentDifficulty
      );
      if (followUp) {
        return followUp;
      }
    }

    // Otherwise, plan next curriculum topic to ensure at least 4 distinct days
    const targetDayNumber = this.selectNextCurriculumDay(session, candidateInsight);
    const dayData = CurriculumService.getDay(targetDayNumber)!;

    // Determine question type based on interview phase & performance
    const questionType = this.selectQuestionType(session, questionsAsked, currentDifficulty);

    // Generate question via Gemini or specialized deterministic engine
    const questionText = await this.craftQuestion(
      session,
      dayData.day,
      dayData.title,
      dayData.objectives,
      dayData.tools,
      questionType,
      currentDifficulty
    );

    return {
      question: questionText,
      day: dayData.day,
      topic: dayData.title,
      questionType,
      difficulty: currentDifficulty,
      isFollowUp: false,
    };
  }

  private static selectNextCurriculumDay(
    session: InterviewSessionState,
    candidateInsight: any
  ): number {
    const covered = new Set(session.curriculumDaysCovered);
    const coreDays = [7, 10, 12, 13, 16, 21, 22, 23, 28, 29, 31];

    // 1. Prefer candidate completed days that haven't been covered yet
    for (const day of candidateInsight.completedDays) {
      if (!covered.has(day) && coreDays.includes(day)) {
        return day;
      }
    }

    // 2. Try any candidate completed day
    for (const day of candidateInsight.completedDays) {
      if (!covered.has(day)) {
        return day;
      }
    }

    // 3. Try standard core days
    for (const day of coreDays) {
      if (!covered.has(day)) {
        return day;
      }
    }

    // If all core days covered, select a high-impact synthesis day (Day 22 Multi-agent, Day 23 MCP, Day 31 Capstone)
    const synthesisDays = [22, 23, 28, 31, 10, 12];
    for (const day of synthesisDays) {
      if (day !== session.currentDay) {
        return day;
      }
    }

    return 31;
  }

  private static selectQuestionType(
    session: InterviewSessionState,
    questionCount: number,
    difficulty: DifficultyLevel
  ): QuestionType {
    if (questionCount <= 1) return 'conceptual';
    if (questionCount <= 3) return difficulty === 'hard' ? 'debugging' : 'explanation';
    if (questionCount <= 5) return difficulty === 'hard' ? 'design' : 'scenario';
    if (questionCount <= 7) return 'trade-off';
    return 'production';
  }

  private static async generateFollowUpQuestion(
    session: InterviewSessionState,
    evalResult: AnswerEvaluation,
    difficulty: DifficultyLevel
  ): Promise<GeneratedQuestion | null> {
    const topic = evalResult.topic;
    const day = evalResult.curriculumDay;

    // If Gemini is configured, prompt it for contextual follow-up
    const prompt = `You are a Principal AI Technical Interviewer.
The candidate just answered a question about Day ${day} (${topic}).
Candidate's answer: "${evalResult.answer}"
Your evaluation score: ${evalResult.score}/10
Missing concepts: ${JSON.stringify(evalResult.missingConcepts)}
Misconceptions: ${JSON.stringify(evalResult.misconceptions)}
Current difficulty: ${difficulty}

Generate ONE concise, sharp follow-up question that directly tests either:
1. The missing concept if they were incomplete
2. A deeper trade-off/edge case if they were strong
3. A simpler diagnostic probe if they gave an incorrect answer

Return ONLY the single question text.`;

    const systemPrompt = 'You are an expert AI engineering interviewer. Be concise, direct, and professional.';
    const geminiQuestion = await generateContentWithGemini(prompt, systemPrompt, 0.4);

    let questionText = geminiQuestion;
    if (!questionText) {
      // Deterministic intelligent follow-up logic
      if (evalResult.score >= 8.0) {
        questionText = `That's a solid explanation of ${topic}. Now suppose your production system experiences 10x query traffic and retrieval latency spikes by 400ms. Where in your pipeline would you look first to optimize performance and caching?`;
      } else if (evalResult.score >= 5.0 && evalResult.missingConcepts.length > 0) {
        questionText = `You covered the core ideas of ${topic}. How specifically did you address ${evalResult.missingConcepts[0]} during your cohort project, and what trade-offs were involved?`;
      } else {
        questionText = `Let's clarify one fundamental aspect of ${topic}: can you walk me through the step-by-step data flow from the raw input to the final model output?`;
      }
    }

    return {
      question: questionText,
      day,
      topic,
      questionType: evalResult.score >= 8 ? 'trade-off' : 'explanation',
      difficulty,
      isFollowUp: true,
    };
  }

  private static async craftQuestion(
    session: InterviewSessionState,
    day: number,
    topic: string,
    objectives: string[],
    tools: string[],
    questionType: QuestionType,
    difficulty: DifficultyLevel
  ): Promise<string> {
    const candidate = session.candidate;
    const candidateName = candidate.member.name;
    const attempts = CandidateService.getMissionAttempts(candidate, day);

    const prompt = `You are a Principal AI Technical Interviewer conducting a realistic technical interview.
Candidate Name: ${candidateName}
Target Curriculum Day: Day ${day} - ${topic}
Day Objectives: ${JSON.stringify(objectives)}
Day Tools: ${JSON.stringify(tools)}
Question Type: ${questionType}
Difficulty: ${difficulty}
Candidate Mission Attempts on this Day: ${attempts}

Questions asked so far: ${session.questionCount}
Curriculum Days Covered so far: ${session.curriculumDaysCovered.join(', ')}

Generate ONE crisp, realistic technical question that:
1. Strictly assesses Day ${day} concepts from the curriculum.
2. Matches the question type (${questionType}) and difficulty (${difficulty}).
3. Sounds like an experienced interviewer assessing real software engineering competence.
4. Avoids pleasantries or rambling.

Return ONLY the question text.`;

    const systemPrompt = 'You are an authoritative, fair, and experienced technical interviewer.';
    const geminiQuestion = await generateContentWithGemini(prompt, systemPrompt, 0.5);

    if (geminiQuestion) {
      return geminiQuestion;
    }

    // Deterministic curated question bank grounded in curriculum.json
    return this.getCuratedQuestion(day, topic, questionType, difficulty);
  }

  public static getCuratedQuestion(
    day: number,
    topic: string,
    type: QuestionType,
    difficulty: DifficultyLevel
  ): string {
    const questionBank: Record<number, Record<string, string>> = {
      7: {
        conceptual: 'What are vector embeddings, and why do dense embeddings outperform traditional keyword matching for semantic similarity in healthcare documents?',
        explanation: 'Walk me through how you generated sentence transformer embeddings for your knowledge base chunks and how you visualized the clusters using PCA.',
        trade_off: 'What are the trade-offs between using local embedding models like Sentence Transformers versus hosted commercial embedding APIs regarding latency, cost, and privacy?',
        debugging: 'If two semantically unrelated healthcare records end up with a high cosine similarity score, what potential causes in tokenization or embedding normalizations would you investigate?',
      },
      8: {
        conceptual: 'What role does a vector database play in a RAG pipeline, and how does vector indexing differ from relational database B-tree indexing?',
        explanation: 'In your mission on Day 8, you compared ChromaDB and Pinecone. What differences did you observe between local embedded storage and cloud-managed vector databases?',
        trade_off: 'Why might you choose an embedded database like ChromaDB over a distributed vector database like Pinecone or Milvus for a prototype?',
        debugging: 'If metadata filtering in ChromaDB causes queries to return zero results despite relevant documents existing, how would you diagnose the query filter structure?',
      },
      10: {
        conceptual: 'On Day 10, you built a hybrid retrieval engine. How does combining structured SQL queries with semantic vector search improve retrieval precision for healthcare plans and claims?',
        explanation: 'Explain the complete query routing logic you implemented: how does the system decide whether a query needs SQL lookup, vector search, or both?',
        trade_off: 'What deduplication and re-ranking trade-offs did you make when merging results returned from SQLite with those from ChromaDB?',
        design: 'How would you design a retrieval engine that handles 100,000 healthcare policies with both structured claim limits and unstructured medical coverage guidelines?',
      },
      11: {
        conceptual: 'What is Retrieval-Augmented Generation (RAG), and what mechanisms prevent the LLM from hallucinating answers not grounded in retrieved context?',
        explanation: 'Explain your end-to-end RAG pipeline from user query ingestion, document retrieval, prompt augmentation, to LLM generation.',
        trade_off: 'What are the trade-offs between passing many smaller retrieved chunks versus a few large chunks to the LLM context window?',
        debugging: 'Suppose your RAG pipeline returns accurate retrieved chunks, but the generated response contradicts the context. How would you debug your prompt and temperature settings?',
      },
      12: {
        conceptual: 'On Day 12, you studied prompt engineering. What are the key differences between zero-shot, few-shot, and chain-of-thought prompting in production chatbots?',
        explanation: 'How did you structure the system prompt for your healthcare chatbot to enforce compliance, clinical tone, and refusal of out-of-domain medical queries?',
        trade_off: 'What are the latency and token cost implications of adding extensive few-shot examples into every user query prompt?',
        debugging: 'If a user attempts prompt injection to bypass healthcare advice guardrails, what specific system prompt delimiters or validation layers would you apply?',
      },
      13: {
        conceptual: 'How does LLM function calling work under the hood, and how do Pydantic schemas enforce type safety on structured model outputs?',
        explanation: 'Describe a specific tool schema you defined for the healthcare chatbot (e.g. checking claim status or deductible amounts) and how the tool execution loop ran.',
        trade_off: 'When would you use function calling with automatic tool execution versus multi-agent delegation for multi-step tasks?',
        debugging: 'What error handling do you implement when the LLM generates invalid JSON arguments that fail Pydantic model validation?',
      },
      16: {
        conceptual: 'On Day 16, you built the FastAPI backend for the chatbot. How did you structure the session-based conversation state and history endpoints?',
        explanation: 'Explain how your FastAPI `/chat` endpoint coordinates retrieval, function calling, and conversation memory before returning a response.',
        trade_off: 'What are the pros and cons of storing conversation history in SQLite versus an in-memory Redis cache for production concurrency?',
        design: 'Design a stateless FastAPI architecture that can serve thousands of concurrent chat sessions while maintaining persistent conversation context.',
      },
      18: {
        conceptual: 'How do Server-Sent Events (SSE) and StreamingResponse in FastAPI deliver real-time LLM token streams to the client interface?',
        explanation: 'Walk through how your backend handles streaming token generation and how client connection drops or timeouts are handled gracefully.',
        trade_off: 'What are the trade-offs between WebSockets and Server-Sent Events (SSE) for AI chatbot streaming responses?',
        debugging: 'If streaming responses stutter or buffer unexpectedly across reverse proxies like Nginx, what HTTP headers and chunking settings would you configure?',
      },
      20: {
        conceptual: 'Why is context window and token limit management critical for multi-turn conversations, and how does conversation summarization work?',
        explanation: 'How did you implement context window management to ensure older messages are summarized without losing critical user preferences or policy details?',
        trade_off: 'What are the trade-offs between a sliding context window (discarding oldest messages) versus recursive summarization for long medical consultations?',
        design: 'Design a token-aware memory manager that dynamically balances retrieved RAG chunks, chat history, and system instructions within a fixed token budget.',
      },
      21: {
        conceptual: 'What is the ReAct (Reasoning + Acting) paradigm in LangChain agents, and how does the Thought-Action-Observation loop function?',
        explanation: 'How did you convert your standalone healthcare functions into reusable LangChain tools, and how did you verify that the agent selects the right tool?',
        trade_off: 'When does an agentic ReAct loop introduce excessive latency or cost compared to deterministic rule-based routing?',
        debugging: 'If an agent gets trapped in an infinite tool invocation loop, what max iterations or stopping conditions should be configured?',
      },
      22: {
        conceptual: 'On Day 22, you implemented Multi-Agent Orchestration with CrewAI or LangGraph. How does a multi-agent system divide complex workflows among specialized agents?',
        explanation: 'Describe the router agent and specialist agents you designed for the healthcare domain (e.g. billing specialist, claims specialist, triage agent).',
        trade_off: 'What are the communication overhead and state synchronization trade-offs of multi-agent architectures versus a single monolithic agent with many tools?',
        design: 'How would you architect a multi-agent workflow where a coordinator agent supervises both a RAG researcher agent and a compliance validator agent before responding to a patient?',
      },
      23: {
        conceptual: 'What is the Model Context Protocol (MCP), and how does standardizing tools and resources via JSON-RPC benefit LLM application architectures?',
        explanation: 'Walk me through the MCP server you built on Day 23: what tools did you expose, and how did an MCP client like Claude Desktop or Cline interact with it?',
        trade_off: 'What are the architectural advantages of decoupling tool implementations into MCP servers rather than hardcoding them into a specific agent framework?',
        debugging: 'How do you handle schema negotiation errors or connection drops between an MCP host client and your MCP tool server?',
      },
      28: {
        conceptual: 'On Day 28, you containerized your chatbot with Docker and deployed to Kubernetes. What key elements are needed in a production container definition for an AI backend?',
        explanation: 'Explain how you configured Kubernetes deployments, services, environment secrets, and liveness/readiness health probes for the FastAPI chatbot.',
        trade_off: 'What are the resource allocation trade-offs (CPU vs memory vs GPU) when scaling containerized LLM inference backends versus API proxy services?',
        debugging: 'If your Kubernetes Pod is crashing with OOMKilled errors during high-volume vector search, how would you diagnose and resolve the issue?',
      },
      29: {
        conceptual: 'What metrics are critical for observing a production AI chatbot (latency, token usage, retrieval precision, error rates), and how do Prometheus and Grafana collect them?',
        explanation: 'How did you implement structured logging throughout your retrieval and LLM pipeline to trace query failures and tool execution metrics?',
        trade_off: 'What are the cost and performance trade-offs of logging full prompt/response payloads versus logging only metadata and hashes?',
        debugging: 'If your Grafana dashboard reveals a sudden 30% drop in retrieval relevance scores, what telemetry would you inspect first to find the root cause?',
      },
      31: {
        conceptual: 'For your Day 31 Capstone Project, you presented a complete enterprise healthcare chatbot. What was the overarching architecture of the system?',
        explanation: 'Explain how your capstone integrated hybrid retrieval, multi-agent orchestration, MCP tools, and containerized deployment into a unified solution.',
        trade_off: 'Looking back at your capstone, what major architectural trade-off or technology choice would you change if you were redesigning it for 100x user scale today?',
        production: 'How would you deploy, secure, and monitor your capstone system to meet HIPAA compliance and 99.9% uptime SLAs in a real healthcare provider environment?',
      },
    };

    const dayGroup = questionBank[day] || questionBank[10];
    const key = type === 'trade-off' ? 'trade_off' : type;
    return (
      dayGroup[key] ||
      dayGroup.explanation ||
      dayGroup.conceptual ||
      `On Day ${day} (${topic}), could you explain how you designed your system and what technical challenges you encountered during implementation?`
    );
  }
}
