import {
  AnswerEvaluation,
  DifficultyLevel,
  InterviewSessionState,
} from './types';
import { CurriculumService } from './curriculumService';
import { generateContentWithGemini } from './geminiClient';

export class EvaluatorService {
  public static async evaluateAnswer(
    session: InterviewSessionState,
    question: string,
    answer: string,
    day: number,
    topic: string,
    currentDifficulty: DifficultyLevel
  ): Promise<AnswerEvaluation> {
    const curriculumDay = CurriculumService.getDay(day);
    const objectives = curriculumDay?.objectives || [];
    const tools = curriculumDay?.tools || [];

    // Try Gemini evaluation first
    const geminiEval = await this.evaluateWithGemini(
      question,
      answer,
      day,
      topic,
      objectives,
      tools,
      currentDifficulty
    );

    if (geminiEval) {
      return geminiEval;
    }

    // Heuristic & rule-based evaluation fallback
    return this.evaluateHeuristically(
      question,
      answer,
      day,
      topic,
      objectives,
      tools,
      currentDifficulty
    );
  }

  private static async evaluateWithGemini(
    question: string,
    answer: string,
    day: number,
    topic: string,
    objectives: string[],
    tools: string[],
    currentDifficulty: DifficultyLevel
  ): Promise<AnswerEvaluation | null> {
    const systemPrompt = `You are a Principal AI Technical Interview Evaluator.
Your job is to objectively and rigorously evaluate a candidate's answer during a technical interview.
You must ground your evaluation in the official curriculum for Day ${day}: "${topic}".
Objectives for this day: ${JSON.stringify(objectives)}
Associated tools: ${JSON.stringify(tools)}

Return ONLY valid JSON matching this exact structure:
{
  "correctness": 0.85,
  "depth": 0.75,
  "clarity": 0.80,
  "practicalUnderstanding": 0.70,
  "confidence": 0.80,
  "score": 7.8,
  "missingConcepts": ["concept1", "concept2"],
  "misconceptions": ["misconception if any"],
  "followUpNeeded": true,
  "suggestedFollowUp": "Brief targeted follow-up question or probe",
  "recommendedDifficulty": "medium",
  "critique": "Actionable feedback on what was strong and what was missing"
}`;

    const userPrompt = `Technical Question Asked:
"${question}"

Candidate Answer:
"${answer}"

Current Difficulty: ${currentDifficulty}

Evaluate the candidate's answer with precise technical standards.`;

    const raw = await generateContentWithGemini(userPrompt, systemPrompt, 0.2);
    if (!raw) return null;

    try {
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          topic,
          curriculumDay: day,
          question,
          answer,
          correctness: typeof parsed.correctness === 'number' ? parsed.correctness : 0.7,
          depth: typeof parsed.depth === 'number' ? parsed.depth : 0.6,
          clarity: typeof parsed.clarity === 'number' ? parsed.clarity : 0.7,
          practicalUnderstanding:
            typeof parsed.practicalUnderstanding === 'number'
              ? parsed.practicalUnderstanding
              : 0.6,
          confidence: typeof parsed.confidence === 'number' ? parsed.confidence : 0.7,
          score: typeof parsed.score === 'number' ? parsed.score : 7.0,
          missingConcepts: Array.isArray(parsed.missingConcepts) ? parsed.missingConcepts : [],
          misconceptions: Array.isArray(parsed.misconceptions) ? parsed.misconceptions : [],
          followUpNeeded: Boolean(parsed.followUpNeeded),
          suggestedFollowUp: parsed.suggestedFollowUp || undefined,
          recommendedDifficulty: ['easy', 'medium', 'hard'].includes(parsed.recommendedDifficulty)
            ? parsed.recommendedDifficulty
            : currentDifficulty,
          critique: parsed.critique || 'Good technical foundation demonstrated.',
        };
      }
    } catch (e) {
      console.warn('[Evaluator] JSON parse error, falling back to heuristic:', e);
    }

    return null;
  }

  private static evaluateHeuristically(
    question: string,
    answer: string,
    day: number,
    topic: string,
    objectives: string[],
    tools: string[],
    currentDifficulty: DifficultyLevel
  ): AnswerEvaluation {
    const text = (answer || '').toLowerCase().trim();
    const wordCount = text.split(/\s+/).filter(Boolean).length;

    // Term analysis based on curriculum day
    const domainKeywords: Record<number, string[]> = {
      7: ['vector', 'embedding', 'dimension', 'transformer', 'similarity', 'cosine', 'semantic', 'cluster', 'pca'],
      8: ['chromadb', 'pinecone', 'index', 'hnsw', 'metadata', 'collection', 'store', 'persistence', 'distance'],
      10: ['retrieval', 'hybrid', 'sql', 'sqlite', 'router', 'deduplication', 'rank', 'match', 'query'],
      11: ['rag', 'llm', 'context', 'grounding', 'retriever', 'generation', 'hallucination', 'prompt', 'pipeline'],
      12: ['prompt', 'few-shot', 'zero-shot', 'chain-of-thought', 'system prompt', 'temperature', 'instruction'],
      13: ['function calling', 'tool', 'pydantic', 'schema', 'structured output', 'json', 'validation'],
      14: ['fine-tuning', 'dataset', 'lora', 'qlora', 'training', 'weights', 'loss', 'epochs'],
      15: ['peft', 'transformers', 'bitsandbytes', 'quantization', 'adapter', 'lora', 'evaluate'],
      16: ['fastapi', 'endpoint', 'chat', 'session', 'backend', 'api', 'cors', 'post'],
      18: ['streaming', 'sse', 'server-sent events', 'tokens', 'chunk', 'generator', 'websocket', 'async'],
      20: ['memory', 'context', 'token limit', 'summarization', 'sqlite', 'history', 'window', 'buffer'],
      21: ['langchain', 'agent', 'react', 'tool', 'reasoning trace', 'thought', 'action', 'observation'],
      22: ['multi-agent', 'crewai', 'langgraph', 'orchestration', 'router', 'specialist', 'workflow', 'state'],
      23: ['mcp', 'model context protocol', 'server', 'client', 'tools', 'resources', 'claude', 'json-rpc'],
      27: ['security', 'guardrails', 'prompt injection', 'sanitization', 'authentication', 'jailbreak', 'privacy'],
      28: ['docker', 'kubernetes', 'container', 'deployment', 'pod', 'service', 'cluster', 'ingress', 'health check'],
      29: ['prometheus', 'grafana', 'logging', 'observability', 'metrics', 'latency', 'traces', 'telemetry'],
      31: ['capstone', 'architecture', 'end-to-end', 'production', 'trade-offs', 'scalability', 'healthcare', 'demo'],
    };

    const targetKeywords = domainKeywords[day] || ['architecture', 'pipeline', 'trade-off', 'implementation'];
    const matchedKeywords = targetKeywords.filter((kw) => text.includes(kw));
    const keywordRatio = matchedKeywords.length / Math.max(1, targetKeywords.length);

    // Compute basic scores
    let correctness = 0.5;
    let depth = 0.5;
    let clarity = 0.6;
    let practicalUnderstanding = 0.5;

    if (wordCount < 10) {
      correctness = 0.3;
      depth = 0.2;
      clarity = 0.4;
      practicalUnderstanding = 0.2;
    } else if (wordCount > 35) {
      depth += 0.2;
      practicalUnderstanding += 0.15;
    }

    if (matchedKeywords.length >= 3) {
      correctness += 0.35;
      depth += 0.2;
      practicalUnderstanding += 0.25;
    } else if (matchedKeywords.length >= 1) {
      correctness += 0.2;
      depth += 0.1;
      practicalUnderstanding += 0.1;
    } else {
      correctness -= 0.15;
      depth -= 0.15;
    }

    // Check for practical indicators
    if (
      text.includes('i built') ||
      text.includes('we implemented') ||
      text.includes('in our pipeline') ||
      text.includes('trade-off') ||
      text.includes('because') ||
      text.includes('instead of')
    ) {
      practicalUnderstanding += 0.15;
      depth += 0.1;
    }

    correctness = Math.min(1.0, Math.max(0.1, Number(correctness.toFixed(2))));
    depth = Math.min(1.0, Math.max(0.1, Number(depth.toFixed(2))));
    clarity = Math.min(1.0, Math.max(0.1, Number(clarity.toFixed(2))));
    practicalUnderstanding = Math.min(
      1.0,
      Math.max(0.1, Number(practicalUnderstanding.toFixed(2)))
    );
    const confidence = Math.min(1.0, Math.max(0.4, Number((clarity * 0.5 + depth * 0.5).toFixed(2))));

    const composite =
      correctness * 0.35 +
      depth * 0.25 +
      practicalUnderstanding * 0.25 +
      clarity * 0.15;
    const score = Number((composite * 10).toFixed(1));

    // Determine missing concepts
    const missingConcepts = targetKeywords
      .filter((kw) => !matchedKeywords.includes(kw))
      .slice(0, 2);

    const misconceptions: string[] = [];
    if (text.includes('vector db stores only text') || text.includes('no embeddings needed')) {
      misconceptions.push('Confusion regarding embedding storage vs raw text');
    }
    if (text.includes('fine-tuning replaces rag for facts')) {
      misconceptions.push('Misunderstanding fine-tuning vs RAG for dynamic knowledge retrieval');
    }

    // Difficulty recommendation
    let recommendedDifficulty: DifficultyLevel = currentDifficulty;
    if (score >= 7.8) {
      recommendedDifficulty = currentDifficulty === 'easy' ? 'medium' : 'hard';
    } else if (score <= 4.5) {
      recommendedDifficulty = currentDifficulty === 'hard' ? 'medium' : 'easy';
    }

    const followUpNeeded = score >= 4.0 && (depth < 0.75 || missingConcepts.length > 0);

    let suggestedFollowUp: string | undefined;
    if (followUpNeeded && missingConcepts.length > 0) {
      suggestedFollowUp = `Could you explain how ${missingConcepts[0]} plays a role in your ${topic} architecture?`;
    }

    const critique =
      score >= 8.0
        ? `Strong command of ${topic}. Articulated key components (${matchedKeywords.join(', ')}).`
        : score >= 5.5
        ? `Good baseline understanding of ${topic}, though could elaborate further on ${missingConcepts.join(' and ')}.`
        : `Answer for ${topic} was too surface-level or missed core implementation mechanics.`;

    return {
      topic,
      curriculumDay: day,
      question,
      answer,
      correctness,
      depth,
      clarity,
      practicalUnderstanding,
      confidence,
      score,
      missingConcepts,
      misconceptions,
      followUpNeeded,
      suggestedFollowUp,
      recommendedDifficulty,
      critique,
    };
  }
}
