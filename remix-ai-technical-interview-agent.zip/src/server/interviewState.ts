import {
  InterviewSessionState,
  CandidateProfile,
  ConversationTurn,
  AnswerEvaluation,
  DifficultyLevel,
  QuestionType,
  FinalFeedback,
} from './types';

class InterviewStateManager {
  private sessions: Map<string, InterviewSessionState> = new Map();

  public createSession(sessionId: string, candidate: CandidateProfile): InterviewSessionState {
    const state: InterviewSessionState = {
      sessionId,
      candidate,
      status: 'in_progress',
      questionCount: 0,
      minimumQuestions: 8,
      minimumCurriculumDays: 4,
      curriculumDaysCovered: [],
      topicsCovered: [],
      currentTopic: null,
      currentDay: null,
      currentQuestionType: 'warmup',
      difficulty: 'medium',
      conversationHistory: [],
      answerEvaluations: [],
      strengths: [],
      weaknesses: [],
      followUpCount: 0,
      isCurrentFollowUp: false,
      currentQuestion: null,
      lastCandidateAnswer: null,
      feedback: null,
      startTime: Date.now(),
      updatedAt: Date.now(),
    };

    this.sessions.set(sessionId, state);
    return state;
  }

  public getSession(sessionId: string): InterviewSessionState | undefined {
    return this.sessions.get(sessionId);
  }

  public updateSession(
    sessionId: string,
    updates: Partial<InterviewSessionState>
  ): InterviewSessionState {
    const current = this.sessions.get(sessionId);
    if (!current) {
      throw new Error(`Interview session not found for sessionId: ${sessionId}`);
    }
    const updated: InterviewSessionState = {
      ...current,
      ...updates,
      updatedAt: Date.now(),
    };
    this.sessions.set(sessionId, updated);
    return updated;
  }

  public addTurn(
    sessionId: string,
    turn: ConversationTurn
  ): InterviewSessionState {
    const session = this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found.`);
    }

    session.conversationHistory.push(turn);
    session.updatedAt = Date.now();
    return session;
  }

  public recordEvaluation(
    sessionId: string,
    evalResult: AnswerEvaluation
  ): InterviewSessionState {
    const session = this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found.`);
    }

    session.answerEvaluations.push(evalResult);

    // Track strengths & weaknesses
    if (evalResult.score >= 7.5 && evalResult.correctness >= 0.75) {
      if (!session.strengths.includes(evalResult.topic)) {
        session.strengths.push(evalResult.topic);
      }
    } else if (evalResult.score < 5.0 || evalResult.correctness < 0.5) {
      if (!session.weaknesses.includes(evalResult.topic)) {
        session.weaknesses.push(evalResult.topic);
      }
    }

    // Add missing concepts into weaknesses if any
    for (const concept of evalResult.missingConcepts) {
      if (!session.weaknesses.includes(concept)) {
        session.weaknesses.push(concept);
      }
    }

    // Dynamic difficulty adjustment
    session.difficulty = evalResult.recommendedDifficulty;
    session.updatedAt = Date.now();
    return session;
  }

  public markCurriculumDayCovered(
    sessionId: string,
    day: number,
    topic: string
  ): InterviewSessionState {
    const session = this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found.`);
    }

    if (!session.curriculumDaysCovered.includes(day)) {
      session.curriculumDaysCovered.push(day);
    }
    if (!session.topicsCovered.includes(topic)) {
      session.topicsCovered.push(topic);
    }
    session.currentDay = day;
    session.currentTopic = topic;
    session.updatedAt = Date.now();
    return session;
  }

  public setFeedback(sessionId: string, feedback: FinalFeedback): InterviewSessionState {
    const session = this.getSession(sessionId);
    if (!session) {
      throw new Error(`Session ${sessionId} not found.`);
    }
    session.feedback = feedback;
    session.status = 'completed';
    session.updatedAt = Date.now();
    return session;
  }

  public getAllSessions(): InterviewSessionState[] {
    return Array.from(this.sessions.values());
  }

  public clear(): void {
    this.sessions.clear();
  }
}

export const interviewStateManager = new InterviewStateManager();
