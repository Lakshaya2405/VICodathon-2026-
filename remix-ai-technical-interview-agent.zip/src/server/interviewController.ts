import {
  InterviewApiRequestBody,
  InterviewApiResponse,
  StartInterviewRequestBody,
  TurnInterviewRequestBody,
  ConversationTurn,
} from './types';
import { interviewStateManager } from './interviewState';
import { InterviewerService } from './interviewer';
import { EvaluatorService } from './evaluator';
import { FeedbackGeneratorService } from './feedbackGenerator';
import { CandidateService } from './candidateService';

export class InterviewController {
  public static async handleInterview(
    body: any
  ): Promise<{ status: number; data: InterviewApiResponse | { error: string } }> {
    if (!body || typeof body !== 'object') {
      return {
        status: 400,
        data: { error: 'Invalid request body. Expected JSON object.' },
      };
    }

    const { sessionId } = body;
    if (!sessionId || typeof sessionId !== 'string') {
      return {
        status: 400,
        data: { error: 'Missing or invalid required field: sessionId.' },
      };
    }

    // Step 1: Start Interview Check (candidate provided)
    if ('candidate' in body && body.candidate) {
      return this.handleStart(sessionId, body.candidate);
    }

    // Step 2: Conversation Turn (message provided)
    if ('message' in body) {
      return this.handleTurn(sessionId, String(body.message || ''));
    }

    return {
      status: 400,
      data: {
        error: 'Invalid request format. Must provide "candidate" to start or "message" to continue.',
      },
    };
  }

  private static async handleStart(
    sessionId: string,
    candidate: any
  ): Promise<{ status: number; data: InterviewApiResponse }> {
    // Validate or normalize candidate profile
    const normalizedCandidate = candidate.member ? candidate : CandidateService.getAllCandidates()[0];

    // Create session in state manager
    const session = interviewStateManager.createSession(sessionId, normalizedCandidate);

    // Generate personalized opening
    const opening = await InterviewerService.generateOpening(session.candidate);

    // Update session with question 1
    session.questionCount = 1;
    session.currentDay = opening.day;
    session.currentTopic = opening.topic;
    session.currentQuestion = opening.question;
    session.isCurrentFollowUp = false;
    session.curriculumDaysCovered = [opening.day];
    session.topicsCovered = [opening.topic];

    // Record turn in history
    const interviewerTurn: ConversationTurn = {
      role: 'interviewer',
      content: opening.question,
      timestamp: Date.now(),
      curriculumDay: opening.day,
      topic: opening.topic,
      questionType: 'warmup',
      difficulty: session.difficulty,
    };
    interviewStateManager.addTurn(sessionId, interviewerTurn);

    // Expected response format per technical-spec.md:
    // { "reply": "Welcome. Let's begin your interview.", "done": false }
    // We combine the welcome greeting with the opening question so candidate has the prompt immediately
    const replyText = `${opening.greeting} ${opening.question}`;

    const response: InterviewApiResponse = {
      reply: replyText,
      done: false,
      metadata: {
        questionCount: session.questionCount,
        curriculumDaysCovered: session.curriculumDaysCovered,
        currentDifficulty: session.difficulty,
        currentTopic: session.currentTopic,
        currentDay: session.currentDay,
        isFollowUp: false,
      },
    };

    return { status: 200, data: response };
  }

  private static async handleTurn(
    sessionId: string,
    candidateMessage: string
  ): Promise<{ status: number; data: InterviewApiResponse | { error: string } }> {
    const session = interviewStateManager.getSession(sessionId);
    if (!session) {
      return {
        status: 404,
        data: {
          error: `Interview session "${sessionId}" not found. Please start the interview with a candidate payload first.`,
        },
      };
    }

    if (session.status === 'completed' && session.feedback) {
      return {
        status: 200,
        data: {
          reply: 'Interview completed.',
          done: true,
          feedback: session.feedback,
        },
      };
    }

    // Record candidate's answer in history
    const candidateTurn: ConversationTurn = {
      role: 'candidate',
      content: candidateMessage,
      timestamp: Date.now(),
    };
    interviewStateManager.addTurn(sessionId, candidateTurn);
    session.lastCandidateAnswer = candidateMessage;

    // 1. Evaluate candidate answer against current question and topic
    const currentQuestion = session.currentQuestion || 'Tell me about your AI project architecture.';
    const currentDay = session.currentDay || 7;
    const currentTopic = session.currentTopic || 'Embeddings Explained';

    const evaluation = await EvaluatorService.evaluateAnswer(
      session,
      currentQuestion,
      candidateMessage,
      currentDay,
      currentTopic,
      session.difficulty
    );

    interviewStateManager.recordEvaluation(sessionId, evaluation);
    interviewStateManager.markCurriculumDayCovered(sessionId, currentDay, currentTopic);

    // Check completion criteria:
    // Minimum 8 questions asked AND minimum 4 curriculum days covered
    const hasMetMinimumQuestions = session.questionCount >= 8;
    const hasMetCurriculumDays = session.curriculumDaysCovered.length >= 4;

    if (hasMetMinimumQuestions && hasMetCurriculumDays) {
      // Generate final feedback
      const feedback = await FeedbackGeneratorService.generateFinalFeedback(session);
      interviewStateManager.setFeedback(sessionId, feedback);

      const finalResponse: InterviewApiResponse = {
        reply: 'Interview completed.',
        done: true,
        feedback: {
          summary: feedback.summary,
          strengths: feedback.strengths,
          gaps: feedback.gaps,
          next: feedback.next,
          detailedScores: feedback.detailedScores,
        },
        metadata: {
          questionCount: session.questionCount,
          curriculumDaysCovered: session.curriculumDaysCovered,
          currentDifficulty: session.difficulty,
          currentTopic: session.currentTopic,
          currentDay: session.currentDay,
          isFollowUp: false,
          latestEvaluation: {
            score: evaluation.score,
            correctness: evaluation.correctness,
            depth: evaluation.depth,
            missingConcepts: evaluation.missingConcepts,
            critique: evaluation.critique,
          },
        },
      };

      return { status: 200, data: finalResponse };
    }

    // 2. Generate next question adaptively (follow-up or new curriculum day)
    const nextQ = await InterviewerService.generateNextQuestion(session);

    // Update state for next question
    session.questionCount += 1;
    session.currentDay = nextQ.day;
    session.currentTopic = nextQ.topic;
    session.currentQuestion = nextQ.question;
    session.currentQuestionType = nextQ.questionType;
    session.isCurrentFollowUp = nextQ.isFollowUp;
    session.difficulty = nextQ.difficulty;

    if (!session.curriculumDaysCovered.includes(nextQ.day)) {
      session.curriculumDaysCovered.push(nextQ.day);
    }
    if (!session.topicsCovered.includes(nextQ.topic)) {
      session.topicsCovered.push(nextQ.topic);
    }

    // Record interviewer's new question
    const nextTurn: ConversationTurn = {
      role: 'interviewer',
      content: nextQ.question,
      timestamp: Date.now(),
      curriculumDay: nextQ.day,
      topic: nextQ.topic,
      questionType: nextQ.questionType,
      difficulty: nextQ.difficulty,
      evaluation,
    };
    interviewStateManager.addTurn(sessionId, nextTurn);

    const response: InterviewApiResponse = {
      reply: nextQ.question,
      done: false,
      metadata: {
        questionCount: session.questionCount,
        curriculumDaysCovered: session.curriculumDaysCovered,
        currentDifficulty: session.difficulty,
        currentTopic: session.currentTopic,
        currentDay: session.currentDay,
        isFollowUp: nextQ.isFollowUp,
        latestEvaluation: {
          score: evaluation.score,
          correctness: evaluation.correctness,
          depth: evaluation.depth,
          missingConcepts: evaluation.missingConcepts,
          critique: evaluation.critique,
        },
      },
    };

    return { status: 200, data: response };
  }
}
