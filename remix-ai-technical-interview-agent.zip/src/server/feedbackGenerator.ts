import { FinalFeedback, InterviewSessionState, AnswerEvaluation } from './types';
import { generateContentWithGemini } from './geminiClient';

export class FeedbackGeneratorService {
  public static async generateFinalFeedback(
    session: InterviewSessionState
  ): Promise<FinalFeedback> {
    const evaluations = session.answerEvaluations;
    const candidate = session.candidate;
    const candidateName = candidate.member.name;
    const candidateRole = candidate.member.jobRole;

    // Compute quantitative metrics
    const count = Math.max(1, evaluations.length);
    const avgCorrectness = evaluations.reduce((acc, e) => acc + e.correctness, 0) / count;
    const avgDepth = evaluations.reduce((acc, e) => acc + e.depth, 0) / count;
    const avgClarity = evaluations.reduce((acc, e) => acc + e.clarity, 0) / count;
    const avgPractical = evaluations.reduce((acc, e) => acc + e.practicalUnderstanding, 0) / count;

    // Compute standard scores according to scoring framework:
    // Technical Knowledge 30%, Conceptual Depth 20%, Problem Solving 20%, Practical Understanding 15%, Communication 10%, Engineering Judgment 5%
    const technicalScore = Math.round(avgCorrectness * 100);
    const conceptualDepthScore = Math.round(avgDepth * 100);
    const practicalUnderstandingScore = Math.round(avgPractical * 100);
    const communicationScore = Math.round(avgClarity * 100);
    const problemSolvingScore = Math.round(((avgCorrectness + avgDepth) / 2) * 100);
    const engineeringJudgmentScore = Math.round(((avgDepth + avgPractical) / 2) * 100);

    const overallScore = Math.round(
      technicalScore * 0.3 +
        conceptualDepthScore * 0.2 +
        problemSolvingScore * 0.2 +
        practicalUnderstandingScore * 0.15 +
        communicationScore * 0.1 +
        engineeringJudgmentScore * 0.05
    );

    // Try Gemini synthesis for personalized, high-caliber feedback
    const geminiFeedback = await this.synthesizeWithGemini(
      session,
      evaluations,
      overallScore,
      technicalScore
    );

    if (geminiFeedback) {
      return {
        ...geminiFeedback,
        detailedScores: {
          overallScore,
          technicalScore,
          conceptualDepthScore,
          problemSolvingScore,
          practicalUnderstandingScore,
          communicationScore,
          engineeringJudgmentScore,
        },
      };
    }

    // Heuristic synthesis fallback
    return this.synthesizeHeuristically(
      session,
      evaluations,
      overallScore,
      technicalScore,
      conceptualDepthScore,
      problemSolvingScore,
      practicalUnderstandingScore,
      communicationScore,
      engineeringJudgmentScore
    );
  }

  private static async synthesizeWithGemini(
    session: InterviewSessionState,
    evaluations: AnswerEvaluation[],
    overallScore: number,
    technicalScore: number
  ): Promise<FinalFeedback | null> {
    const candidate = session.candidate;
    const candidateName = candidate.member.name;
    const candidateRole = candidate.member.jobRole;

    const evalSummaries = evaluations.map((e, idx) => ({
      qNumber: idx + 1,
      topic: e.topic,
      day: e.curriculumDay,
      score: e.score,
      critique: e.critique,
      missingConcepts: e.missingConcepts,
    }));

    const systemPrompt = `You are a Principal AI Engineering Interviewer and Evaluator.
Generate comprehensive, actionable, and structured interview feedback for a candidate who completed an AI/ML cohort.
Return ONLY valid JSON matching this exact structure:
{
  "summary": "High-level 2-3 sentence assessment of the candidate's technical strengths, problem-solving ability, and production readiness.",
  "strengths": [
    "Specific technical capability demonstrated with curriculum context",
    "Another solid strength"
  ],
  "gaps": [
    "Specific missing concept or architectural gap noticed during answers",
    "Another technical area needing review"
  ],
  "next": [
    "Actionable, concrete study or implementation step",
    "Another actionable next step"
  ]
}`;

    const userPrompt = `Candidate: ${candidateName} (${candidateRole})
Overall Score: ${overallScore}/100
Technical Score: ${technicalScore}/100
Curriculum Days Covered: ${session.curriculumDaysCovered.join(', ')}
Questions Asked: ${session.questionCount}
Evaluations Data: ${JSON.stringify(evalSummaries, null, 2)}

Provide clear, professional, and actionable feedback.`;

    const raw = await generateContentWithGemini(userPrompt, systemPrompt, 0.3);
    if (!raw) return null;

    try {
      const jsonMatch = raw.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        if (
          typeof parsed.summary === 'string' &&
          Array.isArray(parsed.strengths) &&
          Array.isArray(parsed.gaps) &&
          Array.isArray(parsed.next)
        ) {
          return {
            summary: parsed.summary,
            strengths: parsed.strengths,
            gaps: parsed.gaps,
            next: parsed.next,
          };
        }
      }
    } catch (e) {
      console.warn('[FeedbackGenerator] JSON parse error, falling back:', e);
    }

    return null;
  }

  private static synthesizeHeuristically(
    session: InterviewSessionState,
    evaluations: AnswerEvaluation[],
    overallScore: number,
    technicalScore: number,
    conceptualDepthScore: number,
    problemSolvingScore: number,
    practicalUnderstandingScore: number,
    communicationScore: number,
    engineeringJudgmentScore: number
  ): FinalFeedback {
    const candidate = session.candidate;
    const candidateName = candidate.member.name;
    const candidateRole = candidate.member.jobRole;

    const strongEvals = evaluations.filter((e) => e.score >= 7.0);
    const weakEvals = evaluations.filter((e) => e.score < 6.0 || e.missingConcepts.length > 0);

    const strengths: string[] = [];
    const gaps: string[] = [];
    const next: string[] = [];

    // Extract strengths
    if (strongEvals.length > 0) {
      for (const e of strongEvals.slice(0, 3)) {
        strengths.push(
          `Demonstrated solid grasp of ${e.topic} (Day ${e.curriculumDay}), articulating core pipeline mechanics and implementation patterns.`
        );
      }
    } else {
      strengths.push(
        `Demonstrated baseline familiarity across core curriculum modules including ${session.topicsCovered.slice(0, 2).join(' and ')}.`
      );
    }

    if (practicalUnderstandingScore >= 70) {
      strengths.push(
        'Showed practical engineering experience by discussing hands-on trade-offs and deployment considerations.'
      );
    }

    // Extract gaps
    if (weakEvals.length > 0) {
      for (const e of weakEvals.slice(0, 3)) {
        const missing = e.missingConcepts.length > 0 ? e.missingConcepts.join(', ') : 'deeper trade-offs';
        gaps.push(
          `For ${e.topic} (Day ${e.curriculumDay}), needs clearer articulation around ${missing} and edge-case handling.`
        );
      }
    } else {
      gaps.push(
        'Could delve deeper into advanced production telemetry, latency budgeting, and high-throughput vector caching.'
      );
    }

    // Actionable next steps
    next.push(
      'Review end-to-end retrieval benchmarking: evaluate chunk size impact on precision/recall and test re-ranking algorithms.'
    );
    next.push(
      'Deepen multi-agent orchestration and MCP tool schema design to handle complex multi-step tool failure recovery.'
    );
    next.push(
      'Build end-to-end integration tests and load tests for containerized FastAPI endpoints under simulated concurrent traffic.'
    );

    const summary = `${candidateName} (${candidateRole}) completed a rigorous ${evaluations.length}-question technical assessment covering ${session.curriculumDaysCovered.length} curriculum days with an overall score of ${overallScore}/100. ${
      overallScore >= 75
        ? 'The candidate demonstrates strong technical foundations and is well-positioned for AI engineering roles.'
        : 'The candidate demonstrates good fundamental concepts but will benefit from targeted review in retrieval optimization and system trade-offs.'
    }`;

    return {
      summary,
      strengths,
      gaps,
      next,
      detailedScores: {
        overallScore,
        technicalScore,
        conceptualDepthScore,
        problemSolvingScore,
        practicalUnderstandingScore,
        communicationScore,
        engineeringJudgmentScore,
      },
      topicsMastered: strongEvals.map((e) => e.topic),
      topicsNeedingReview: weakEvals.map((e) => e.topic),
    };
  }
}
