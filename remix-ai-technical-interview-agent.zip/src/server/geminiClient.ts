import { GoogleGenAI } from '@google/genai';

let genAIInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }

  if (!genAIInstance) {
    genAIInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  return genAIInstance;
}

export function getPreferredModel(): string {
  return process.env.GEMINI_MODEL || 'gemini-3.6-flash';
}

export async function generateContentWithGemini(
  prompt: string,
  systemInstruction?: string,
  temperature: number = 0.7
): Promise<string | null> {
  const ai = getGeminiClient();
  if (!ai) {
    return null;
  }

  try {
    const model = getPreferredModel();
    const config: any = {
      temperature,
    };
    if (systemInstruction) {
      config.systemInstruction = systemInstruction;
    }

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config,
    });

    const text = response.text;
    return text ? text.trim() : null;
  } catch (error) {
    console.warn('[GeminiClient] API invocation warning:', error);
    return null;
  }
}
