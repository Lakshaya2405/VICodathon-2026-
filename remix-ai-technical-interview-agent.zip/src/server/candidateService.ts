import candidatesJson from '../data/candidates.json';
import { CandidateProfile, CandidateMission } from './types';

const candidatesList: CandidateProfile[] = (candidatesJson as { candidates: CandidateProfile[] }).candidates;

export interface CandidateInsight {
  candidateId: string;
  name: string;
  jobRole: string;
  yearsExperience: number;
  education: string;
  completedDays: number[];
  skippedDays: number[];
  struggledDays: number[]; // missions that took >= 3 attempts or failed
  firstTryDays: number[]; // missions passed on 1st attempt
  strongSignals: string[];
  weakSignals: string[];
  recommendedOpeningTopics: number[];
}

export class CandidateService {
  public static getAllCandidates(): CandidateProfile[] {
    return candidatesList;
  }

  public static getCandidateById(candidateId: string): CandidateProfile | undefined {
    return candidatesList.find((c) => c.member.id === candidateId);
  }

  public static analyzeCandidate(candidate: CandidateProfile): CandidateInsight {
    const completedDays: number[] = [];
    const skippedDays: number[] = [];
    const struggledDays: number[] = [];
    const firstTryDays: number[] = [];

    const strongSignals: string[] = [];
    const weakSignals: string[] = [];

    for (const mission of candidate.missions) {
      if (mission.skipped) {
        skippedDays.push(mission.day);
      } else if (mission.passed) {
        completedDays.push(mission.day);
        if (mission.attempts === 1) {
          firstTryDays.push(mission.day);
        } else if (mission.attempts && mission.attempts >= 3) {
          struggledDays.push(mission.day);
        }
      } else if (mission.passed === false) {
        struggledDays.push(mission.day);
      }
    }

    // Evaluate signals
    if (candidate.signals.missionsFirstTry >= 20) {
      strongSignals.push('High first-try pass rate (' + candidate.signals.missionsFirstTry + ' missions)');
    }
    if (candidate.signals.commitDays >= 28) {
      strongSignals.push('Consistent active learner (' + candidate.signals.commitDays + ' commit days)');
    }

    if (struggledDays.length > 0) {
      weakSignals.push(`Demonstrated friction on Day(s): ${struggledDays.join(', ')}`);
    }
    if (skippedDays.length > 0) {
      weakSignals.push(`Skipped missions on Day(s): ${skippedDays.join(', ')}`);
    }

    // Recommended topics: Focus on passed core days, test both their strong areas and probe their struggles
    const priorityDays = completedDays.length > 0 ? completedDays : [7, 10, 12, 16, 22, 23, 28, 31];
    const recommendedOpeningTopics = priorityDays.slice(0, 5);

    return {
      candidateId: candidate.member.id,
      name: candidate.member.name,
      jobRole: candidate.member.jobRole,
      yearsExperience: candidate.member.yearsExperience,
      education: candidate.member.education,
      completedDays,
      skippedDays,
      struggledDays,
      firstTryDays,
      strongSignals,
      weakSignals,
      recommendedOpeningTopics,
    };
  }

  public static isMissionCompleted(candidate: CandidateProfile, day: number): boolean {
    const mission = candidate.missions.find((m) => m.day === day);
    return !!(mission && mission.passed && !mission.skipped);
  }

  public static isMissionSkipped(candidate: CandidateProfile, day: number): boolean {
    const mission = candidate.missions.find((m) => m.day === day);
    return !!(mission && mission.skipped);
  }

  public static getMissionAttempts(candidate: CandidateProfile, day: number): number {
    const mission = candidate.missions.find((m) => m.day === day);
    return mission?.attempts || 1;
  }
}
