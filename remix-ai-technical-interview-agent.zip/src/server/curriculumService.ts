import curriculumJson from '../data/curriculum.json';
import { CurriculumData, CurriculumDay, CurriculumModule } from './types';

const curriculum: CurriculumData = curriculumJson as CurriculumData;

export class CurriculumService {
  public static getCurriculum(): CurriculumData {
    return curriculum;
  }

  public static getAllDays(): CurriculumDay[] {
    return curriculum.days;
  }

  public static getDay(dayNumber: number): CurriculumDay | undefined {
    return curriculum.days.find((d) => d.day === dayNumber);
  }

  public static getModuleForDay(dayNumber: number): CurriculumModule | undefined {
    return curriculum.modules.find(
      (m) => dayNumber >= m.days[0] && dayNumber <= m.days[1]
    );
  }

  public static getDaysForModule(moduleNumber: number): CurriculumDay[] {
    const mod = curriculum.modules.find((m) => m.n === moduleNumber);
    if (!mod) return [];
    return curriculum.days.filter(
      (d) => d.day >= mod.days[0] && d.day <= mod.days[1]
    );
  }

  public static findDaysByKeywords(keywords: string[]): CurriculumDay[] {
    const lowerKeywords = keywords.map((k) => k.toLowerCase());
    return curriculum.days.filter((d) => {
      const textToSearch = [
        d.title,
        ...d.tools,
        ...d.objectives,
      ]
        .join(' ')
        .toLowerCase();
      return lowerKeywords.some((kw) => textToSearch.includes(kw));
    });
  }

  /**
   * Returns a core curated list of curriculum days suited for comprehensive assessment
   */
  public static getCoreCurriculumDays(): number[] {
    return [7, 8, 10, 11, 12, 13, 16, 20, 21, 22, 23, 27, 28, 29, 31];
  }
}
