import React, { useState, useEffect } from 'react';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { StatsRow } from './components/StatsRow';
import { LiveInterviewView } from './components/LiveInterviewView';
import { CandidateRosterView } from './components/CandidateRosterView';
import { CurriculumExplorerView } from './components/CurriculumExplorerView';
import { SessionInspectorView } from './components/SessionInspectorView';
import { ApiSandboxView } from './components/ApiSandboxView';
import { TechSpecView } from './components/TechSpecView';
import { FeedbackModal } from './components/FeedbackModal';
import { CandidateProfile, InterviewSessionState } from './server/types';
import { CandidateService } from './server/candidateService';

export function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('interview');
  const [candidates, setCandidates] = useState<CandidateProfile[]>([]);
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateProfile | null>(null);
  const [session, setSession] = useState<InterviewSessionState | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isAiLiveMode, setIsAiLiveMode] = useState(true);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  // Initialize candidates list
  useEffect(() => {
    fetch('/api/candidates')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setCandidates(data);
          setSelectedCandidate(data[0]); // Default to Sarah Johnson (Senior Data Engineer)
          startNewInterviewSession(data[0]);
        }
      })
      .catch((err) => {
        console.warn('Fallback loading candidates directly:', err);
        const all = CandidateService.getAllCandidates();
        setCandidates(all);
        if (all.length > 0) {
          setSelectedCandidate(all[0]);
          startNewInterviewSession(all[0]);
        }
      });
  }, []);

  const startNewInterviewSession = async (candidate: CandidateProfile) => {
    setIsLoading(true);
    const newSessionId = `session-${candidate.member.id.toLowerCase()}-${Date.now().toString(36)}`;

    try {
      const res = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: newSessionId,
          candidate,
        }),
      });

      const data = await res.json();

      // Retrieve full session state from backend
      const sessionRes = await fetch(`/api/session/${newSessionId}`);
      if (sessionRes.ok) {
        const fullSession = await sessionRes.json();
        setSession(fullSession);
      } else {
        // Fallback local session state
        setSession({
          sessionId: newSessionId,
          candidate,
          startTime: Date.now(),
          currentQuestionIndex: 0,
          currentQuestion: data.reply,
          currentDay: data.metadata?.currentDay || 7,
          currentTopic: data.metadata?.currentTopic || 'Embeddings Explained',
          difficulty: 'medium',
          status: 'in_progress',
          conversationHistory: [
            {
              role: 'interviewer',
              content: data.reply,
              timestamp: Date.now(),
              curriculumDay: data.metadata?.currentDay || 7,
              topic: data.metadata?.currentTopic || 'Embeddings Explained',
            },
          ],
          answerEvaluations: [],
          topicsCovered: [data.metadata?.currentTopic || 'Embeddings Explained'],
          curriculumDaysCovered: data.metadata?.curriculumDaysCovered || [7],
          questionCount: 1,
        });
      }
    } catch (e) {
      console.error('Error starting interview session:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (message: string) => {
    if (!session || isLoading) return;

    setIsLoading(true);
    try {
      const res = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: session.sessionId,
          message,
        }),
      });

      const data = await res.json();

      // Update session state from backend
      const sessionRes = await fetch(`/api/session/${session.sessionId}`);
      if (sessionRes.ok) {
        const updated = await sessionRes.json();
        setSession(updated);

        // If completed, automatically open the feedback modal!
        if (updated.status === 'completed' && updated.feedback) {
          setShowFeedbackModal(true);
        }
      }
    } catch (e) {
      console.error('Error sending interview turn:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectAndStartCandidate = (candidate: CandidateProfile) => {
    setSelectedCandidate(candidate);
    startNewInterviewSession(candidate);
    setActiveTab('interview');
  };

  const activeTabTitles: Record<NavTab, string> = {
    interview: 'Technical Assessment Console',
    candidates: 'Cohort Roster • 20 Candidate Profiles & History',
    curriculum: 'Curriculum Navigator • 31 Days Across 8 Modules',
    inspector: 'Session Inspector • Reasoning & Evaluation Trace',
    sandbox: 'API Sandbox • POST /api/interview & Automated Test Suite',
    spec: 'Technical Specification • Contract & Grounding Architecture',
  };

  return (
    <div
      id="app-root"
      className="h-screen w-screen flex bg-[#07070a] text-[#f8fafc] font-sans overflow-hidden antialiased select-none relative nova-virtual-bg"
    >
      {/* Global Ambient NOVA MIND Watermark Layer */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-0 select-none"
        aria-hidden="true"
      >
        <div className="text-center transform -rotate-6 scale-110 opacity-[0.035] transition-all">
          <div className="font-display text-[14vw] font-black tracking-[0.25em] text-[#00f0ff] uppercase leading-none whitespace-nowrap">
            NOVA MIND
          </div>
          <div className="font-mono text-[1.8vw] tracking-[0.6em] text-[#ff007f] uppercase font-bold mt-2">
            NEURAL TECHNICAL EVALUATION ENGINE • V3.8
          </div>
        </div>
      </div>

      {/* Editorial Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedCandidate={selectedCandidate}
        questionCount={session?.questionCount || 0}
        daysCoveredCount={session?.curriculumDaysCovered?.length || 0}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-transparent relative z-10">
        {/* Top Header */}
        <Header
          candidates={candidates}
          selectedCandidate={selectedCandidate}
          onSelectCandidate={handleSelectAndStartCandidate}
          onResetSession={() => {
            if (selectedCandidate) startNewInterviewSession(selectedCandidate);
          }}
          isAiLiveMode={isAiLiveMode}
          setIsAiLiveMode={setIsAiLiveMode}
          onOpenTestRunner={() => setActiveTab('sandbox')}
          activeTabTitle={activeTabTitles[activeTab]}
        />

        {/* Dynamic Workspace Container */}
        <main className="flex-1 p-5 md:p-7 flex flex-col gap-5 overflow-hidden min-h-0 relative">
          {/* Top Operational Stats Row (Always visible for real-time observability) */}
          <StatsRow
            questionCount={session?.questionCount || 0}
            minimumQuestions={8}
            curriculumDaysCovered={session?.curriculumDaysCovered || []}
            minimumDays={4}
            difficulty={session?.difficulty || 'medium'}
            averageScore={
              session?.answerEvaluations && session.answerEvaluations.length > 0
                ? session.answerEvaluations.reduce((a, b) => a + b.score, 0) /
                  session.answerEvaluations.length
                : 0
            }
            isComplete={session?.status === 'completed'}
          />

          {/* Active Tab Workspace with Virtual Background Watermark Container */}
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden relative nova-watermark-container">
            {activeTab === 'interview' && selectedCandidate && (
              <LiveInterviewView
                session={session}
                candidate={selectedCandidate}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
                onViewFeedback={() => setShowFeedbackModal(true)}
              />
            )}

            {activeTab === 'candidates' && (
              <CandidateRosterView
                candidates={candidates}
                selectedCandidate={selectedCandidate}
                onSelectAndStart={handleSelectAndStartCandidate}
              />
            )}

            {activeTab === 'curriculum' && <CurriculumExplorerView />}

            {activeTab === 'inspector' && <SessionInspectorView session={session} />}

            {activeTab === 'sandbox' && selectedCandidate && (
              <ApiSandboxView candidate={selectedCandidate} />
            )}

            {activeTab === 'spec' && <TechSpecView />}
          </div>
        </main>
      </div>

      {/* Feedback Evaluation Modal */}
      {showFeedbackModal && session?.feedback && selectedCandidate && (
        <FeedbackModal
          feedback={session.feedback}
          candidate={selectedCandidate}
          onClose={() => setShowFeedbackModal(false)}
          onResetSession={() => {
            if (selectedCandidate) startNewInterviewSession(selectedCandidate);
          }}
        />
      )}
    </div>
  );
}

export default App;

