import React from 'react';
import { Terminal, Code2, ShieldCheck, Sparkles, Cpu } from 'lucide-react';

export const TechSpecView: React.FC = () => {
  return (
    <div id="tech-spec-view" className="flex-1 bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-8 overflow-y-auto space-y-8 select-none backdrop-blur-xl shadow-2xl relative z-10">
      {/* Virtual Background Watermark */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
        <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
          NOVA MIND
        </span>
      </div>

      {/* Title */}
      <div className="border-b border-[#222538] pb-5 relative z-10">
        <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-1">
          Technical Architecture Specification
        </span>
        <h2 className="font-display text-[1.65rem] text-white font-bold tracking-tight">
          AI Technical Interview Agent Protocol & Grounding Specification
        </h2>
        <p className="font-mono text-[0.7rem] text-[#94a3b8] mt-1">
          API Contract • State Machine • Dynamic Grounding Engine • Evaluation Trace
        </p>
      </div>

      {/* Core Endpoint */}
      <section className="space-y-4 relative z-10">
        <h3 className="font-mono text-[0.68rem] uppercase tracking-[0.2em] text-[#ff007f] font-bold">
          1. API Contract (POST /api/interview)
        </h3>
        <p className="font-sans text-[0.95rem] leading-relaxed text-[#cbd5e1]">
          The interviewer communicates through a single stateful, JSON-RPC compliant endpoint:{' '}
          <code className="font-mono text-[0.8rem] bg-[#141624] text-[#00f0ff] px-2 py-0.5 rounded border border-[#00f0ff]/30 shadow-[0_0_8px_rgba(0,240,255,0.2)]">
            POST /api/interview
          </code>
          .
        </p>

        {/* Start Request */}
        <div className="border border-[#222538] rounded-xl p-4 bg-[#080910] shadow-lg">
          <div className="font-mono text-[0.65rem] uppercase font-bold text-[#00ff9d] mb-2">
            // Step 1: Start Interview Request
          </div>
          <pre className="font-mono text-[0.75rem] text-[#38bdf8] overflow-x-auto leading-relaxed">{`{
  "sessionId": "abc-123",
  "candidate": {
    "member": {
      "id": "CAND-001",
      "name": "Sarah Johnson",
      "jobRole": "Senior Data Engineer",
      "yearsExperience": 6
    },
    "missions": [ ... ]
  }
}`}</pre>
        </div>

        {/* Conversation Turn */}
        <div className="border border-[#222538] rounded-xl p-4 bg-[#080910] shadow-lg">
          <div className="font-mono text-[0.65rem] uppercase font-bold text-[#00f0ff] mb-2">
            // Step 2: Message Turn Request
          </div>
          <pre className="font-mono text-[0.75rem] text-[#d8b4fe] overflow-x-auto leading-relaxed">{`{
  "sessionId": "abc-123",
  "message": "Sentence transformers generate dense embeddings with cosine similarity metric."
}`}</pre>
        </div>

        {/* Response */}
        <div className="border border-[#222538] rounded-xl p-4 bg-[#080910] shadow-lg">
          <div className="font-mono text-[0.65rem] uppercase font-bold text-[#ff007f] mb-2">
            // Step 3: End Response with Structured Feedback
          </div>
          <pre className="font-mono text-[0.75rem] text-[#00ff9d] overflow-x-auto leading-relaxed">{`{
  "reply": "Interview completed.",
  "done": true,
  "feedback": {
    "summary": "Candidate demonstrated strong understanding of hybrid retrieval...",
    "strengths": ["Clear explanation of vector embeddings", "Solid SQL query router design"],
    "gaps": ["Did not address latency trade-offs in re-ranking"],
    "next": ["Practice load testing containerized FastAPI endpoints"]
  }
}`}</pre>
        </div>
      </section>

      {/* Rules */}
      <section className="space-y-4 relative z-10">
        <h3 className="font-mono text-[0.68rem] uppercase tracking-[0.2em] text-[#ffbe0b] font-bold">
          2. Mandatory Interview Engine Guarantees
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#10121f] p-5 rounded-xl border border-[#222538] hover:border-[#00f0ff]/40 transition-all shadow-lg">
            <strong className="font-display text-[1.1rem] block mb-1 text-[#00f0ff]">
              Minimum 8 Questions
            </strong>
            <span className="font-sans text-[0.82rem] text-[#94a3b8] leading-relaxed block">
              The interviewer conducts a comprehensive multi-turn session with at least 8 questions before generating final feedback.
            </span>
          </div>
          <div className="bg-[#10121f] p-5 rounded-xl border border-[#222538] hover:border-[#ff007f]/40 transition-all shadow-lg">
            <strong className="font-display text-[1.1rem] block mb-1 text-[#ff007f]">
              Minimum 4 Curriculum Days
            </strong>
            <span className="font-sans text-[0.82rem] text-[#94a3b8] leading-relaxed block">
              Ensures broad technical coverage across vector embeddings, vector databases, hybrid retrieval, RAG, prompt engineering, multi-agent frameworks, MCP, and Kubernetes.
            </span>
          </div>
          <div className="bg-[#10121f] p-5 rounded-xl border border-[#222538] hover:border-[#00ff9d]/40 transition-all shadow-lg">
            <strong className="font-display text-[1.1rem] block mb-1 text-[#00ff9d]">
              Curriculum Grounding
            </strong>
            <span className="font-sans text-[0.82rem] text-[#94a3b8] leading-relaxed block">
              All questions and evaluation criteria are strictly grounded in curriculum.json tools and learning objectives.
            </span>
          </div>
          <div className="bg-[#10121f] p-5 rounded-xl border border-[#222538] hover:border-[#a855f7]/40 transition-all shadow-lg">
            <strong className="font-display text-[1.1rem] block mb-1 text-[#d8b4fe]">
              Candidate Personalization
            </strong>
            <span className="font-sans text-[0.82rem] text-[#94a3b8] leading-relaxed block">
              Opening questions, warm-up topics, and follow-ups are dynamically shaped by candidate background and completed missions.
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};

