import React, { useState } from 'react';
import {
  Download,
  Copy,
  Check,
  X,
  RefreshCw,
  Sparkles,
  Award,
  TrendingUp,
} from 'lucide-react';
import { FinalFeedback, CandidateProfile } from '../server/types';

interface FeedbackModalProps {
  feedback: FinalFeedback;
  candidate: CandidateProfile;
  onClose: () => void;
  onResetSession: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  feedback,
  candidate,
  onClose,
  onResetSession,
}) => {
  const [copied, setCopied] = useState(false);

  const scores = feedback.detailedScores || {
    overallScore: 82,
    technicalScore: 84,
    conceptualDepthScore: 80,
    problemSolvingScore: 82,
    practicalUnderstandingScore: 80,
    communicationScore: 85,
    engineeringJudgmentScore: 80,
  };

  const handleCopy = () => {
    const text = JSON.stringify(feedback, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(feedback, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `interview-feedback-${candidate.member.id}-${Date.now()}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div
      id="feedback-modal-overlay"
      className="fixed inset-0 z-50 bg-[#000000]/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto select-none"
    >
      <div
        id="feedback-modal-card"
        className="bg-[#0c0d15] border border-[#222538] w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden rounded-2xl shadow-[0_0_50px_rgba(0,240,255,0.15)] relative"
      >
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        {/* Header */}
        <div className="bg-[#121422] text-[#f8fafc] p-6 flex items-start justify-between border-b border-[#222538] shrink-0 relative z-10">
          <div>
            <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-1">
              Final Synthesis & Decision Report
            </span>
            <div className="flex items-center gap-3">
              <h3 className="font-display text-[1.65rem] font-bold text-white tracking-tight">
                Interview Evaluation Report
              </h3>
              <span className="font-mono text-[0.65rem] uppercase tracking-wider bg-emerald-500/20 text-[#00ff9d] border border-emerald-500/40 px-2 py-0.5 rounded font-bold shadow-[0_0_8px_rgba(0,255,157,0.3)]">
                Completed
              </span>
            </div>
            <p className="font-mono text-[0.7rem] text-[#94a3b8] mt-1">
              Candidate: <span className="text-white font-semibold">{candidate.member.name}</span> • {candidate.member.jobRole} ({candidate.member.id})
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-[#94a3b8] hover:text-[#ff007f] p-1.5 rounded-lg border border-[#222538] hover:border-[#ff007f] transition-colors cursor-pointer bg-[#0c0d15]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-[#f8fafc] flex-1 relative z-10">
          {/* Executive Summary */}
          <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 shadow-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#a855f7] font-bold">
                Executive Assessment Summary
              </span>
              <div className="flex items-baseline gap-2 font-mono text-[0.75rem]">
                <span className="text-[#94a3b8]">Overall Score:</span>
                <span className="font-bold bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] px-2.5 py-0.5 rounded shadow-[0_0_10px_rgba(0,240,255,0.4)]">
                  {scores.overallScore} / 100
                </span>
              </div>
            </div>
            <p className="font-serif text-[1.08rem] leading-relaxed text-[#f8fafc] font-normal italic">
              "{feedback.summary}"
            </p>
          </div>

          {/* Scoring Grid */}
          <div>
            <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold block mb-3">
              Competency Breakdown & Evaluation Scores
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { label: 'Technical Knowledge', val: scores.technicalScore, weight: '30%', color: '#00f0ff' },
                { label: 'Conceptual Depth', val: scores.conceptualDepthScore, weight: '20%', color: '#a855f7' },
                { label: 'Problem Solving', val: scores.problemSolvingScore, weight: '20%', color: '#ff007f' },
                {
                  label: 'Practical Understanding',
                  val: scores.practicalUnderstandingScore,
                  weight: '15%',
                  color: '#00ff9d',
                },
                { label: 'Communication', val: scores.communicationScore, weight: '10%', color: '#38bdf8' },
                {
                  label: 'Engineering Judgment',
                  val: scores.engineeringJudgmentScore,
                  weight: '5%',
                  color: '#ffbe0b',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="bg-[#121422] border border-[#222538] rounded-xl p-3.5 flex flex-col justify-between shadow-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[0.68rem] text-[#f8fafc] font-medium">{item.label}</span>
                    <span className="font-mono text-[0.6rem] text-[#64748b]">wt: {item.weight}</span>
                  </div>
                  <div className="flex items-baseline justify-between mt-2 font-mono">
                    <span className="font-bold text-base text-white">{item.val}%</span>
                    <span
                      className="text-[0.62rem] uppercase font-bold px-1.5 py-0.5 rounded"
                      style={{
                        backgroundColor: `${item.color}20`,
                        color: item.color,
                        border: `1px solid ${item.color}40`,
                      }}
                    >
                      {item.val >= 80 ? 'Exceeds' : item.val >= 60 ? 'Meets' : 'Needs Review'}
                    </span>
                  </div>
                  <div className="w-full bg-[#080910] border border-[#222538] rounded-full h-1.5 overflow-hidden mt-2">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${item.val}%`,
                        backgroundColor: item.color,
                        boxShadow: `0 0 8px ${item.color}`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Strengths & Gaps Two-Column */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Strengths */}
            <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 shadow-md">
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold text-[#00ff9d] block mb-3">
                Demonstrated Strengths
              </span>
              <ul className="space-y-2.5">
                {feedback.strengths.map((str, idx) => (
                  <li
                    key={idx}
                    className="font-serif text-[0.95rem] text-[#cbd5e1] leading-relaxed flex items-start gap-2.5"
                  >
                    <span className="font-mono text-[0.65rem] text-[#00ff9d] bg-[#00ff9d]/10 border border-[#00ff9d]/30 px-1.5 py-0.5 rounded shrink-0 mt-0.5 font-bold">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Knowledge Gaps */}
            <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 shadow-md">
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold text-[#ff007f] block mb-3">
                Identified Knowledge Gaps
              </span>
              <ul className="space-y-2.5">
                {feedback.gaps.map((gap, idx) => (
                  <li
                    key={idx}
                    className="font-serif text-[0.95rem] text-[#cbd5e1] leading-relaxed flex items-start gap-2.5"
                  >
                    <span className="font-mono text-[0.65rem] text-[#ff007f] bg-[#ff007f]/10 border border-[#ff007f]/30 px-1.5 py-0.5 rounded shrink-0 mt-0.5 font-bold">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{gap}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Actionable Next Steps */}
          <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 shadow-md">
            <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold text-[#00f0ff] block mb-3">
              Actionable Next Steps & Study Recommendations
            </span>
            <div className="space-y-2.5">
              {feedback.next.map((step, idx) => (
                <div
                  key={idx}
                  className="bg-[#080910] border border-[#1d2030] rounded-lg p-3 text-[0.92rem] font-serif text-[#cbd5e1] leading-relaxed flex items-start gap-3"
                >
                  <span className="font-mono text-[0.65rem] bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40 px-2 py-0.5 rounded font-bold shrink-0">
                    Step {idx + 1}
                  </span>
                  <span className="flex-1">{step}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-[#121422] border-t border-[#222538] p-4 flex items-center justify-between shrink-0 relative z-10">
          <div className="flex items-center gap-2 font-mono text-[0.7rem]">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#080910] border border-[#222538] text-[#cbd5e1] hover:border-[#00f0ff] hover:text-[#00f0ff] rounded-lg transition-colors cursor-pointer uppercase tracking-wider"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#00ff9d]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#080910] border border-[#222538] text-[#cbd5e1] hover:border-[#a855f7] hover:text-[#a855f7] rounded-lg transition-colors cursor-pointer uppercase tracking-wider"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Report</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onResetSession();
                onClose();
              }}
              className="font-mono text-[0.7rem] uppercase tracking-wider font-black flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] hover:brightness-110 shadow-[0_0_15px_rgba(0,240,255,0.4)] rounded-lg transition-all cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Next Candidate</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

