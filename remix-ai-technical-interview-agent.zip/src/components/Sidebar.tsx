import React from 'react';
import {
  MessageSquareCode,
  Users,
  BookOpen,
  Activity,
  Terminal,
  FileCode,
  Sparkles,
  Cpu,
} from 'lucide-react';
import { CandidateProfile } from '../server/types';

export type NavTab =
  | 'interview'
  | 'candidates'
  | 'curriculum'
  | 'inspector'
  | 'sandbox'
  | 'spec';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  selectedCandidate: CandidateProfile | null;
  questionCount: number;
  daysCoveredCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  selectedCandidate,
  questionCount,
  daysCoveredCount,
}) => {
  const navItems = [
    {
      id: 'interview' as NavTab,
      label: 'Live Interview',
      icon: MessageSquareCode,
      badge: `Q${questionCount || 1}/8`,
      accentColor: 'text-[#00f0ff] border-cyan-500/30 bg-cyan-500/10',
    },
    {
      id: 'candidates' as NavTab,
      label: 'Candidate Roster',
      icon: Users,
      badge: 'N=20',
      accentColor: 'text-[#ff007f] border-pink-500/30 bg-pink-500/10',
    },
    {
      id: 'curriculum' as NavTab,
      label: 'Curriculum Grounding',
      icon: BookOpen,
      badge: `D${daysCoveredCount || 7}`,
      accentColor: 'text-[#a855f7] border-purple-500/30 bg-purple-500/10',
    },
    {
      id: 'inspector' as NavTab,
      label: 'Reasoning Trace',
      icon: Activity,
      badge: 'LOGS',
      accentColor: 'text-[#00ff9d] border-emerald-500/30 bg-emerald-500/10',
    },
    {
      id: 'sandbox' as NavTab,
      label: 'API Sandbox & Tests',
      icon: Terminal,
      badge: 'RPC',
      accentColor: 'text-[#ffbe0b] border-amber-500/30 bg-amber-500/10',
    },
    {
      id: 'spec' as NavTab,
      label: 'Technical Spec',
      icon: FileCode,
      badge: 'SPEC',
      accentColor: 'text-[#38bdf8] border-sky-500/30 bg-sky-500/10',
    },
  ];

  return (
    <aside
      id="app-sidebar"
      className="w-[250px] bg-[#0c0d14]/90 text-[#f8fafc] flex flex-col border-r border-[#222538] p-5 pb-5 shrink-0 select-none justify-between backdrop-blur-xl relative z-20"
    >
      {/* Brand Header & Navigation */}
      <div className="flex flex-col gap-6">
        {/* NOVA MIND Brand Logo */}
        <div className="px-1 pt-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#00f0ff] via-[#a855f7] to-[#ff007f] p-[1.5px] shadow-[0_0_15px_rgba(0,240,255,0.4)]">
              <div className="w-full h-full bg-[#090a10] rounded-[6px] flex items-center justify-center text-white">
                <Cpu className="w-4 h-4 text-[#00f0ff]" />
              </div>
            </div>
            <div>
              <div className="font-display text-[1.45rem] font-black tracking-[0.1em] text-white flex items-center gap-1.5 leading-none">
                <span className="bg-gradient-to-r from-[#00f0ff] via-[#c084fc] to-[#ff007f] bg-clip-text text-transparent">
                  NOVA MIND
                </span>
              </div>
              <span className="font-mono text-[0.58rem] tracking-[0.25em] text-[#00f0ff]/70 uppercase font-semibold block mt-1">
                AI Technical Examiner
              </span>
            </div>
          </div>
        </div>

        {/* Navigation List */}
        <div>
          <span className="font-mono text-[0.6rem] uppercase tracking-[0.2em] text-[#94a3b8]/60 block mb-2.5 px-2 font-bold">
            Virtual Workspace
          </span>
          <nav className="space-y-1.5">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  id={`nav-btn-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[0.82rem] font-semibold transition-all cursor-pointer text-left border ${
                    isActive
                      ? 'bg-gradient-to-r from-[#00f0ff]/15 via-[#a855f7]/10 to-transparent border-[#00f0ff]/50 text-white shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                      : 'border-transparent text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#151724] hover:border-[#2a2e45]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-[#00f0ff]' : 'text-[#64748b]'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>
                  <span
                    className={`font-mono text-[0.62rem] font-bold px-1.5 py-0.5 rounded border tracking-tight shrink-0 ${
                      isActive
                        ? item.accentColor
                        : 'text-[#64748b] bg-[#121420] border-[#222538]'
                    }`}
                  >
                    {item.badge}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Candidate Profile / System Operator Footer */}
      <div className="pt-4 border-t border-[#222538] px-1">
        <div className="bg-[#121420] border border-[#222538] rounded-xl p-3 relative overflow-hidden">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-mono text-[0.58rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold">
              Active Candidate
            </span>
            <span className="w-2 h-2 rounded-full bg-[#00ff9d] animate-pulse shadow-[0_0_8px_#00ff9d]" />
          </div>
          <div className="text-[0.88rem] font-bold text-white truncate">
            {selectedCandidate ? selectedCandidate.member.name : 'Sarah Johnson'}
          </div>
          <div className="font-mono text-[0.65rem] text-[#94a3b8] truncate mt-0.5">
            {selectedCandidate ? selectedCandidate.member.jobRole : 'Senior Data Engineer'}
          </div>
          <div className="font-mono text-[0.6rem] text-[#64748b] mt-1 flex items-center justify-between">
            <span>ID: {selectedCandidate ? selectedCandidate.member.id : 'CAN-01'}</span>
            <span className="text-[#a855f7] font-semibold">Ready</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

