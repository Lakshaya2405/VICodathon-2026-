import React from 'react';
import { DifficultyLevel } from '../server/types';
import { HelpCircle, BookOpen, Flame, Award } from 'lucide-react';

interface StatsRowProps {
  questionCount: number;
  minimumQuestions: number;
  curriculumDaysCovered: number[];
  minimumDays: number;
  difficulty: DifficultyLevel;
  averageScore: number;
  isComplete: boolean;
}

export const StatsRow: React.FC<StatsRowProps> = ({
  questionCount,
  minimumQuestions,
  curriculumDaysCovered,
  minimumDays,
  difficulty,
  averageScore,
  isComplete,
}) => {
  const getDifficultyLabel = (diff: DifficultyLevel) => {
    switch (diff) {
      case 'easy':
        return 'EASY';
      case 'hard':
        return 'ADVANCED';
      default:
        return 'STANDARD';
    }
  };

  const currDaysLabel =
    curriculumDaysCovered.length > 0
      ? curriculumDaysCovered.map((d) => `D${d}`).join(' ')
      : 'D7';

  return (
    <div id="stats-row" className="grid grid-cols-2 md:grid-cols-4 gap-4 select-none relative z-10">
      {/* Metric 1: Questions (Electric Cyan) */}
      <div className="bg-[#0e101a]/90 border border-[#222538] rounded-xl p-4 flex flex-col justify-between backdrop-blur-md hover:border-[#00f0ff]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.5)] group">
        <div className="flex items-center justify-between mb-1">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold">
            Questions
          </span>
          <HelpCircle className="w-3.5 h-3.5 text-[#00f0ff]/60 group-hover:text-[#00f0ff] transition-colors" />
        </div>
        <div className="font-display text-[1.85rem] font-black leading-none text-white flex items-baseline gap-1">
          <span className="text-[#00f0ff]">{questionCount}</span>
          <span className="text-white/30 text-[1.2rem] font-normal">/{minimumQuestions}</span>
        </div>
        <div className="w-full bg-[#1c1f30] h-1 rounded-full overflow-hidden mt-3">
          <div
            className="h-full bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] shadow-[0_0_8px_#00f0ff]"
            style={{ width: `${Math.min(100, (questionCount / minimumQuestions) * 100)}%` }}
          />
        </div>
      </div>

      {/* Metric 2: Curriculum (Neon Magenta/Purple) */}
      <div className="bg-[#0e101a]/90 border border-[#222538] rounded-xl p-4 flex flex-col justify-between backdrop-blur-md hover:border-[#ff007f]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.5)] group">
        <div className="flex items-center justify-between mb-1">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#ff007f] font-bold">
            Curriculum Days
          </span>
          <BookOpen className="w-3.5 h-3.5 text-[#ff007f]/60 group-hover:text-[#ff007f] transition-colors" />
        </div>
        <div className="font-display text-[1.65rem] font-bold leading-none text-[#ff007f] truncate" title={currDaysLabel}>
          {currDaysLabel}
        </div>
        <div className="w-full bg-[#1c1f30] h-1 rounded-full overflow-hidden mt-3">
          <div
            className="h-full bg-gradient-to-r from-[#ff007f] to-[#a855f7] shadow-[0_0_8px_#ff007f]"
            style={{ width: `${Math.min(100, (curriculumDaysCovered.length / minimumDays) * 100)}%` }}
          />
        </div>
      </div>

      {/* Metric 3: Difficulty (Electric Amber) */}
      <div className="bg-[#0e101a]/90 border border-[#222538] rounded-xl p-4 flex flex-col justify-between backdrop-blur-md hover:border-[#ffbe0b]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.5)] group">
        <div className="flex items-center justify-between mb-1">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#ffbe0b] font-bold">
            Difficulty Tier
          </span>
          <Flame className="w-3.5 h-3.5 text-[#ffbe0b]/60 group-hover:text-[#ffbe0b] transition-colors" />
        </div>
        <div className="font-mono text-[1.4rem] font-black text-[#ffbe0b] leading-none uppercase tracking-wide">
          {getDifficultyLabel(difficulty)}
        </div>
        <div className="w-full bg-[#1c1f30] h-1 rounded-full overflow-hidden mt-3">
          <div
            className="h-full bg-gradient-to-r from-[#ffbe0b] to-[#f59e0b] shadow-[0_0_8px_#ffbe0b]"
            style={{
              width: difficulty === 'hard' ? '100%' : difficulty === 'medium' ? '65%' : '35%',
            }}
          />
        </div>
      </div>

      {/* Metric 4: Score/Rating (Vibrant Emerald) */}
      <div className="bg-[#0e101a]/90 border border-[#222538] rounded-xl p-4 flex flex-col justify-between backdrop-blur-md hover:border-[#00ff9d]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.5)] group">
        <div className="flex items-center justify-between mb-1">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold">
            Candidate Rating
          </span>
          <Award className="w-3.5 h-3.5 text-[#00ff9d]/60 group-hover:text-[#00ff9d] transition-colors" />
        </div>
        <div className="font-display text-[1.65rem] font-bold leading-none text-[#00ff9d]">
          {averageScore > 0 ? (
            <span>
              {averageScore.toFixed(1)} <span className="text-white/30 text-[1.1rem]">/ 10</span>
            </span>
          ) : isComplete ? (
            'EVALUATED'
          ) : (
            'IN PROGRESS'
          )}
        </div>
        <div className="w-full bg-[#1c1f30] h-1 rounded-full overflow-hidden mt-3">
          <div
            className="h-full bg-gradient-to-r from-[#00ff9d] to-[#10b981] shadow-[0_0_8px_#00ff9d]"
            style={{ width: `${Math.min(100, (averageScore / 10) * 100 || 25)}%` }}
          />
        </div>
      </div>
    </div>
  );
};

