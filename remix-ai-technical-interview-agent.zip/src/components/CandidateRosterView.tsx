import React, { useState } from 'react';
import { Search, Play, Users, Sparkles, Filter } from 'lucide-react';
import { CandidateProfile } from '../server/types';
import { CandidateService } from '../server/candidateService';

interface CandidateRosterViewProps {
  candidates: CandidateProfile[];
  selectedCandidate: CandidateProfile | null;
  onSelectAndStart: (candidate: CandidateProfile) => void;
}

export const CandidateRosterView: React.FC<CandidateRosterViewProps> = ({
  candidates,
  selectedCandidate,
  onSelectAndStart,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');

  const roles = ['ALL', ...Array.from(new Set(candidates.map((c) => c.member.jobRole)))];

  const filtered = candidates.filter((c) => {
    const matchesSearch =
      c.member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.member.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.member.jobRole.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'ALL' || c.member.jobRole === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div id="candidate-roster-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Header controls */}
      <div className="bg-[#0c0d15]/90 p-5 border border-[#222538] rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-xl">
        <div>
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#ff007f] font-bold block mb-1">
            Cohort Database • N=20
          </span>
          <h3 className="font-display text-[1.4rem] text-white font-bold tracking-tight">
            Candidate Evaluation Roster
          </h3>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 text-[#64748b] absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search name, role, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-[#121422] border border-[#222538] rounded-lg font-sans text-[0.8rem] text-white placeholder:text-[#64748b] outline-none focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] transition-all"
            />
          </div>

          <div className="relative">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-1.5 bg-[#121422] border border-[#222538] rounded-lg font-mono text-[0.72rem] text-[#00f0ff] font-bold cursor-pointer outline-none focus:border-[#00f0ff] transition-all"
            >
              {roles.map((r) => (
                <option key={r} value={r} className="bg-[#0f1019] text-white">
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Roster Table / Grid with Virtual Background Watermark */}
      <div className="flex-1 bg-[#0c0d15]/90 border border-[#222538] rounded-xl overflow-y-auto backdrop-blur-xl shadow-2xl relative">
        {/* Ambient watermark inside roster */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#ff007f] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        <table className="w-full text-left border-collapse relative z-10">
          <thead>
            <tr className="bg-[#10121d] border-b border-[#222538] font-mono text-[0.62rem] uppercase tracking-wider text-[#94a3b8] font-bold">
              <th className="py-3 px-4">Candidate Profile</th>
              <th className="py-3 px-4">Role & Experience</th>
              <th className="py-3 px-4">Curriculum Completed</th>
              <th className="py-3 px-4">Attempt Pattern</th>
              <th className="py-3 px-4">Completion Status</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#222538]">
            {filtered.map((candidate) => {
              const insight = CandidateService.analyzeCandidate(candidate);
              const isSelected = selectedCandidate?.member.id === candidate.member.id;

              return (
                <tr
                  key={candidate.member.id}
                  className={`hover:bg-[#141624] transition-colors ${
                    isSelected ? 'bg-[#00f0ff]/10 border-l-2 border-[#00f0ff]' : ''
                  }`}
                >
                  {/* Candidate Name & ID */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#00f0ff]/30 to-[#ff007f]/30 border border-white/10 text-white font-mono font-black text-[0.72rem] flex items-center justify-center shrink-0">
                        {candidate.member.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')}
                      </div>
                      <div>
                        <span className="font-display text-[0.95rem] font-bold text-white block leading-tight">
                          {candidate.member.name}
                        </span>
                        <span className="font-mono text-[0.62rem] text-[#00f0ff] font-bold">
                          {candidate.member.id}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Role */}
                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-xs text-[#f1f5f9] block">
                      {candidate.member.jobRole}
                    </span>
                    <span className="font-mono text-[0.62rem] text-[#94a3b8]">
                      {candidate.member.yearsExperience} yrs experience
                    </span>
                  </td>

                  {/* Completed Days */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-xs text-[#00ff9d]">
                        {insight.completedDays.length}
                      </span>
                      <span className="font-mono text-[0.65rem] text-[#64748b]">/ 31</span>
                      <div className="flex gap-1 ml-2">
                        {insight.completedDays.slice(0, 3).map((d) => (
                          <span
                            key={d}
                            className="font-mono text-[0.58rem] px-1.5 py-0.5 rounded bg-[#a855f7]/15 border border-[#a855f7]/30 text-[#d8b4fe] font-bold"
                          >
                            D{d}
                          </span>
                        ))}
                      </div>
                    </div>
                  </td>

                  {/* Struggles */}
                  <td className="py-3.5 px-4">
                    {insight.struggledDays.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {insight.struggledDays.slice(0, 2).map((d) => (
                          <span
                            key={d}
                            className="font-mono text-[0.58rem] px-1.5 py-0.5 rounded bg-[#ffbe0b]/15 border border-[#ffbe0b]/30 text-[#ffbe0b] font-bold"
                          >
                            Day {d} (Retry)
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="font-mono text-[0.62rem] text-[#00ff9d] font-bold">
                        First-try passes
                      </span>
                    )}
                  </td>

                  {/* Skipped */}
                  <td className="py-3.5 px-4">
                    {insight.skippedDays.length > 0 ? (
                      <span className="font-mono text-[0.62rem] text-[#94a3b8]">
                        Skipped {insight.skippedDays.length} days
                      </span>
                    ) : (
                      <span className="font-mono text-[0.62rem] text-[#00ff9d] font-bold">
                        100% Completed
                      </span>
                    )}
                  </td>

                  {/* Action */}
                  <td className="py-3.5 px-4 text-right">
                    <button
                      id={`btn-start-${candidate.member.id}`}
                      onClick={() => onSelectAndStart(candidate)}
                      className={`font-mono text-[0.68rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-lg border transition-all cursor-pointer inline-flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-[#00f0ff] text-[#07070a] border-[#00f0ff] shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                          : 'bg-[#141624] text-[#cbd5e1] border-[#222538] hover:border-[#00f0ff] hover:text-[#00f0ff]'
                      }`}
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>{isSelected ? 'Active' : 'Interview'}</span>
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

