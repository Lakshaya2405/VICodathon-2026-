import React, { useState } from 'react';
import { BookOpen, Layers, Sparkles, Filter, CheckCircle } from 'lucide-react';
import { CurriculumService } from '../server/curriculumService';

export const CurriculumExplorerView: React.FC = () => {
  const curriculum = CurriculumService.getCurriculum();
  const [selectedModule, setSelectedModule] = useState<number | 'ALL'>('ALL');

  const filteredDays = curriculum.days.filter((d) => {
    if (selectedModule === 'ALL') return true;
    const mod = curriculum.modules.find((m) => m.n === selectedModule);
    if (!mod) return true;
    return d.day >= mod.days[0] && d.day <= mod.days[1];
  });

  return (
    <div id="curriculum-explorer-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Header */}
      <div className="bg-[#0c0d15]/90 p-5 border border-[#222538] rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-xl">
        <div>
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-1">
            Curriculum Grounding Matrix
          </span>
          <h3 className="font-display text-[1.4rem] text-white font-bold tracking-tight">
            31-Day Syllabus & Assessment Benchmarks
          </h3>
        </div>

        {/* Module Filter */}
        <div className="flex items-center gap-3">
          <span className="font-mono text-[0.68rem] uppercase tracking-wider text-[#94a3b8]">Filter Module:</span>
          <select
            value={selectedModule}
            onChange={(e) => {
              const val = e.target.value;
              setSelectedModule(val === 'ALL' ? 'ALL' : Number(val));
            }}
            className="px-3 py-1.5 bg-[#121422] border border-[#222538] rounded-lg font-mono text-[0.72rem] text-[#00f0ff] font-bold cursor-pointer outline-none focus:border-[#00f0ff] transition-all"
          >
            <option value="ALL" className="bg-[#0f1019] text-white">All 8 Modules (Days 1-31)</option>
            {curriculum.modules.map((m) => (
              <option key={m.n} value={m.n} className="bg-[#0f1019] text-white">
                Module {m.n}: {m.title} (Days {m.days[0]}-{m.days[1]})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Curriculum Grid with Virtual Background Watermark */}
      <div className="flex-1 bg-[#0c0d15]/90 border border-[#222538] rounded-xl overflow-y-auto p-6 backdrop-blur-xl shadow-2xl relative">
        {/* Ambient watermark inside curriculum */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 relative z-10">
          {filteredDays.map((day) => {
            const mod = curriculum.modules.find(
              (m) => day.day >= m.days[0] && day.day <= m.days[1]
            );

            return (
              <div
                key={day.day}
                className="bg-[#10121f]/85 border border-[#222538] rounded-xl p-5 flex flex-col justify-between hover:border-[#00f0ff]/50 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.4)] group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-mono font-bold text-[0.72rem] bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] px-2.5 py-0.5 rounded shadow-[0_0_10px_rgba(0,240,255,0.3)]">
                      Day {day.day}
                    </span>
                    <span className="font-mono text-[0.62rem] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#ff007f]/10 border border-[#ff007f]/30 text-[#ff007f]">
                      {day.type}
                    </span>
                  </div>

                  <h4 className="font-display text-[1.18rem] font-bold text-white mb-1 leading-snug group-hover:text-[#00f0ff] transition-colors">
                    {day.title}
                  </h4>
                  <p className="font-mono text-[0.65rem] text-[#a855f7] mb-4">
                    Module {mod?.n || ''}: {mod?.title || ''}
                  </p>

                  {/* Tools */}
                  <div className="mb-4">
                    <span className="font-mono text-[0.6rem] uppercase tracking-[0.15em] text-[#64748b] block mb-1.5 font-bold">
                      Tools & Stack:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {day.tools.map((tool, idx) => (
                        <span
                          key={idx}
                          className="font-mono text-[0.62rem] px-2 py-0.5 rounded bg-[#16192a] border border-[#2b314a] text-[#cbd5e1]"
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Objectives */}
                  <div>
                    <span className="font-mono text-[0.6rem] uppercase tracking-[0.15em] text-[#00ff9d] block mb-1.5 font-bold">
                      Learning Objectives:
                    </span>
                    <ul className="space-y-1.5 text-[0.78rem] text-[#cbd5e1]">
                      {day.objectives.map((obj, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="font-mono text-[0.62rem] text-[#00f0ff] font-bold shrink-0 mt-0.5">
                            {String(idx + 1).padStart(2, '0')}
                          </span>
                          <span>{obj}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

