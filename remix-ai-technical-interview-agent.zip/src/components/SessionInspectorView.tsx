import React from 'react';
import { Activity, Sparkles, BrainCircuit, Terminal } from 'lucide-react';
import { InterviewSessionState } from '../server/types';

interface SessionInspectorViewProps {
  session: InterviewSessionState | null;
}

export const SessionInspectorView: React.FC<SessionInspectorViewProps> = ({ session }) => {
  if (!session) {
    return (
      <div className="flex-1 bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-12 flex flex-col items-center justify-center text-center select-none backdrop-blur-xl relative">
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>
        <Activity className="w-10 h-10 text-[#00f0ff]/40 mb-3 animate-pulse" />
        <h3 className="font-display text-[1.4rem] font-bold text-white">No Active Session Found</h3>
        <p className="font-mono text-[0.75rem] text-[#94a3b8] max-w-sm mt-1">
          Start an interview session from the Live Interview or Candidate Roster tab to inspect session state in real-time.
        </p>
      </div>
    );
  }

  return (
    <div id="session-inspector-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Session Metadata Header */}
      <div className="bg-[#0c0d15]/90 p-5 border border-[#222538] rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-xl">
        <div>
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-1">
            Reasoning & Telemetry Trace
          </span>
          <div className="flex items-baseline gap-3">
            <h3 className="font-display text-[1.4rem] text-white font-bold tracking-tight">
              Session Inspector ({session.sessionId})
            </h3>
            <span className="font-mono text-[0.65rem] uppercase tracking-wider bg-emerald-500/20 text-[#00ff9d] border border-emerald-500/40 px-2 py-0.5 rounded font-bold shadow-[0_0_8px_rgba(0,255,157,0.3)]">
              {session.status}
            </span>
          </div>
          <p className="font-mono text-[0.7rem] text-[#94a3b8] mt-0.5">
            Candidate: <span className="text-white font-semibold">{session.candidate.member.name}</span> ({session.candidate.member.jobRole})
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-[0.72rem]">
          <span className="border border-[#00f0ff]/40 px-3 py-1 bg-[#00f0ff]/10 text-[#00f0ff] rounded-lg font-bold">
            {session.questionCount} Questions
          </span>
          <span className="border border-[#a855f7]/40 px-3 py-1 bg-[#a855f7]/10 text-[#d8b4fe] rounded-lg font-bold">
            {session.curriculumDaysCovered.length} Days Covered
          </span>
        </div>
      </div>

      {/* Two Column Layout: Left (Turns), Right (Evaluations) */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-5 overflow-hidden relative">
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        {/* Left: Chronological Turns */}
        <div className="bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-5 overflow-y-auto space-y-4 backdrop-blur-xl shadow-2xl relative z-10">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-2">
            Conversation Turns ({session.conversationHistory.length})
          </span>
          {session.conversationHistory.map((turn, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-xl border ${
                turn.role === 'interviewer'
                  ? 'bg-[#121422] border-[#00f0ff]/30 shadow-[0_0_15px_rgba(0,240,255,0.1)]'
                  : 'bg-[#161828]/80 border-[#2b3048]'
              }`}
            >
              <div className="flex items-center justify-between mb-2 font-mono text-[0.65rem] uppercase">
                <span
                  className={`font-bold px-2 py-0.5 rounded ${
                    turn.role === 'interviewer'
                      ? 'bg-[#00f0ff]/20 text-[#00f0ff]'
                      : 'bg-[#ff007f]/20 text-[#ff007f]'
                  }`}
                >
                  [{String(idx + 1).padStart(2, '0')}] {turn.role}
                </span>
                {turn.curriculumDay && (
                  <span className="text-[#a855f7] bg-[#a855f7]/10 px-2 py-0.5 rounded border border-[#a855f7]/20">
                    Day {turn.curriculumDay}: {turn.topic}
                  </span>
                )}
              </div>
              <p
                className={
                  turn.role === 'interviewer'
                    ? 'font-serif text-[1.02rem] leading-relaxed text-[#f8fafc]'
                    : 'font-sans text-[0.88rem] leading-relaxed text-[#cbd5e1]'
                }
              >
                {turn.content}
              </p>
            </div>
          ))}
        </div>

        {/* Right: Answer Evaluations */}
        <div className="bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-5 overflow-y-auto space-y-4 backdrop-blur-xl shadow-2xl relative z-10">
          <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold block mb-2">
            Answer Evaluations & Critique Log ({session.answerEvaluations.length})
          </span>
          {session.answerEvaluations.length === 0 ? (
            <div className="border border-dashed border-[#222538] rounded-xl p-8 text-center font-sans italic text-[#64748b] text-[0.85rem]">
              No answer evaluations recorded yet. Respond to questions in Live Interview to generate real-time evaluations.
            </div>
          ) : (
            session.answerEvaluations.map((evalItem, idx) => (
              <div key={idx} className="p-4 bg-[#10121d] border border-[#222538] rounded-xl space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between font-mono text-[0.72rem]">
                  <span className="font-bold text-[#f8fafc]">
                    Turn {idx + 1}: Day {evalItem.curriculumDay} ({evalItem.topic})
                  </span>
                  <span className="bg-emerald-500/20 text-[#00ff9d] border border-emerald-500/40 px-2 py-0.5 rounded font-bold shadow-[0_0_8px_rgba(0,255,157,0.3)]">
                    Score: {evalItem.score} / 10
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 py-1.5 font-mono text-[0.65rem] border-y border-[#222538] text-[#cbd5e1]">
                  <div>Correctness: <strong className="text-[#00f0ff]">{Math.round(evalItem.correctness * 100)}%</strong></div>
                  <div>Depth: <strong className="text-[#a855f7]">{Math.round(evalItem.depth * 100)}%</strong></div>
                  <div>Clarity: <strong className="text-[#00ff9d]">{Math.round(evalItem.clarity * 100)}%</strong></div>
                </div>

                <p className="font-serif italic text-[0.92rem] text-[#cbd5e1] leading-relaxed">
                  "{evalItem.critique}"
                </p>

                {evalItem.missingConcepts && evalItem.missingConcepts.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1 font-mono text-[0.62rem]">
                    <span className="text-[#64748b]">Missing:</span>
                    {evalItem.missingConcepts.map((c, i) => (
                      <span key={i} className="border border-[#ffbe0b]/30 px-1.5 py-0.5 rounded bg-[#ffbe0b]/10 text-[#ffbe0b]">
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

