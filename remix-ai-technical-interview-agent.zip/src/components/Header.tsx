import React from 'react';
import { ChevronDown, RefreshCw, BrainCircuit, Terminal, Sparkles } from 'lucide-react';
import { CandidateProfile } from '../server/types';

interface HeaderProps {
  candidates: CandidateProfile[];
  selectedCandidate: CandidateProfile | null;
  onSelectCandidate: (candidate: CandidateProfile) => void;
  onResetSession: () => void;
  isAiLiveMode: boolean;
  setIsAiLiveMode: (live: boolean) => void;
  onOpenTestRunner: () => void;
  activeTabTitle: string;
}

export const Header: React.FC<HeaderProps> = ({
  candidates,
  selectedCandidate,
  onSelectCandidate,
  onResetSession,
  isAiLiveMode,
  setIsAiLiveMode,
  onOpenTestRunner,
  activeTabTitle,
}) => {
  return (
    <header className="px-6 md:px-8 py-4 border-b border-[#222538] flex flex-wrap justify-between items-center gap-4 bg-[#0c0d14]/80 backdrop-blur-xl select-none relative z-20">
      {/* Title with subtle gradient / glowing accent */}
      <div className="flex items-center gap-3">
        <h2 className="font-display text-[1.4rem] md:text-[1.65rem] font-bold text-white tracking-tight flex items-center gap-2">
          <span>{activeTabTitle || 'Technical Assessment Console'}</span>
        </h2>
      </div>

      {/* Action Controls & Candidate Selector */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Candidate Selector with dark glass background */}
        <div className="relative flex items-center">
          <select
            id="header-candidate-select"
            value={selectedCandidate?.member.id || ''}
            onChange={(e) => {
              const found = candidates.find((c) => c.member.id === e.target.value);
              if (found) onSelectCandidate(found);
            }}
            className="font-mono text-[0.75rem] border border-[#222538] pl-3 pr-8 py-1.5 bg-[#121420] text-[#f8fafc] rounded-lg cursor-pointer appearance-none outline-none focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] shadow-sm hover:border-[#3b4260] transition-colors"
          >
            {candidates.map((c) => (
              <option key={c.member.id} value={c.member.id} className="bg-[#0f1019] text-[#f8fafc]">
                {c.member.id}: {c.member.name} ({c.member.jobRole})
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-[#00f0ff] absolute right-2.5 pointer-events-none" />
        </div>

        {/* AI Mode Toggle with vibrant neon pulse */}
        <button
          id="btn-ai-mode-toggle"
          onClick={() => setIsAiLiveMode(!isAiLiveMode)}
          className={`font-mono text-[0.7rem] font-bold uppercase tracking-wider border px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
            isAiLiveMode
              ? 'bg-emerald-500/15 border-emerald-500/60 text-[#00ff9d] shadow-[0_0_12px_rgba(0,255,157,0.25)]'
              : 'bg-[#121420] border-[#222538] text-[#94a3b8] hover:text-white'
          }`}
          title="Toggle Gemini API Live Mode"
        >
          <BrainCircuit className="w-3.5 h-3.5 text-[#00ff9d]" />
          <span>Gemini: {isAiLiveMode ? 'LIVE ENGINE' : 'MOCK'}</span>
        </button>

        {/* Run Tests Button in vibrant purple/cyan */}
        <button
          id="btn-header-tests"
          onClick={onOpenTestRunner}
          className="font-mono text-[0.7rem] font-bold uppercase tracking-wider border border-[#a855f7]/40 px-3 py-1.5 rounded-lg bg-[#a855f7]/10 text-[#d8b4fe] hover:bg-[#a855f7]/25 hover:border-[#a855f7] flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_10px_rgba(168,85,247,0.15)]"
          title="Run Automated Test Suite"
        >
          <Terminal className="w-3.5 h-3.5 text-[#c084fc]" />
          <span className="hidden sm:inline">Run Tests</span>
        </button>

        {/* Reset Session in electric cyan */}
        <button
          id="btn-header-reset"
          onClick={onResetSession}
          className="font-mono text-[0.7rem] font-bold uppercase tracking-wider border border-cyan-400 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] hover:from-[#38bdf8] hover:to-[#00f0ff] flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,240,255,0.4)]"
          title="Start Fresh Interview Session"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>New Session</span>
        </button>
      </div>
    </header>
  );
};

