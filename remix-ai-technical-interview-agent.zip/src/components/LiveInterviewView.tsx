import React, { useState, useRef, useEffect } from 'react';
import { CheckCircle2, Zap, Sparkles, Send, BrainCircuit, Activity } from 'lucide-react';
import {
  CandidateProfile,
  InterviewSessionState,
  AnswerEvaluation,
} from '../server/types';
import { CurriculumService } from '../server/curriculumService';

interface LiveInterviewViewProps {
  session: InterviewSessionState | null;
  candidate: CandidateProfile;
  onSendMessage: (message: string) => Promise<void>;
  isLoading: boolean;
  onViewFeedback: () => void;
}

export const LiveInterviewView: React.FC<LiveInterviewViewProps> = ({
  session,
  candidate,
  onSendMessage,
  isLoading,
  onViewFeedback,
}) => {
  const [inputText, setInputText] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.conversationHistory, isLoading]);

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;
    const msg = inputText.trim();
    setInputText('');
    await onSendMessage(msg);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Preset realistic candidate answers for rapid simulation
  const quickAnswerPresets = [
    {
      title: 'Strong Technical',
      text: 'In our pipeline, we generated 384-dimensional dense vectors using Sentence Transformers (all-MiniLM-L6-v2) across 512-token chunks with 50-token overlap. For similarity, we used cosine distance in ChromaDB with HNSW indexing, and paired it with an SQLite query router for structured claims metadata lookups before passing the top-5 re-ranked chunks to the LLM at 0.2 temperature.',
    },
    {
      title: 'Partial / Incomplete',
      text: 'Vector databases store embeddings and we used ChromaDB to search documents and retrieve them for our chatbot.',
    },
    {
      title: 'Weak / Vague',
      text: 'We just used AI to answer questions from the dataset without writing much code.',
    },
    {
      title: 'MCP / Multi-Agent',
      text: 'On Day 22 and 23, we decoupled our healthcare tools into an MCP server with JSON-RPC schemas. The coordinator agent delegates between a claims specialist and a triage specialist. The trade-off is a 200ms latency overhead for tool negotiation versus clean modularity.',
    },
  ];

  const currentDayData = session?.currentDay
    ? CurriculumService.getDay(session.currentDay)
    : CurriculumService.getDay(7);

  const latestEval: AnswerEvaluation | undefined =
    session?.answerEvaluations && session.answerEvaluations.length > 0
      ? session.answerEvaluations[session.answerEvaluations.length - 1]
      : undefined;

  return (
    <div id="live-interview-workspace" className="flex-1 grid grid-cols-1 lg:grid-cols-[1fr_330px] gap-6 overflow-hidden min-h-0 relative z-10">
      {/* Left: Interview Canvas */}
      <div className="flex flex-col bg-[#0c0d15]/90 border border-[#222538] rounded-xl overflow-hidden backdrop-blur-xl relative shadow-2xl">
        {/* Virtual Background Watermark inside tab */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[15vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        {/* Canvas Header */}
        <div className="px-5 py-3.5 bg-[#10121d] border-b border-[#222538] flex justify-between items-center select-none relative z-10">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00f0ff] shadow-[0_0_8px_#00f0ff]" />
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.15em] text-[#00f0ff] font-bold">
              SESSION: {session?.sessionId || `session-${candidate.member.id.toLowerCase()}`}
            </span>
          </div>
          <div className="flex items-center gap-3">
            {session?.status === 'completed' ? (
              <button
                id="btn-view-feedback-banner"
                onClick={onViewFeedback}
                className="font-mono text-[0.68rem] font-bold uppercase tracking-wider px-3 py-1.5 bg-gradient-to-r from-[#00ff9d] to-[#10b981] text-[#07070a] rounded-lg shadow-[0_0_12px_rgba(0,255,157,0.4)] hover:brightness-110 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#07070a]" />
                <span>View Evaluation Report</span>
              </button>
            ) : (
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.15em] px-2.5 py-1 rounded bg-[#00ff9d]/10 border border-[#00ff9d]/30 text-[#00ff9d] flex items-center gap-1.5 font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00ff9d] animate-ping" />
                EXAMINER ACTIVE
              </span>
            )}
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-6 md:p-7 overflow-y-auto space-y-6 relative z-10">
          {session?.conversationHistory.map((turn, index) => {
            const isInterviewer = turn.role === 'interviewer';
            const turnNum = String(Math.floor(index / 2) + 1).padStart(2, '0');

            return (
              <div
                key={index}
                className={`p-4 rounded-xl transition-all border ${
                  isInterviewer
                    ? 'bg-[#121422] border-[#00f0ff]/30 shadow-[0_4px_20px_rgba(0,0,0,0.4)]'
                    : 'bg-[#161828]/80 border-[#2b3048] ml-4 md:ml-8'
                }`}
              >
                {/* Block Label */}
                <div className="mb-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-mono text-[0.62rem] uppercase font-bold tracking-wider px-2 py-0.5 rounded ${
                        isInterviewer
                          ? 'bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/30'
                          : 'bg-[#ff007f]/15 text-[#ff007f] border border-[#ff007f]/30'
                      }`}
                    >
                      {isInterviewer
                        ? `NOVA MIND AGENT [${turnNum}]`
                        : `CANDIDATE: ${candidate.member.name} [${turnNum}]`}
                    </span>
                    {turn.curriculumDay && (
                      <span className="font-mono text-[0.6rem] text-[#a855f7] bg-[#a855f7]/10 px-2 py-0.5 rounded border border-[#a855f7]/20">
                        Day {turn.curriculumDay} • {turn.topic || 'Core Concept'}
                      </span>
                    )}
                  </div>
                  <span className="font-mono text-[0.6rem] text-[#64748b]">
                    {new Date(turn.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Text Content */}
                <div
                  className={
                    isInterviewer
                      ? 'font-serif text-[1.1rem] leading-[1.65] text-[#f8fafc] font-medium'
                      : 'font-sans text-[0.92rem] leading-relaxed text-[#cbd5e1]'
                  }
                >
                  {turn.content}
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="p-4 rounded-xl bg-[#121422] border border-[#00f0ff]/40 shadow-[0_0_20px_rgba(0,240,255,0.15)] animate-pulse">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-mono text-[0.62rem] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40">
                  NOVA MIND REASONING TRACE
                </span>
                <BrainCircuit className="w-3.5 h-3.5 text-[#00f0ff] animate-spin" />
              </div>
              <div className="font-serif italic text-[1.05rem] text-[#94a3b8]">
                Analyzing candidate response against curriculum benchmarks & synthesizing follow-up...
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Response Tray with Quick Presets */}
        <div className="p-5 border-t border-[#222538] bg-[#0e101b] relative z-10">
          <div className="flex items-center justify-between mb-2.5">
            <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold">
              Simulation Presets
            </span>
            <span className="font-mono text-[0.6rem] text-[#64748b]">
              Click to load test payload
            </span>
          </div>

          <div className="flex flex-wrap gap-2 mb-3.5">
            {quickAnswerPresets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => setInputText(preset.text)}
                disabled={isLoading || session?.status === 'completed'}
                className="font-mono text-[0.66rem] px-2.5 py-1.5 rounded-md border border-[#262a40] bg-[#141624] text-[#cbd5e1] hover:border-[#00f0ff] hover:bg-[#00f0ff]/10 hover:text-[#00f0ff] transition-all cursor-pointer disabled:opacity-30"
              >
                {preset.title}
              </button>
            ))}
          </div>

          <div className="flex gap-3 items-end">
            <textarea
              id="interview-answer-input"
              rows={2}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading || session?.status === 'completed'}
              placeholder={
                session?.status === 'completed'
                  ? 'Interview completed. Click "View Evaluation Report" above.'
                  : 'Type candidate technical response or select a preset above...'
              }
              className="flex-1 border border-[#262a40] rounded-xl px-4 py-2.5 font-sans text-[0.92rem] outline-none bg-[#121422] text-[#f8fafc] placeholder:text-[#64748b] placeholder:italic resize-none focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] transition-all shadow-inner"
            />
            <button
              id="btn-send-answer"
              onClick={handleSend}
              disabled={!inputText.trim() || isLoading || session?.status === 'completed'}
              className="bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] px-6 py-3.5 rounded-xl font-mono text-[0.72rem] font-black uppercase tracking-wider hover:brightness-110 shadow-[0_0_15px_rgba(0,240,255,0.4)] transition-all disabled:opacity-20 cursor-pointer shrink-0 flex items-center gap-1.5"
            >
              <span>SUBMIT</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Right: Sidebar Info Pane */}
      <div className="flex flex-col gap-5 overflow-y-auto select-none relative z-10">
        {/* Curriculum Focus Section */}
        <div className="bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-5 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#ff007f] font-bold">
              Curriculum Grounding
            </span>
            <span className="font-mono text-[0.62rem] px-2 py-0.5 rounded bg-[#ff007f]/10 text-[#ff007f] border border-[#ff007f]/20 font-bold">
              Day {session?.currentDay || 7}
            </span>
          </div>
          <h3 className="font-display text-[1.25rem] font-bold text-white mb-2">
            {currentDayData?.title || 'Embeddings Explained'}
          </h3>
          <p className="text-[0.82rem] leading-relaxed text-[#94a3b8] mb-3">
            Focusing on vector transformations, chunking strategies, and retrieval mechanics within AI-core applications.
          </p>

          <div className="pt-3 border-t border-[#222538]">
            <span className="font-mono text-[0.6rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block mb-2">
              Key Objectives
            </span>
            <div className="space-y-2">
              {currentDayData?.objectives ? (
                currentDayData.objectives.slice(0, 3).map((obj, idx) => (
                  <div key={idx} className="flex gap-2.5 text-[0.78rem] text-[#cbd5e1]">
                    <span className="font-mono text-[0.65rem] text-[#00f0ff] font-bold shrink-0 mt-0.5">
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{obj}</span>
                  </div>
                ))
              ) : (
                <>
                  <div className="flex gap-2.5 text-[0.78rem] text-[#cbd5e1]">
                    <span className="font-mono text-[0.65rem] text-[#00f0ff] font-bold shrink-0">01</span>
                    <span>Text to vector conversion mechanics</span>
                  </div>
                  <div className="flex gap-2.5 text-[0.78rem] text-[#cbd5e1]">
                    <span className="font-mono text-[0.65rem] text-[#00f0ff] font-bold shrink-0">02</span>
                    <span>Knowledge base chunking strategies</span>
                  </div>
                  <div className="flex gap-2.5 text-[0.78rem] text-[#cbd5e1]">
                    <span className="font-mono text-[0.65rem] text-[#00f0ff] font-bold shrink-0">03</span>
                    <span>Embedding storage & retrieval logic</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Live Evaluator Box */}
        {latestEval ? (
          <div className="bg-[#0c0d15]/90 border border-[#222538] rounded-xl p-5 backdrop-blur-xl shadow-xl space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold">
                Latest Evaluation
              </span>
              <span className="font-mono text-[0.82rem] font-bold px-2 py-0.5 rounded bg-[#00ff9d]/10 text-[#00ff9d] border border-[#00ff9d]/30">
                {latestEval.score} / 10
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-[0.75rem] font-mono border-y border-[#222538] py-2.5">
              <div>
                <span className="text-[#64748b] block text-[0.6rem]">Correctness</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-bold text-white">{Math.round(latestEval.correctness * 100)}%</span>
                  <div className="flex-1 bg-[#1a1c2b] h-1 rounded-full overflow-hidden">
                    <div className="h-full bg-[#00f0ff]" style={{ width: `${latestEval.correctness * 100}%` }} />
                  </div>
                </div>
              </div>
              <div>
                <span className="text-[#64748b] block text-[0.6rem]">Depth</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-bold text-white">{Math.round(latestEval.depth * 100)}%</span>
                  <div className="flex-1 bg-[#1a1c2b] h-1 rounded-full overflow-hidden">
                    <div className="h-full bg-[#a855f7]" style={{ width: `${latestEval.depth * 100}%` }} />
                  </div>
                </div>
              </div>
            </div>

            <p className="text-[0.82rem] font-sans italic leading-relaxed text-[#cbd5e1]">
              "{latestEval.critique}"
            </p>
          </div>
        ) : (
          <div className="bg-[#0c0d15]/50 border border-dashed border-[#222538] rounded-xl p-6 text-center text-[0.78rem] italic text-[#64748b] flex flex-col items-center justify-center min-h-[140px] gap-2">
            <Activity className="w-5 h-5 text-[#64748b]/40" />
            <span>Live performance data will stream once the candidate provides an answer.</span>
          </div>
        )}
      </div>
    </div>
  );
};

