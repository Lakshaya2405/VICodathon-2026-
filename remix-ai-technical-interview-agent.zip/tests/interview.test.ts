import { InterviewController } from '../src/server/interviewController';
import { CandidateService } from '../src/server/candidateService';
import { interviewStateManager } from '../src/server/interviewState';
import { CurriculumService } from '../src/server/curriculumService';

async function runTests() {
  console.log('====================================================');
  console.log('🚀 RUNNING AI TECHNICAL INTERVIEW AGENT TEST SUITE');
  console.log('====================================================\n');

  let passedTests = 0;
  let totalTests = 0;

  function assert(condition: boolean, testName: string, details?: string) {
    totalTests++;
    if (condition) {
      console.log(`[PASS] ${testName}`);
      passedTests++;
    } else {
      console.error(`[FAIL] ${testName}`);
      if (details) console.error(`       Details: ${details}`);
    }
  }

  // TEST 1: Curriculum and Candidates Loading
  const candidates = CandidateService.getAllCandidates();
  assert(candidates.length === 20, 'Curriculum & Candidates Loader: 20 candidate profiles loaded');

  const curriculum = CurriculumService.getCurriculum();
  assert(curriculum.days.length === 31, 'Curriculum Loader: 31 curriculum days loaded across 8 modules');

  // TEST 2: Start Interview Session for Candidate 1 (Sarah Johnson)
  const candidate1 = CandidateService.getCandidateById('CAND-001')!;
  const sessionId1 = 'test-session-sarah-001';

  const startRes1 = await InterviewController.handleInterview({
    sessionId: sessionId1,
    candidate: candidate1,
  });

  assert(startRes1.status === 200, 'Start Interview: Returns HTTP 200');
  assert(
    'reply' in startRes1.data && typeof startRes1.data.reply === 'string' && startRes1.data.reply.length > 10,
    'Start Interview: Returns conversational reply greeting'
  );
  assert(
    'done' in startRes1.data && startRes1.data.done === false,
    'Start Interview: done is false on start'
  );

  // TEST 3: Multi-turn Interview Execution (8+ questions, 4+ curriculum days)
  const sampleAnswers = [
    'For our embeddings, we used Sentence Transformers with all-MiniLM-L6-v2, producing 384-dimensional vectors. We computed cosine similarity to find relevant healthcare chunks.',
    'ChromaDB served as our local vector database with HNSW indexing and metadata filtering by plan type and section. We used SQLite alongside for structured plan limits.',
    'Our query router determines if the query contains structured filter terms. If so, it queries SQLite, otherwise it sends to ChromaDB vector search and merges ranked results.',
    'In our RAG pipeline, we grounded the prompt with retrieved chunks and set temperature to 0.2 to prevent medical hallucinations.',
    'We used system prompt guardrails with clear XML delimiters and few-shot examples of clinical tone to prevent prompt injection.',
    'FastAPI /chat endpoint manages session history in SQLite, truncating or summarizing conversation context when approaching token limits.',
    'For multi-agent orchestration, we used a router agent to delegate to a billing specialist agent and a claims triage agent.',
    'We exposed our healthcare tools through an MCP server using JSON-RPC tools for Claude Desktop to inspect plan benefits.',
    'We containerized the backend with Docker, configuring Kubernetes readiness probes and Prometheus metrics for latency observability.',
    'Our Capstone project integrated hybrid retrieval, MCP tools, and containerized deployment with 99.9% uptime architecture.',
  ];

  let currentTurn = 1;
  let lastResponse: any = null;

  for (const answer of sampleAnswers) {
    const turnRes = await InterviewController.handleInterview({
      sessionId: sessionId1,
      message: answer,
    });

    assert(turnRes.status === 200, `Conversation Turn ${currentTurn}: Returns HTTP 200`);
    lastResponse = turnRes.data;

    if (lastResponse.done) {
      console.log(`\n🎉 Interview Session ${sessionId1} finished at turn ${currentTurn}!`);
      break;
    }
    currentTurn++;
  }

  // TEST 4: Verification of 8+ Questions and 4+ Curriculum Days
  const session1State = interviewStateManager.getSession(sessionId1);
  assert(
    session1State !== undefined && session1State.questionCount >= 8,
    `Question Count Guarantee: Asked ${session1State?.questionCount || 0} questions (>= 8 required)`
  );
  assert(
    session1State !== undefined && session1State.curriculumDaysCovered.length >= 4,
    `Curriculum Coverage Guarantee: Covered ${session1State?.curriculumDaysCovered.length || 0} distinct days (>= 4 required)`
  );

  // TEST 5: Final Structured Feedback Validation
  assert(
    lastResponse && lastResponse.done === true && lastResponse.feedback !== undefined,
    'End Interview: Returns done: true with structured feedback'
  );
  assert(
    typeof lastResponse?.feedback?.summary === 'string' && lastResponse.feedback.summary.length > 20,
    'Feedback Format: summary is a non-empty string'
  );
  assert(
    Array.isArray(lastResponse?.feedback?.strengths) && lastResponse.feedback.strengths.length > 0,
    'Feedback Format: strengths is a non-empty array'
  );
  assert(
    Array.isArray(lastResponse?.feedback?.gaps) && lastResponse.feedback.gaps.length > 0,
    'Feedback Format: gaps is a non-empty array'
  );
  assert(
    Array.isArray(lastResponse?.feedback?.next) && lastResponse.feedback.next.length > 0,
    'Feedback Format: next is a non-empty array of actionable steps'
  );

  // TEST 6: Candidate Personalization Comparison (CAND-001 vs CAND-011)
  const candidate2 = CandidateService.getCandidateById('CAND-011')!; // Mia Alvarez (UX Researcher, skipped vector dbs & agents)
  const sessionId2 = 'test-session-mia-011';

  const startRes2 = await InterviewController.handleInterview({
    sessionId: sessionId2,
    candidate: candidate2,
  });

  const reply1 = startRes1.data && 'reply' in startRes1.data ? startRes1.data.reply : '';
  const reply2 = startRes2.data && 'reply' in startRes2.data ? startRes2.data.reply : '';

  assert(
    reply1 !== reply2 && reply2.includes('Mia Alvarez'),
    'Candidate Personalization: Interview greetings and opening trajectory differ across candidates'
  );

  // TEST 7: Error Handling & Invalid Requests
  const errRes1 = await InterviewController.handleInterview(null);
  assert(errRes1.status === 400, 'Error Handling: Null body returns HTTP 400');

  const errRes2 = await InterviewController.handleInterview({ message: 'Hello without session' });
  assert(errRes2.status === 400, 'Error Handling: Missing sessionId returns HTTP 400');

  const errRes3 = await InterviewController.handleInterview({ sessionId: 'non-existent-session-id', message: 'Hello' });
  assert(errRes3.status === 404, 'Error Handling: Non-existent sessionId returns HTTP 404');

  console.log('\n====================================================');
  console.log(`📊 TEST SUITE SUMMARY: ${passedTests}/${totalTests} PASSED`);
  console.log('====================================================\n');

  if (passedTests === totalTests) {
    console.log('✅ ALL TESTS PASSED SUCCESSFULLY!');
  } else {
    console.error('❌ SOME TESTS FAILED');
    process.exit(1);
  }
}

runTests().catch((e) => {
  console.error('Unhandled test failure:', e);
  process.exit(1);
});
