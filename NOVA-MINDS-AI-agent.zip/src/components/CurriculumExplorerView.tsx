import React, { useState } from 'react';
import { BookOpen, Layers, Sparkles, Filter, CheckCircle } from 'lucide-react';
import { CurriculumService } from '../server/curriculumService';
import { useTheme } from '../theme/ThemeContext';

export const CurriculumExplorerView: React.FC = () => {
  const { currentTheme } = useTheme();
  const curriculum = CurriculumService.getCurriculum();
  const [selectedModule, setSelectedModule] = useState<number | 'ALL'>('ALL');

  const filteredDays = curriculum.days.filter((d) => {
    if (selectedModule === 'ALL') return true;
    const mod = curriculum.modules.find((m) => m.n === selectedModule);
    if (!mod) return true;
    return d.day >= mod.days[0] && d.day <= mod.days[1];
  });

  return (
    <div id="curriculum-explorer-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Header */}
      <div
        className="p-5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-md border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div>
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            Curriculum Grounding Matrix
          </span>
          <h3
            className="font-display text-[1.4rem] font-bold tracking-tight"
            style={{ color: currentTheme.colors.ink }}
          >
            31-Day Syllabus & Assessment Benchmarks
          </h3>
        </div>

        {/* Module Filter */}
        <div className="flex items-center gap-3">
          <span
            className="font-mono text-[0.68rem] uppercase tracking-wider"
            style={{ color: currentTheme.colors.inkMuted }}
          >
            Filter Module:
          </span>
          <select
            value={selectedModule}
            onChange={(e) => {
              const val = e.target.value;
              setSelectedModule(val === 'ALL' ? 'ALL' : Number(val));
            }}
            className="px-3 py-1.5 rounded-lg font-mono text-[0.72rem] font-bold cursor-pointer outline-none transition-all border"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.neonCyan,
            }}
          >
            <option
              value="ALL"
              style={{ backgroundColor: currentTheme.colors.bgCard, color: currentTheme.colors.ink }}
            >
              All 8 Modules (Days 1-31)
            </option>
            {curriculum.modules.map((m) => (
              <option
                key={m.n}
                value={m.n}
                style={{ backgroundColor: currentTheme.colors.bgCard, color: currentTheme.colors.ink }}
              >
                Module {m.n}: {m.title} (Days {m.days[0]}-{m.days[1]})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Curriculum Grid with Virtual Background Watermark */}
      <div
        className="flex-1 rounded-xl overflow-y-auto p-6 backdrop-blur-xl shadow-xl relative border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        {/* Ambient watermark inside curriculum */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 relative z-10">
          {filteredDays.map((day) => {
            const mod = curriculum.modules.find(
              (m) => day.day >= m.days[0] && day.day <= m.days[1]
            );

            return (
              <div
                key={day.day}
                className="rounded-xl p-5 flex flex-col justify-between transition-all shadow-md group border"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="font-mono font-bold text-[0.72rem] px-2.5 py-0.5 rounded shadow-sm"
                      style={{
                        background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`,
                        color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                        boxShadow: `0 0 10px ${currentTheme.colors.primaryGlow}`,
                      }}
                    >
                      Day {day.day}
                    </span>
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold tracking-wider px-2 py-0.5 rounded border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonMagenta}18`,
                        borderColor: `${currentTheme.colors.neonMagenta}33`,
                        color: currentTheme.colors.neonMagenta,
                      }}
                    >
                      {day.type}
                    </span>
                  </div>

                  <h4
                    className="font-display text-[1.18rem] font-bold mb-1 leading-snug transition-colors"
                    style={{ color: currentTheme.colors.ink }}
                  >
                    {day.title}
                  </h4>
                  <p
                    className="font-mono text-[0.65rem] mb-4"
                    style={{ color: currentTheme.colors.neonPurple }}
                  >
                    Module {mod?.n || ''}: {mod?.title || ''}
                  </p>

                  {/* Tools */}
                  <div className="mb-4">
                    <span
                      className="font-mono text-[0.6rem] uppercase tracking-[0.15em] block mb-1.5 font-bold"
                      style={{ color: currentTheme.colors.inkFaint }}
                    >
                      Tools & Stack:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {day.tools.map((tool, idx) => (
                        <span
                          key={idx}
                          className="font-mono text-[0.62rem] px-2 py-0.5 rounded border"
                          style={{
                            backgroundColor: currentTheme.colors.bgSurface,
                            borderColor: currentTheme.colors.borderDark,
                            color: currentTheme.colors.inkMuted,
                          }}
                        >
                          {tool}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Objectives */}
                  <div>
                    <span
                      className="font-mono text-[0.6rem] uppercase tracking-[0.15em] block mb-1.5 font-bold"
                      style={{ color: currentTheme.colors.neonEmerald }}
                    >
                      Learning Objectives:
                    </span>
                    <ul className="space-y-1.5 text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
                      {day.objectives.map((obj, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span
                            className="font-mono text-[0.62rem] font-bold shrink-0 mt-0.5"
                            style={{ color: currentTheme.colors.neonCyan }}
                          >
                            {String(idx + 1).padStart(2, '0')}
                          </span>
                          <span>{obj}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
