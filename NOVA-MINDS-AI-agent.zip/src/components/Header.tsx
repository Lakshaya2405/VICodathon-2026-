import React from 'react';
import {
  ChevronDown,
  RefreshCw,
  BrainCircuit,
  Terminal,
  Palette,
  FileText,
  Menu,
  Sparkles,
} from 'lucide-react';
import { CandidateProfile } from '../server/types';
import { useTheme } from '../theme/ThemeContext';

interface HeaderProps {
  candidates: CandidateProfile[];
  selectedCandidate: CandidateProfile | null;
  onSelectCandidate: (candidate: CandidateProfile) => void;
  onResetSession: () => void;
  isAiLiveMode: boolean;
  setIsAiLiveMode: (live: boolean) => void;
  onOpenTestRunner: () => void;
  onOpenBeginnerGuide: () => void;
  onOpenCatchAllChats?: () => void;
  activeTabTitle: string;
  onToggleMobileMenu?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  candidates,
  selectedCandidate,
  onSelectCandidate,
  onResetSession,
  isAiLiveMode,
  setIsAiLiveMode,
  onOpenTestRunner,
  onOpenBeginnerGuide,
  onOpenCatchAllChats,
  activeTabTitle,
  onToggleMobileMenu,
}) => {
  const { currentTheme, presets, selectPreset, setIsThemeModalOpen, cycleNextTheme } = useTheme();

  return (
    <header
      className="px-3 sm:px-6 md:px-8 py-2.5 sm:py-3.5 border-b flex flex-wrap justify-between items-center gap-2.5 backdrop-blur-xl select-none relative z-20 transition-colors"
      style={{
        backgroundColor: `${currentTheme.colors.bgSurface}ee`,
        borderColor: currentTheme.colors.borderDark,
        color: currentTheme.colors.ink,
      }}
    >
      {/* Title & Mobile Hamburger Toggle */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        {/* Mobile Hamburger Button */}
        {onToggleMobileMenu && (
          <button
            id="btn-mobile-nav-toggle"
            onClick={onToggleMobileMenu}
            className="lg:hidden p-2 rounded-lg border flex items-center justify-center cursor-pointer transition-all hover:brightness-110 shrink-0"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.neonCyan,
            }}
            aria-label="Toggle Navigation Menu"
            title="Open Navigation Menu"
          >
            <Menu className="w-4 h-4" />
          </button>
        )}

        <div className="min-w-0">
          <h2
            className="font-display text-sm sm:text-base md:text-xl font-bold tracking-tight flex items-center gap-2 truncate"
            style={{ color: currentTheme.colors.ink }}
          >
            <span className="truncate">{activeTabTitle || 'Technical Assessment Console'}</span>
          </h2>
        </div>
      </div>

      {/* Action Controls, Theme Quick Switcher & Candidate Selector */}
      <div className="flex flex-wrap items-center gap-1.5 sm:gap-2.5">
        {/* Catch All Chats Button in Header */}
        {onOpenCatchAllChats && (
          <button
            id="btn-header-catch-all-chats"
            onClick={onOpenCatchAllChats}
            className="font-mono text-[0.68rem] sm:text-[0.7rem] font-black uppercase tracking-wider px-2 sm:px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-md group hover:brightness-110"
            style={{
              backgroundColor: `${currentTheme.colors.neonCyan}20`,
              borderColor: currentTheme.colors.neonCyan,
              borderWidth: '1px',
              color: currentTheme.colors.neonCyan,
              boxShadow: `0 0 12px ${currentTheme.colors.primaryGlow}`,
            }}
            title="Catch and export all chats and transcripts into a single file"
          >
            <FileText className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
            <span className="hidden md:inline">Catch All Chats</span>
            <span
              className="font-mono text-[0.58rem] px-1.5 py-0.2 rounded border font-bold"
              style={{
                backgroundColor: `${currentTheme.colors.neonEmerald}22`,
                borderColor: currentTheme.colors.neonEmerald,
                color: currentTheme.colors.neonEmerald,
              }}
            >
              1 FILE
            </span>
          </button>
        )}

        {/* Quick Theme Selector Dropdown */}
        <div className="relative hidden sm:flex items-center">
          <select
            id="header-theme-select"
            value={currentTheme.id}
            onChange={(e) => {
              if (e.target.value === '__open_modal__') {
                setIsThemeModalOpen(true);
              } else {
                selectPreset(e.target.value);
              }
            }}
            className="font-mono text-[0.7rem] sm:text-[0.72rem] pl-2 pr-6 py-1.5 rounded-lg cursor-pointer appearance-none outline-none font-bold transition-all shadow-sm"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              borderWidth: '1px',
              color: currentTheme.colors.neonCyan,
            }}
          >
            {presets.map((p) => (
              <option
                key={p.id}
                value={p.id}
                style={{ backgroundColor: currentTheme.colors.bgSurface, color: currentTheme.colors.ink }}
              >
                {p.name} {p.mode === 'light' ? '☀️' : '🌙'}
              </option>
            ))}
          </select>
          <ChevronDown
            className="w-3 h-3 absolute right-2 pointer-events-none"
            style={{ color: currentTheme.colors.neonCyan }}
          />
        </div>

        {/* Dynamic Theme Studio Button & Cycle Button */}
        <div className="flex items-center gap-1">
          <button
            id="btn-theme-studio"
            onClick={() => setIsThemeModalOpen(true)}
            className="font-mono text-[0.68rem] sm:text-[0.7rem] font-bold uppercase tracking-wider px-2.5 sm:px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-md group"
            style={{
              backgroundColor: `${currentTheme.colors.neonMagenta}18`,
              borderColor: currentTheme.colors.neonMagenta,
              borderWidth: '1px',
              color: currentTheme.colors.neonMagenta,
              boxShadow: `0 0 12px ${currentTheme.colors.secondaryGlow}`,
            }}
            title="Open Dynamic Theme Studio & AI Customizer"
          >
            <Palette className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline">Theme</span>
            <span
              className="w-2 h-2 rounded-full ml-0.5 shrink-0 shadow-sm border border-black/20"
              style={{ backgroundColor: currentTheme.colors.neonCyan }}
            />
          </button>

          {/* Quick Cycle Theme Button */}
          <button
            id="btn-quick-cycle-theme"
            onClick={cycleNextTheme}
            className="p-1.5 rounded-lg transition-all cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              borderWidth: '1px',
              color: currentTheme.colors.inkMuted,
            }}
            title="Quick Cycle Next Theme Preset"
          >
            <RefreshCw className="w-3.5 h-3.5 hover:rotate-180 transition-transform" />
          </button>
        </div>

        {/* Candidate Selector (Responsive) */}
        <div className="relative flex items-center">
          <select
            id="header-candidate-select"
            value={selectedCandidate?.member.id || ''}
            onChange={(e) => {
              const found = candidates.find((c) => c.member.id === e.target.value);
              if (found) onSelectCandidate(found);
            }}
            className="font-mono text-[0.68rem] sm:text-[0.72rem] pl-2 sm:pl-3 pr-6 sm:pr-8 py-1.5 rounded-lg cursor-pointer appearance-none outline-none transition-colors shadow-sm max-w-[125px] sm:max-w-[190px] md:max-w-[240px] truncate"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              borderWidth: '1px',
              color: currentTheme.colors.ink,
            }}
          >
            {candidates.map((c) => (
              <option
                key={c.member.id}
                value={c.member.id}
                style={{ backgroundColor: currentTheme.colors.bgSurface, color: currentTheme.colors.ink }}
              >
                {c.member.name} ({c.member.id})
              </option>
            ))}
          </select>
          <ChevronDown
            className="w-3 h-3 absolute right-2 pointer-events-none"
            style={{ color: currentTheme.colors.neonCyan }}
          />
        </div>

        {/* AI Mode Toggle with vibrant neon pulse */}
        <button
          id="btn-ai-mode-toggle"
          onClick={() => setIsAiLiveMode(!isAiLiveMode)}
          className="font-mono text-[0.68rem] sm:text-[0.7rem] font-bold uppercase tracking-wider px-2 sm:px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
          style={{
            backgroundColor: isAiLiveMode
              ? `${currentTheme.colors.neonEmerald}20`
              : currentTheme.colors.bgCard,
            borderColor: isAiLiveMode
              ? currentTheme.colors.neonEmerald
              : currentTheme.colors.borderDark,
            borderWidth: '1px',
            color: isAiLiveMode
              ? currentTheme.colors.neonEmerald
              : currentTheme.colors.inkMuted,
            boxShadow: isAiLiveMode
              ? `0 0 12px ${currentTheme.colors.neonEmerald}33`
              : 'none',
          }}
          title="Toggle Gemini API Live Mode"
        >
          <BrainCircuit className="w-3.5 h-3.5" style={{ color: isAiLiveMode ? currentTheme.colors.neonEmerald : currentTheme.colors.inkMuted }} />
          <span>{isAiLiveMode ? 'LIVE' : 'MOCK'}</span>
        </button>

        {/* Reset / New Session in electric cyan */}
        <button
          id="btn-header-reset"
          onClick={onResetSession}
          className="font-mono text-[0.68rem] sm:text-[0.7rem] font-bold uppercase tracking-wider px-2.5 sm:px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer font-black shrink-0"
          style={{
            background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonMagenta})`,
            color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
            boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
          }}
          title="Start Fresh Interview Session"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">New Session</span>
          <span className="sm:hidden">Reset</span>
        </button>
      </div>
    </header>
  );
};
