import React, { useState } from 'react';
import {
  BookOpen,
  HelpCircle,
  X,
  Code2,
  BrainCircuit,
  Award,
  Zap,
  Play,
  CheckCircle2,
  Layers,
  Sparkles,
  Terminal,
  FileCode,
  Users,
} from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';

interface BeginnerGuideModalProps {
  onClose: () => void;
  onOpenLiveInterview?: () => void;
  onOpenTestRunner?: () => void;
}

export const BeginnerGuideModal: React.FC<BeginnerGuideModalProps> = ({
  onClose,
  onOpenLiveInterview,
  onOpenTestRunner,
}) => {
  const { currentTheme } = useTheme();
  const [activeSection, setActiveSection] = useState<'overview' | 'api' | 'state' | 'scoring' | 'faq'>('overview');

  const guideSections = [
    { id: 'overview' as const, label: '1. How It Works', icon: HelpCircle },
    { id: 'api' as const, label: '2. API Contract', icon: Code2 },
    { id: 'state' as const, label: '3. State Machine', icon: BrainCircuit },
    { id: 'scoring' as const, label: '4. Scoring & Feedback', icon: Award },
    { id: 'faq' as const, label: '5. Beginner FAQ', icon: BookOpen },
  ];

  return (
    <div
      id="beginner-guide-modal-overlay"
      className="fixed inset-0 z-50 bg-[#000000]/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto select-none animate-in fade-in duration-200"
    >
      <div
        id="beginner-guide-modal-card"
        className="w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden rounded-2xl shadow-2xl relative border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
          boxShadow: `0 0 50px ${currentTheme.colors.primaryGlow}`,
        }}
      >
        {/* Ambient watermark inside guide */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[16vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        {/* Modal Header */}
        <div
          className="p-6 flex items-start justify-between border-b shrink-0 relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div>
            <div className="flex items-center gap-2 mb-1">
              <BookOpen className="w-4 h-4" style={{ color: currentTheme.colors.neonCyan }} />
              <span
                className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
                style={{ color: currentTheme.colors.neonCyan }}
              >
                Beginner's Guide & Architecture Manual
              </span>
            </div>
            <h3
              className="font-display text-[1.6rem] font-bold tracking-tight"
              style={{ color: currentTheme.colors.ink }}
            >
              How This Interview Agent is Built & Maintained
            </h3>
            <p
              className="font-mono text-[0.72rem] mt-1"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              A clear, step-by-step walkthrough of the data flow, backend API, scoring engine, and React components.
            </p>
          </div>

          <button
            id="btn-close-beginner-guide"
            onClick={onClose}
            className="p-1.5 rounded-lg border transition-colors cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.inkMuted,
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Section Navigation Tabs */}
        <div
          className="px-6 py-2.5 border-b flex items-center gap-2 overflow-x-auto relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgSurface,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          {guideSections.map((sec) => {
            const isActive = activeSection === sec.id;
            const Icon = sec.icon;
            return (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id)}
                className="px-3 py-1.5 rounded-lg font-mono text-[0.72rem] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 shrink-0 border"
                style={{
                  backgroundColor: isActive
                    ? `${currentTheme.colors.neonCyan}20`
                    : currentTheme.colors.bgCard,
                  borderColor: isActive
                    ? currentTheme.colors.neonCyan
                    : currentTheme.colors.borderDark,
                  color: isActive ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                  boxShadow: isActive ? `0 0 10px ${currentTheme.colors.primaryGlow}` : 'none',
                }}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{sec.label}</span>
              </button>
            );
          })}
        </div>

        {/* Section Content */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6 flex-1 relative z-10">
          {/* SECTION 1: OVERVIEW */}
          {activeSection === 'overview' && (
            <div className="space-y-6">
              <div
                className="p-5 rounded-xl border shadow-sm"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <h4
                  className="font-display text-[1.25rem] font-bold mb-2"
                  style={{ color: currentTheme.colors.ink }}
                >
                  High-Level System Architecture
                </h4>
                <p
                  className="font-sans text-[0.92rem] leading-relaxed mb-4"
                  style={{ color: currentTheme.colors.inkMuted }}
                >
                  This application simulates a realistic, curriculum-grounded technical interview for AI and machine learning candidates. The architecture is split cleanly into three simple layers:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}20`,
                        borderColor: `${currentTheme.colors.neonCyan}40`,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      1. Frontend (React + Vite)
                    </span>
                    <h5 className="font-bold text-[0.95rem] mb-1" style={{ color: currentTheme.colors.ink }}>
                      Interactive Workspace
                    </h5>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      Displays the live chat console, cohort candidate roster, curriculum matrix, session inspector, and developer test sandbox.
                    </p>
                  </div>

                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonPurple}20`,
                        borderColor: `${currentTheme.colors.neonPurple}40`,
                        color: currentTheme.colors.neonPurple,
                      }}
                    >
                      2. Backend Controller (Express)
                    </span>
                    <h5 className="font-bold text-[0.95rem] mb-1" style={{ color: currentTheme.colors.ink }}>
                      POST /api/interview
                    </h5>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      Handles the two official request types (Start Session vs Message Turn) and coordinates state transitions.
                    </p>
                  </div>

                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                        borderColor: `${currentTheme.colors.neonEmerald}40`,
                        color: currentTheme.colors.neonEmerald,
                      }}
                    >
                      3. AI Evaluation Engine
                    </span>
                    <h5 className="font-bold text-[0.95rem] mb-1" style={{ color: currentTheme.colors.ink }}>
                      Adaptive Intelligence
                    </h5>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      Grades answers against the 31-day curriculum, dynamically adjusts difficulty, and outputs structured strengths and gaps.
                    </p>
                  </div>
                </div>
              </div>

              {/* 3 Steps Flow */}
              <div
                className="p-5 rounded-xl border space-y-3"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <h4
                  className="font-display text-[1.18rem] font-bold"
                  style={{ color: currentTheme.colors.ink }}
                >
                  The Complete 3-Phase Interview Lifecycle
                </h4>
                <div className="space-y-3 font-sans text-[0.88rem]">
                  <div className="flex gap-3">
                    <span
                      className="font-mono font-black text-[0.72rem] w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}20`,
                        borderColor: currentTheme.colors.neonCyan,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      1
                    </span>
                    <div>
                      <strong style={{ color: currentTheme.colors.ink }}>Phase 1: Starting the Interview</strong>
                      <p style={{ color: currentTheme.colors.inkMuted }} className="text-[0.82rem] mt-0.5">
                        Client sends candidate info in <code className="font-mono text-[0.75rem] px-1 py-0.5 rounded bg-black/30">POST /api/interview</code>. The server initializes the state, loads the candidate's completed days, and asks Question 1.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span
                      className="font-mono font-black text-[0.72rem] w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonMagenta}20`,
                        borderColor: currentTheme.colors.neonMagenta,
                        color: currentTheme.colors.neonMagenta,
                      }}
                    >
                      2
                    </span>
                    <div>
                      <strong style={{ color: currentTheme.colors.ink }}>Phase 2: Multi-Turn Conversation & Live Grading</strong>
                      <p style={{ color: currentTheme.colors.inkMuted }} className="text-[0.82rem] mt-0.5">
                        Candidate submits answers. The Evaluator scores correctness, depth, and clarity, identifies missing concepts, and decides whether to ask a follow-up or move to a new curriculum day.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span
                      className="font-mono font-black text-[0.72rem] w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                        borderColor: currentTheme.colors.neonEmerald,
                        color: currentTheme.colors.neonEmerald,
                      }}
                    >
                      3
                    </span>
                    <div>
                      <strong style={{ color: currentTheme.colors.ink }}>Phase 3: Completion & Final Feedback Report</strong>
                      <p style={{ color: currentTheme.colors.inkMuted }} className="text-[0.82rem] mt-0.5">
                        Once at least 8 questions have been answered across at least 4 curriculum days, the server responds with <code className="font-mono text-[0.75rem] px-1 py-0.5 rounded bg-black/30">done: true</code> and structured feedback (summary, strengths, gaps, next steps).
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: API CONTRACT */}
          {activeSection === 'api' && (
            <div className="space-y-6">
              <div
                className="p-5 rounded-xl border shadow-sm space-y-4"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between">
                  <span
                    className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold"
                    style={{ color: currentTheme.colors.neonCyan }}
                  >
                    API Endpoint Specifications
                  </span>
                  <span
                    className="font-mono text-[0.65rem] px-2 py-0.5 rounded border"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                      borderColor: `${currentTheme.colors.neonEmerald}40`,
                      color: currentTheme.colors.neonEmerald,
                    }}
                  >
                    POST /api/interview
                  </span>
                </div>

                <p className="text-[0.88rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                  The backend has one primary JSON endpoint that handles both starting the session and sending answers. Here is what the JSON payloads look like:
                </p>

                {/* Request 1 */}
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <span className="font-mono text-[0.68rem] font-bold block mb-1.5" style={{ color: currentTheme.colors.neonCyan }}>
                    A) Start Request Payload (Initiates Session):
                  </span>
                  <pre
                    className="font-mono text-[0.72rem] p-3 rounded-lg overflow-x-auto"
                    style={{
                      backgroundColor: currentTheme.colors.bgCard,
                      color: currentTheme.colors.neonEmerald,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >{`{
  "sessionId": "session-sarah-101",
  "candidate": {
    "member": {
      "id": "CAND-01",
      "name": "Sarah Johnson",
      "jobRole": "Senior Data Engineer",
      "yearsExperience": 6
    },
    "missions": [
      { "day": 7, "title": "Embeddings Explained", "passed": true },
      { "day": 8, "title": "Vector Databases", "passed": true }
    ]
  }
}`}</pre>
                </div>

                {/* Request 2 */}
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <span className="font-mono text-[0.68rem] font-bold block mb-1.5" style={{ color: currentTheme.colors.neonMagenta }}>
                    B) Conversation Turn Payload (Candidate Answer):
                  </span>
                  <pre
                    className="font-mono text-[0.72rem] p-3 rounded-lg overflow-x-auto"
                    style={{
                      backgroundColor: currentTheme.colors.bgCard,
                      color: currentTheme.colors.neonPurple,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >{`{
  "sessionId": "session-sarah-101",
  "message": "We converted documents into 384-dim dense vectors using SentenceTransformers..."
}`}</pre>
                </div>

                {/* Response */}
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <span className="font-mono text-[0.68rem] font-bold block mb-1.5" style={{ color: currentTheme.colors.neonEmerald }}>
                    C) Server Response Payload (When Done):
                  </span>
                  <pre
                    className="font-mono text-[0.72rem] p-3 rounded-lg overflow-x-auto"
                    style={{
                      backgroundColor: currentTheme.colors.bgCard,
                      color: currentTheme.colors.neonCyan,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >{`{
  "reply": "Interview completed.",
  "done": true,
  "feedback": {
    "summary": "Candidate demonstrated strong engineering mastery...",
    "strengths": ["Vector transformation mechanics", "SQL query router integration"],
    "gaps": ["Latency trade-offs in re-ranking"],
    "next": ["Practice load testing containerized endpoints"]
  }
}`}</pre>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: STATE MACHINE */}
          {activeSection === 'state' && (
            <div className="space-y-6">
              <div
                className="p-5 rounded-xl border shadow-sm space-y-4"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <h4
                  className="font-display text-[1.25rem] font-bold"
                  style={{ color: currentTheme.colors.ink }}
                >
                  Session State & Guarantees
                </h4>
                <p className="text-[0.88rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                  The state manager (<code className="font-mono text-[0.75rem] px-1 py-0.5 rounded bg-black/30">src/server/interviewState.ts</code>) tracks each session in memory and ensures the following strict requirements are met:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}20`,
                        borderColor: `${currentTheme.colors.neonCyan}40`,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      Rule 1: Minimum 8 Questions
                    </span>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      An interview cannot complete until at least 8 questions have been asked and answered. This ensures thorough assessment depth.
                    </p>
                  </div>

                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonMagenta}20`,
                        borderColor: `${currentTheme.colors.neonMagenta}40`,
                        color: currentTheme.colors.neonMagenta,
                      }}
                    >
                      Rule 2: Minimum 4 Curriculum Days
                    </span>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      The interviewer must span across at least 4 different curriculum days (e.g. Day 7 Embeddings, Day 10 Hybrid Retrieval, Day 22 Multi-Agent, Day 28 Kubernetes).
                    </p>
                  </div>

                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonPurple}20`,
                        borderColor: `${currentTheme.colors.neonPurple}40`,
                        color: currentTheme.colors.neonPurple,
                      }}
                    >
                      Rule 3: Dynamic Difficulty
                    </span>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      Difficulty levels adapt between <strong>easy</strong>, <strong>medium</strong>, and <strong>hard</strong> based on candidate score and depth of technical explanation.
                    </p>
                  </div>

                  <div
                    className="p-4 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <span
                      className="font-mono text-[0.62rem] uppercase font-bold px-2 py-0.5 rounded border block w-fit mb-2"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                        borderColor: `${currentTheme.colors.neonEmerald}40`,
                        color: currentTheme.colors.neonEmerald,
                      }}
                    >
                      Rule 4: Candidate Grounding
                    </span>
                    <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                      Candidate background (job role, years of experience, completed vs skipped days) dynamically informs opening questions and follow-ups.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 4: SCORING & FEEDBACK */}
          {activeSection === 'scoring' && (
            <div className="space-y-6">
              <div
                className="p-5 rounded-xl border shadow-sm space-y-4"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <h4
                  className="font-display text-[1.25rem] font-bold"
                  style={{ color: currentTheme.colors.ink }}
                >
                  How Candidates are Evaluated & Scored
                </h4>
                <p className="text-[0.88rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                  Each answer is graded on 4 key metrics that feed into an overall score out of 10:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    className="p-3.5 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <strong className="text-[0.88rem]" style={{ color: currentTheme.colors.neonCyan }}>
                        1. Technical Correctness (35%)
                      </strong>
                    </div>
                    <p className="text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
                      Checks accuracy of tools, algorithms, protocols, distance metrics, and APIs mentioned.
                    </p>
                  </div>

                  <div
                    className="p-3.5 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <strong className="text-[0.88rem]" style={{ color: currentTheme.colors.neonPurple }}>
                        2. Conceptual Depth (25%)
                      </strong>
                    </div>
                    <p className="text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
                      Verifies whether the candidate understands underlying mechanisms rather than just buzzwords.
                    </p>
                  </div>

                  <div
                    className="p-3.5 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <strong className="text-[0.88rem]" style={{ color: currentTheme.colors.neonMagenta }}>
                        3. Practical Understanding (25%)
                      </strong>
                    </div>
                    <p className="text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
                      Rewards discussion of trade-offs, edge cases, debugging real issues, and production choices.
                    </p>
                  </div>

                  <div
                    className="p-3.5 rounded-xl border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <strong className="text-[0.88rem]" style={{ color: currentTheme.colors.neonEmerald }}>
                        4. Clarity & Precision (15%)
                      </strong>
                    </div>
                    <p className="text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
                      Evaluates concise, professional communication without rambling or ambiguity.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 5: FAQ */}
          {activeSection === 'faq' && (
            <div className="space-y-4">
              {[
                {
                  q: 'Where do I start if I am a beginner trying to test the app?',
                  a: 'Go to the "Live Interview" tab! Use the preset answer buttons right above the input box (e.g. "Strong Technical", "Partial Answer", or "Simulation Presets") to instantly submit realistic answers without typing long paragraphs manually.',
                },
                {
                  q: 'How does the dynamic theme switcher work?',
                  a: 'Click "Theme Studio" in the top header or sidebar. You can choose from 10 curated light and dark presets, type any prompt into the AI Synthesizer, or fine-tune individual neon accent colors live.',
                },
                {
                  q: 'How do I run automated tests to verify the whole system?',
                  a: 'Click the "Tests" button in the top header or navigate to the "API Sandbox & Tests" tab in the sidebar, then click "Automated Test Runner" -> "Run All Tests". It will verify all 8 endpoints in seconds.',
                },
                {
                  q: 'Where is the backend code located?',
                  a: 'All server files are cleanly organized in `src/server/`: `interviewController.ts` (API route), `interviewer.ts` (question selection), `evaluator.ts` (answer grading), `feedbackGenerator.ts` (final report), and `interviewState.ts` (in-memory state).',
                },
              ].map((faq, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border shadow-xs"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <h5 className="font-bold text-[0.92rem] mb-1" style={{ color: currentTheme.colors.ink }}>
                    {faq.q}
                  </h5>
                  <p className="text-[0.82rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                    {faq.a}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div
          className="p-4 border-t flex items-center justify-between shrink-0 relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="font-mono text-[0.68rem]" style={{ color: currentTheme.colors.inkMuted }}>
            Tip: Press <code className="px-1.5 py-0.5 rounded bg-black/30 font-bold">New Session</code> in the header anytime to restart fresh.
          </div>

          <div className="flex items-center gap-2.5">
            {onOpenTestRunner && (
              <button
                onClick={() => {
                  onOpenTestRunner();
                  onClose();
                }}
                className="font-mono text-[0.7rem] uppercase tracking-wider px-3.5 py-1.5 rounded-lg border transition-all cursor-pointer font-bold"
                style={{
                  backgroundColor: currentTheme.colors.bgSurface,
                  borderColor: currentTheme.colors.borderDark,
                  color: currentTheme.colors.neonPurple,
                }}
              >
                Run Tests
              </button>
            )}

            <button
              onClick={onClose}
              className="px-5 py-1.5 rounded-lg font-mono text-[0.72rem] font-black uppercase tracking-wider hover:brightness-110 shadow-sm transition-all cursor-pointer"
              style={{
                background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`,
                color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
              }}
            >
              Got It! Close Guide
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
