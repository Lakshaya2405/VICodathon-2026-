import React, { useState } from 'react';
import { Play, Copy, Check, Send, Terminal, Sparkles, Code2 } from 'lucide-react';
import { CandidateProfile } from '../server/types';
import { useTheme } from '../theme/ThemeContext';

interface ApiSandboxViewProps {
  candidate: CandidateProfile;
}

export const ApiSandboxView: React.FC<ApiSandboxViewProps> = ({ candidate }) => {
  const { currentTheme } = useTheme();
  const [activeSubTab, setActiveSubTab] = useState<'sandbox' | 'testrunner'>('sandbox');
  const [requestType, setRequestType] = useState<'start' | 'turn'>('start');
  const [sessionId, setSessionId] = useState('sandbox-session-001');
  const [candidateMessage, setCandidateMessage] = useState(
    'Sentence transformers convert medical text into 384-dimensional dense vectors, and we indexed them in ChromaDB with cosine similarity.'
  );
  const [responseJson, setResponseJson] = useState<string>('{\n  "status": "Ready to execute"\n}');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Test Runner State
  const [testResults, setTestResults] = useState<{ name: string; passed: boolean; details?: string }[]>([]);
  const [isTesting, setIsTesting] = useState(false);

  const getRequestBody = () => {
    if (requestType === 'start') {
      return {
        sessionId,
        candidate,
      };
    }
    return {
      sessionId,
      message: candidateMessage,
    };
  };

  const handleExecute = async () => {
    setIsLoading(true);
    try {
      const body = getRequestBody();
      const res = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      setResponseJson(JSON.stringify(data, null, 2));
    } catch (e: any) {
      setResponseJson(JSON.stringify({ error: e.message || 'Fetch failed' }, null, 2));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunFullTestSuite = async () => {
    setIsTesting(true);
    setTestResults([]);
    const results: { name: string; passed: boolean; details?: string }[] = [];

    const addResult = (name: string, passed: boolean, details?: string) => {
      results.push({ name, passed, details });
      setTestResults([...results]);
    };

    try {
      // 1. Health check
      const healthRes = await fetch('/api/health');
      addResult('GET /api/health: Service live and healthy', healthRes.status === 200);

      // 2. Candidates load
      const candRes = await fetch('/api/candidates');
      const candidates = await candRes.json();
      addResult('GET /api/candidates: Returns 20 cohort profiles', Array.isArray(candidates) && candidates.length === 20);

      // 3. Curriculum load
      const currRes = await fetch('/api/curriculum');
      const curriculum = await currRes.json();
      addResult('GET /api/curriculum: Returns 31 curriculum days across 8 modules', curriculum.days?.length === 31);

      // 4. Start interview
      const testSessionId = `test-runner-${Date.now()}`;
      const startRes = await fetch('/api/interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: testSessionId, candidate: candidates[0] }),
      });
      const startData = await startRes.json();
      addResult('POST /api/interview (Start): Returns opening greeting and done: false', startRes.status === 200 && startData.done === false);

      // 5. Multi-turn interview execution
      const answers = [
        'Sentence transformers generate dense embeddings with cosine similarity metric.',
        'ChromaDB vector database indexed with HNSW for healthcare document retrieval.',
        'SQLite query router splits structured metadata from semantic vector queries.',
        'RAG prompt augmentation with low temperature prevents medical hallucinations.',
        'FastAPI backend manages session state and conversation context.',
        'Multi-agent crew delegates claims specialist and triage specialist.',
        'MCP server exposes JSON-RPC tools for LLM tool invocation.',
        'Containerized with Docker and Kubernetes deployment readiness probes.',
      ];

      let completedData: any = null;
      for (let i = 0; i < answers.length; i++) {
        const turnRes = await fetch('/api/interview', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId: testSessionId, message: answers[i] }),
        });
        const turnData = await turnRes.json();
        if (turnData.done) {
          completedData = turnData;
          break;
        }
      }

      addResult('Minimum 8 Questions & 4 Curriculum Days Guarantee: Session finished successfully', completedData !== null && completedData.done === true);
      addResult('Final Feedback Structure: summary string and strengths/gaps/next arrays', typeof completedData?.feedback?.summary === 'string' && Array.isArray(completedData?.feedback?.strengths) && Array.isArray(completedData?.feedback?.gaps) && Array.isArray(completedData?.feedback?.next));
      
      // 6. Catch all chats endpoints tests
      const allChatsRes = await fetch('/api/chats/all');
      const allChatsData = await allChatsRes.json();
      addResult('GET /api/chats/all: Returns consolidated chat array and turn counts', allChatsRes.status === 200 && typeof allChatsData.totalTurns === 'number');

      const singleFileRes = await fetch('/api/chats/single-file?format=markdown');
      const singleFileText = await singleFileRes.text();
      addResult('GET /api/chats/single-file: Returns unified single markdown file transcript', singleFileRes.status === 200 && singleFileText.includes('NOVA MIND'));

      const exportJsonRes = await fetch('/api/chats/export?format=json');
      addResult('GET /api/chats/export: Returns single-file download with Content-Disposition header', exportJsonRes.status === 200);

      addResult('Error Handling: Null or invalid payload returns HTTP 400', (await (await fetch('/api/interview', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })).status) === 400);
    } catch (e: any) {
      addResult('Test Execution', false, e.message);
    } finally {
      setIsTesting(false);
    }
  };

  const copyCurl = () => {
    const curl = `curl -X POST http://localhost:3000/api/interview \\\n  -H "Content-Type: application/json" \\\n  -d '${JSON.stringify(getRequestBody())}'`;
    navigator.clipboard.writeText(curl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="api-sandbox-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Header Tabs */}
      <div
        className="p-5 rounded-xl flex items-center justify-between backdrop-blur-xl shadow-md border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div>
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            Endpoint Testing & Execution
          </span>
          <h3
            className="font-display text-[1.4rem] font-bold tracking-tight"
            style={{ color: currentTheme.colors.ink }}
          >
            POST /api/interview Developer Sandbox
          </h3>
        </div>

        <div className="flex items-center gap-2 font-mono text-[0.7rem]">
          <button
            onClick={() => setActiveSubTab('sandbox')}
            className="px-3 py-1.5 rounded-lg border font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
            style={{
              background:
                activeSubTab === 'sandbox'
                  ? `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`
                  : currentTheme.colors.bgSurface,
              color:
                activeSubTab === 'sandbox'
                  ? currentTheme.mode === 'light'
                    ? '#ffffff'
                    : '#07070a'
                  : currentTheme.colors.inkMuted,
              borderColor:
                activeSubTab === 'sandbox'
                  ? currentTheme.colors.neonCyan
                  : currentTheme.colors.borderDark,
              boxShadow:
                activeSubTab === 'sandbox'
                  ? `0 0 12px ${currentTheme.colors.primaryGlow}`
                  : 'none',
            }}
          >
            Interactive Sandbox
          </button>
          <button
            onClick={() => setActiveSubTab('testrunner')}
            className="px-3 py-1.5 rounded-lg border font-bold uppercase tracking-wider transition-all cursor-pointer shadow-sm"
            style={{
              background:
                activeSubTab === 'testrunner'
                  ? `linear-gradient(to right, ${currentTheme.colors.neonPurple}, ${currentTheme.colors.neonMagenta})`
                  : currentTheme.colors.bgSurface,
              color:
                activeSubTab === 'testrunner'
                  ? currentTheme.mode === 'light'
                    ? '#ffffff'
                    : '#07070a'
                  : currentTheme.colors.inkMuted,
              borderColor:
                activeSubTab === 'testrunner'
                  ? currentTheme.colors.neonPurple
                  : currentTheme.colors.borderDark,
              boxShadow:
                activeSubTab === 'testrunner'
                  ? `0 0 12px ${currentTheme.colors.neonPurple}66`
                  : 'none',
            }}
          >
            Automated Test Runner
          </button>
        </div>
      </div>

      {activeSubTab === 'sandbox' ? (
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-5 overflow-y-auto md:overflow-hidden min-h-0 relative">
          {/* Virtual Background Watermark inside sandbox */}
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
            <span
              className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              NOVA MIND
            </span>
          </div>

          {/* Request Panel */}
          <div
            className="rounded-xl p-5 flex flex-col overflow-hidden backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <div className="flex items-center justify-between mb-4">
              <span
                className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
                style={{ color: currentTheme.colors.neonCyan }}
              >
                HTTP Request Payload
              </span>
              <div className="flex items-center gap-2 font-mono text-[0.65rem]">
                <button
                  onClick={() => setRequestType('start')}
                  className="px-2.5 py-1 rounded-md border font-bold uppercase cursor-pointer transition-all"
                  style={{
                    backgroundColor:
                      requestType === 'start'
                        ? `${currentTheme.colors.neonCyan}20`
                        : currentTheme.colors.bgCard,
                    color:
                      requestType === 'start'
                        ? currentTheme.colors.neonCyan
                        : currentTheme.colors.inkMuted,
                    borderColor:
                      requestType === 'start'
                        ? currentTheme.colors.neonCyan
                        : currentTheme.colors.borderDark,
                  }}
                >
                  Start Payload
                </button>
                <button
                  onClick={() => setRequestType('turn')}
                  className="px-2.5 py-1 rounded-md border font-bold uppercase cursor-pointer transition-all"
                  style={{
                    backgroundColor:
                      requestType === 'turn'
                        ? `${currentTheme.colors.neonMagenta}20`
                        : currentTheme.colors.bgCard,
                    color:
                      requestType === 'turn'
                        ? currentTheme.colors.neonMagenta
                        : currentTheme.colors.inkMuted,
                    borderColor:
                      requestType === 'turn'
                        ? currentTheme.colors.neonMagenta
                        : currentTheme.colors.borderDark,
                  }}
                >
                  Message Turn
                </button>
              </div>
            </div>

            <div className="space-y-3.5 flex-1 overflow-y-auto">
              <div>
                <label
                  className="font-mono text-[0.62rem] uppercase tracking-wider block mb-1"
                  style={{ color: currentTheme.colors.inkMuted }}
                >
                  Session ID:
                </label>
                <input
                  type="text"
                  value={sessionId}
                  onChange={(e) => setSessionId(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg font-mono text-[0.75rem] outline-none border transition-all"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.ink,
                  }}
                />
              </div>

              {requestType === 'turn' && (
                <div>
                  <label
                    className="font-mono text-[0.62rem] uppercase tracking-wider block mb-1"
                    style={{ color: currentTheme.colors.inkMuted }}
                  >
                    Candidate Message:
                  </label>
                  <textarea
                    rows={3}
                    value={candidateMessage}
                    onChange={(e) => setCandidateMessage(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg font-sans text-[0.88rem] outline-none resize-none border transition-all"
                    style={{
                      backgroundColor: currentTheme.colors.bgCard,
                      borderColor: currentTheme.colors.borderDark,
                      color: currentTheme.colors.ink,
                    }}
                  />
                </div>
              )}

              <div>
                <label
                  className="font-mono text-[0.62rem] uppercase tracking-wider block mb-1"
                  style={{ color: currentTheme.colors.inkMuted }}
                >
                  JSON Preview:
                </label>
                <pre
                  className="p-3 rounded-lg font-mono text-[0.7rem] overflow-x-auto max-h-44 shadow-inner border"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.neonEmerald,
                  }}
                >
                  {JSON.stringify(getRequestBody(), null, 2)}
                </pre>
              </div>
            </div>

            <div
              className="pt-4 border-t flex items-center justify-between mt-auto"
              style={{ borderColor: currentTheme.colors.borderDark }}
            >
              <button
                onClick={copyCurl}
                className="font-mono text-[0.68rem] uppercase tracking-wider flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer shadow-xs"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                  color: currentTheme.colors.ink,
                }}
              >
                {copied ? <Check className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonEmerald }} /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy cURL'}</span>
              </button>

              <button
                onClick={handleExecute}
                disabled={isLoading}
                className="font-mono text-[0.7rem] uppercase tracking-wider font-black px-4 py-2 rounded-lg hover:brightness-110 transition-all disabled:opacity-30 cursor-pointer flex items-center gap-1.5 shadow-sm"
                style={{
                  background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`,
                  color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                  boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isLoading ? 'Executing...' : 'Send Request'}</span>
              </button>
            </div>
          </div>

          {/* Response Panel */}
          <div
            className="rounded-xl p-5 flex flex-col overflow-hidden backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <span
              className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold mb-3 block"
              style={{ color: currentTheme.colors.neonEmerald }}
            >
              HTTP Response Payload (JSON)
            </span>
            <div
              className="flex-1 rounded-xl p-4 overflow-y-auto shadow-inner border"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <pre
                className="font-mono text-[0.75rem] leading-relaxed"
                style={{ color: currentTheme.colors.neonCyan }}
              >
                {responseJson}
              </pre>
            </div>
          </div>
        </div>
      ) : (
        /* Automated Test Runner Sub-Tab */
        <div
          className="flex-1 rounded-xl p-6 flex flex-col overflow-hidden backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgSurface,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          {/* Virtual Background Watermark inside test runner */}
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
            <span
              className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
              style={{ color: currentTheme.colors.neonPurple }}
            >
              NOVA MIND
            </span>
          </div>

          <div className="flex items-center justify-between mb-4 relative z-10">
            <div>
              <h4
                className="font-display text-[1.25rem] font-bold"
                style={{ color: currentTheme.colors.ink }}
              >
                End-to-End Automated Verification Runner
              </h4>
              <p
                className="font-mono text-[0.68rem]"
                style={{ color: currentTheme.colors.inkMuted }}
              >
                Executes all compliance tests (8+ questions, 4+ curriculum days, candidate personalization, error handling).
              </p>
            </div>
            <button
              onClick={handleRunFullTestSuite}
              disabled={isTesting}
              className="font-mono text-[0.72rem] uppercase tracking-wider font-bold px-4 py-2 rounded-lg hover:brightness-110 transition-all disabled:opacity-30 cursor-pointer flex items-center gap-2 shadow-sm"
              style={{
                background: `linear-gradient(to right, ${currentTheme.colors.neonPurple}, ${currentTheme.colors.neonMagenta})`,
                color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                boxShadow: `0 0 15px ${currentTheme.colors.neonPurple}66`,
              }}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isTesting ? 'Running...' : 'Run All Tests'}</span>
            </button>
          </div>

          <div
            className="flex-1 overflow-y-auto space-y-2.5 p-4 rounded-xl relative z-10 border shadow-inner"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            {testResults.length === 0 ? (
              <div
                className="py-12 text-center font-mono text-[0.75rem]"
                style={{ color: currentTheme.colors.inkFaint }}
              >
                Click "Run All Tests" to execute the test suite live in browser.
              </div>
            ) : (
              testResults.map((t, idx) => (
                <div
                  key={idx}
                  className="rounded-lg p-3 flex items-center justify-between border transition-colors shadow-xs"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <span
                    className="font-mono text-[0.75rem] font-medium"
                    style={{ color: currentTheme.colors.ink }}
                  >
                    {t.name}
                  </span>
                  <span
                    className="font-mono text-[0.65rem] font-bold uppercase px-2.5 py-0.5 rounded border"
                    style={{
                      backgroundColor: t.passed
                        ? `${currentTheme.colors.neonEmerald}20`
                        : '#ef444420',
                      color: t.passed
                        ? currentTheme.colors.neonEmerald
                        : '#ef4444',
                      borderColor: t.passed
                        ? `${currentTheme.colors.neonEmerald}40`
                        : '#ef444440',
                      boxShadow: t.passed
                        ? `0 0 8px ${currentTheme.colors.neonEmerald}40`
                        : 'none',
                    }}
                  >
                    {t.passed ? 'PASS' : 'FAIL'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
