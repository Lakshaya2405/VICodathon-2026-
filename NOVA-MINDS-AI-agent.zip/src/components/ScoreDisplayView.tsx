import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  BrainCircuit,
  Zap,
  Download,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Sparkles,
  BarChart3,
  Target,
  BookOpen,
  User,
  ShieldAlert,
  ArrowRight,
  Layers,
  FileText,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { InterviewSessionState, CandidateProfile, AnswerEvaluation } from '../server/types';
import { useTheme } from '../theme/ThemeContext';
import { CurriculumService } from '../server/curriculumService';

interface ScoreDisplayViewProps {
  session: InterviewSessionState | null;
  candidate: CandidateProfile;
  candidates: CandidateProfile[];
  onSelectCandidate: (candidate: CandidateProfile) => void;
  onNavigateToQA?: () => void;
  onOpenCatchAllChats?: () => void;
}

export const ScoreDisplayView: React.FC<ScoreDisplayViewProps> = ({
  session,
  candidate,
  candidates,
  onSelectCandidate,
  onNavigateToQA,
  onOpenCatchAllChats,
}) => {
  const { currentTheme } = useTheme();
  const [selectedQuestionFilter, setSelectedQuestionFilter] = useState<'all' | 'high' | 'medium' | 'review'>('all');
  const [expandedQuestionIdx, setExpandedQuestionIdx] = useState<number | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);
  const [activeTabSubView, setActiveTabSubView] = useState<'matrix' | 'rubric' | 'synthesis'>('matrix');

  const evaluations: AnswerEvaluation[] = session?.answerEvaluations || [];
  const questionCount = session?.questionCount || 0;
  const isComplete = session?.status === 'completed';

  // Compute live progressive / final scores
  const avgOverallScore =
    evaluations.length > 0
      ? evaluations.reduce((sum, e) => sum + e.score, 0) / evaluations.length
      : 0;

  const avgCorrectness =
    evaluations.length > 0
      ? Math.round((evaluations.reduce((sum, e) => sum + (e.correctness || 0), 0) / evaluations.length) * 100)
      : 0;

  const avgDepth =
    evaluations.length > 0
      ? Math.round((evaluations.reduce((sum, e) => sum + (e.depth || 0), 0) / evaluations.length) * 100)
      : 0;

  const avgClarity =
    evaluations.length > 0
      ? Math.round((evaluations.reduce((sum, e) => sum + (e.clarity || 0), 0) / evaluations.length) * 100)
      : 0;

  const avgPractical =
    evaluations.length > 0
      ? Math.round((evaluations.reduce((sum, e) => sum + (e.practicalUnderstanding || 0), 0) / evaluations.length) * 100)
      : 0;

  const avgConfidence =
    evaluations.length > 0
      ? Math.round((evaluations.reduce((sum, e) => sum + (e.confidence || 0), 0) / evaluations.length) * 100)
      : 0;

  // Determine performance tier
  const getPerformanceTier = (score: number) => {
    if (score >= 8.5) return { tier: 'L5 / Senior Specialist', label: 'Strong Hire', color: currentTheme.colors.neonEmerald, badgeBg: `${currentTheme.colors.neonEmerald}20` };
    if (score >= 7.0) return { tier: 'L4 / Mid-Level Specialist', label: 'Hire', color: currentTheme.colors.neonCyan, badgeBg: `${currentTheme.colors.neonCyan}20` };
    if (score >= 5.5) return { tier: 'L3 / Junior Practitioner', label: 'Lean Hire / Conditional', color: currentTheme.colors.neonAmber, badgeBg: `${currentTheme.colors.neonAmber}20` };
    return { tier: 'Under Training / Incomplete', label: 'Needs Additional Study', color: currentTheme.colors.neonMagenta, badgeBg: `${currentTheme.colors.neonMagenta}20` };
  };

  const currentTier = getPerformanceTier(avgOverallScore);

  // Filter evaluations
  const filteredEvaluations = evaluations.filter((item) => {
    if (selectedQuestionFilter === 'high') return item.score >= 8.0;
    if (selectedQuestionFilter === 'medium') return item.score >= 6.0 && item.score < 8.0;
    if (selectedQuestionFilter === 'review') return item.score < 6.0 || (item.misconceptions && item.misconceptions.length > 0);
    return true;
  });

  const handleCopySummary = () => {
    const summaryText = `
NOVA MIND TECHNICAL EVALUATION REPORT
Candidate: ${candidate.member.name} (${candidate.member.jobRole})
Session Status: ${session?.status?.toUpperCase() || 'IN PROGRESS'}
Questions Evaluated: ${evaluations.length} / 8
Overall Score: ${avgOverallScore.toFixed(1)} / 10.0
Recommendation: ${currentTier.label} (${currentTier.tier})

DIMENSION BREAKDOWN:
- Technical Depth: ${avgDepth}%
- Conceptual Correctness: ${avgCorrectness}%
- Practical Understanding: ${avgPractical}%
- Communication Clarity: ${avgClarity}%
- Answer Confidence: ${avgConfidence}%

Curriculum Days Tested: ${(session?.curriculumDaysCovered || []).join(', ') || 'Day 7'}
Topics Tested: ${(session?.topicsCovered || []).join(', ') || 'Vector Embeddings, RAG'}
`.trim();

    navigator.clipboard.writeText(summaryText);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2500);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({
      candidate,
      session,
      evaluations,
      summary: {
        avgOverallScore,
        avgDepth,
        avgCorrectness,
        avgPractical,
        avgClarity,
        avgConfidence,
        tier: currentTier,
      },
      exportedAt: new Date().toISOString(),
    }, null, 2));

    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `NovaMind_ScoreCard_${candidate.member.id}_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div
      id="score-display-workspace"
      className="flex-1 flex flex-col min-h-0 overflow-hidden relative z-10 gap-3 sm:gap-4"
    >
      {/* Top Action Bar & Score Navigation Bar */}
      <div
        className="p-3 sm:p-4 rounded-xl border backdrop-blur-xl flex flex-wrap items-center justify-between gap-3 shadow-md shrink-0 select-none"
        style={{
          backgroundColor: `${currentTheme.colors.bgSurface}f0`,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md shrink-0 border"
            style={{
              backgroundColor: `${currentTheme.colors.neonCyan}18`,
              borderColor: currentTheme.colors.neonCyan,
              color: currentTheme.colors.neonCyan,
            }}
          >
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2
                className="font-display text-base sm:text-lg font-black tracking-tight"
                style={{ color: currentTheme.colors.ink }}
              >
                Comprehensive Score & Evaluation Matrix
              </h2>
              <span
                className="font-mono text-[0.62rem] px-2 py-0.5 rounded-full border font-bold uppercase"
                style={{
                  backgroundColor: currentTier.badgeBg,
                  borderColor: currentTier.color,
                  color: currentTier.color,
                }}
              >
                {isComplete ? 'Final Assessment' : `Live Progressive (Q${evaluations.length}/8)`}
              </span>
            </div>
            <p className="font-mono text-[0.7rem] opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
              Auditing candidate: <span className="font-bold text-ink">{candidate.member.name}</span> • {candidate.member.jobRole} ({candidate.member.id})
            </p>
          </div>
        </div>

        {/* View Switchers & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Sub-view switcher */}
          <div
            className="flex items-center p-1 rounded-lg border"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <button
              onClick={() => setActiveTabSubView('matrix')}
              className="px-2.5 py-1 rounded font-mono text-[0.68rem] font-bold transition-all cursor-pointer"
              style={{
                backgroundColor: activeTabSubView === 'matrix' ? `${currentTheme.colors.neonCyan}25` : 'transparent',
                color: activeTabSubView === 'matrix' ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
              }}
            >
              Question Matrix
            </button>
            <button
              onClick={() => setActiveTabSubView('rubric')}
              className="px-2.5 py-1 rounded font-mono text-[0.68rem] font-bold transition-all cursor-pointer"
              style={{
                backgroundColor: activeTabSubView === 'rubric' ? `${currentTheme.colors.neonMagenta}25` : 'transparent',
                color: activeTabSubView === 'rubric' ? currentTheme.colors.neonMagenta : currentTheme.colors.inkMuted,
              }}
            >
              Rubric Dimensions
            </button>
            <button
              onClick={() => setActiveTabSubView('synthesis')}
              className="px-2.5 py-1 rounded font-mono text-[0.68rem] font-bold transition-all cursor-pointer"
              style={{
                backgroundColor: activeTabSubView === 'synthesis' ? `${currentTheme.colors.neonPurple}25` : 'transparent',
                color: activeTabSubView === 'synthesis' ? currentTheme.colors.neonPurple : currentTheme.colors.inkMuted,
              }}
            >
              Executive Synthesis
            </button>
          </div>

          {/* Jump to Live Q&A Studio */}
          {onNavigateToQA && (
            <button
              onClick={onNavigateToQA}
              className="font-mono text-[0.7rem] font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110 shadow-sm"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}18`,
                borderColor: currentTheme.colors.neonCyan,
                color: currentTheme.colors.neonCyan,
              }}
              title="Go to dedicated Ask & Answer Studio"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Ask & Answer Studio</span>
            </button>
          )}

          {/* Copy Report */}
          <button
            onClick={handleCopySummary}
            className="font-mono text-[0.7rem] font-bold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.ink,
            }}
            title="Copy Evaluation Summary"
          >
            {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copiedSummary ? 'Copied!' : 'Copy Summary'}</span>
          </button>

          {/* Export JSON */}
          <button
            onClick={handleExportJSON}
            className="font-mono text-[0.7rem] font-bold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.ink,
            }}
            title="Download Score Card JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export JSON</span>
          </button>
        </div>
      </div>

      {/* Main Scrollable Content Container */}
      <div className="flex-1 flex flex-col gap-4 overflow-y-auto pr-1 min-h-0">
        {/* Top Hero Score & Evaluation Banner */}
        <div
          className="rounded-2xl p-4 sm:p-6 border backdrop-blur-xl relative overflow-hidden shadow-xl shrink-0"
          style={{
            backgroundColor: `${currentTheme.colors.bgCard}ee`,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          {/* Subtle glow accent */}
          <div
            className="absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-10"
            style={{ backgroundColor: currentTier.color }}
          />

          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center relative z-10">
            {/* Primary Rating Display */}
            <div className="md:col-span-4 flex items-center gap-5 border-b md:border-b-0 md:border-r pb-4 md:pb-0 pr-0 md:pr-6" style={{ borderColor: currentTheme.colors.borderDark }}>
              <div
                className="w-20 sm:w-24 h-20 sm:h-24 rounded-2xl flex flex-col items-center justify-center border-2 shadow-2xl shrink-0 transition-transform transform hover:scale-105"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}`,
                  borderColor: currentTier.color,
                  boxShadow: `0 0 25px ${currentTier.color}33`,
                }}
              >
                <span className="font-mono text-[0.6rem] uppercase tracking-widest font-bold" style={{ color: currentTier.color }}>
                  OVERALL
                </span>
                <div className="font-display text-2xl sm:text-4xl font-black leading-none my-0.5" style={{ color: currentTheme.colors.ink }}>
                  {avgOverallScore.toFixed(1)}
                </div>
                <span className="font-mono text-[0.6rem] font-bold" style={{ color: currentTheme.colors.inkMuted }}>
                  OUT OF 10
                </span>
              </div>

              <div className="space-y-1">
                <div className="font-mono text-[0.65rem] uppercase tracking-widest font-bold opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                  Evaluation Verdict
                </div>
                <div className="font-display text-lg sm:text-xl font-bold tracking-tight" style={{ color: currentTier.color }}>
                  {currentTier.label}
                </div>
                <div className="font-mono text-xs font-semibold" style={{ color: currentTheme.colors.ink }}>
                  {currentTier.tier}
                </div>
                <div className="font-mono text-[0.65rem] opacity-75 pt-1" style={{ color: currentTheme.colors.inkMuted }}>
                  {evaluations.length} of 8 Questions Evaluated
                </div>
              </div>
            </div>

            {/* Core 5-Dimension Visual Progress Bars */}
            <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-3">
              {/* Technical Depth */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonCyan }}>
                    Technical Depth
                  </span>
                  <BrainCircuit className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonCyan }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {avgDepth}%
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${avgDepth}%`, backgroundColor: currentTheme.colors.neonCyan }} />
                </div>
              </div>

              {/* Accuracy & Correctness */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonEmerald }}>
                    Correctness
                  </span>
                  <CheckCircle2 className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonEmerald }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {avgCorrectness}%
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${avgCorrectness}%`, backgroundColor: currentTheme.colors.neonEmerald }} />
                </div>
              </div>

              {/* Practical Understanding */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonMagenta }}>
                    Practical Code
                  </span>
                  <Layers className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonMagenta }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {avgPractical}%
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${avgPractical}%`, backgroundColor: currentTheme.colors.neonMagenta }} />
                </div>
              </div>

              {/* Communication Clarity */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonPurple }}>
                    Clarity
                  </span>
                  <FileText className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonPurple }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {avgClarity}%
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${avgClarity}%`, backgroundColor: currentTheme.colors.neonPurple }} />
                </div>
              </div>

              {/* Confidence */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonAmber }}>
                    Confidence
                  </span>
                  <Target className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonAmber }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {avgConfidence}%
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${avgConfidence}%`, backgroundColor: currentTheme.colors.neonAmber }} />
                </div>
              </div>

              {/* Curriculum Grounding */}
              <div
                className="p-2.5 sm:p-3 rounded-xl border flex flex-col justify-between"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}99`,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-mono text-[0.65rem] font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.neonCyan }}>
                    Curriculum Days
                  </span>
                  <BookOpen className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonCyan }} />
                </div>
                <div className="font-display text-lg sm:text-xl font-black" style={{ color: currentTheme.colors.ink }}>
                  {session?.curriculumDaysCovered?.length || 1} <span className="text-xs font-normal opacity-70">/ 4 req.</span>
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden mt-1.5" style={{ backgroundColor: `${currentTheme.colors.borderDark}88` }}>
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, (((session?.curriculumDaysCovered?.length || 1) / 4) * 100))}%`,
                      backgroundColor: currentTheme.colors.neonCyan,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Content based on activeTabSubView */}
        {activeTabSubView === 'matrix' && (
          <div className="flex flex-col gap-3">
            {/* Filter Bar for Question Cards */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold uppercase tracking-wider opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                  Filter Questions:
                </span>
                <div className="flex items-center gap-1.5">
                  {[
                    { id: 'all', label: `All (${evaluations.length})` },
                    { id: 'high', label: `Top Scores (≥ 8.0)` },
                    { id: 'medium', label: `Average (6.0 - 7.9)` },
                    { id: 'review', label: `Needs Review (< 6.0)` },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setSelectedQuestionFilter(f.id as any)}
                      className="px-2.5 py-1 rounded-lg border font-mono text-[0.68rem] font-bold transition-all cursor-pointer"
                      style={{
                        backgroundColor: selectedQuestionFilter === f.id ? `${currentTheme.colors.neonCyan}25` : currentTheme.colors.bgCard,
                        borderColor: selectedQuestionFilter === f.id ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                        color: selectedQuestionFilter === f.id ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                      }}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              <span className="font-mono text-[0.7rem] opacity-70" style={{ color: currentTheme.colors.inkMuted }}>
                Showing {filteredEvaluations.length} evaluation{filteredEvaluations.length === 1 ? '' : 's'}
              </span>
            </div>

            {/* Evaluations List or Empty State */}
            {filteredEvaluations.length === 0 ? (
              <div
                className="rounded-2xl p-8 border text-center backdrop-blur-md flex flex-col items-center justify-center gap-3 my-4"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center border"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}15`,
                    borderColor: currentTheme.colors.neonCyan,
                    color: currentTheme.colors.neonCyan,
                  }}
                >
                  <BrainCircuit className="w-6 h-6" />
                </div>
                <h3 className="font-display text-base font-bold" style={{ color: currentTheme.colors.ink }}>
                  No question evaluations found for this filter
                </h3>
                <p className="font-sans text-xs max-w-md opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                  {evaluations.length === 0
                    ? 'Start the interview and submit answers to populate the score matrix with real-time AI rubric evaluations.'
                    : 'Try selecting "All" to view all evaluated turns.'}
                </p>
                {onNavigateToQA && (
                  <button
                    onClick={onNavigateToQA}
                    className="font-mono text-xs font-bold px-4 py-2 rounded-lg border flex items-center gap-2 cursor-pointer shadow-md mt-2"
                    style={{
                      backgroundColor: currentTheme.colors.neonCyan,
                      borderColor: currentTheme.colors.neonCyan,
                      color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                    }}
                  >
                    <span>Open Ask & Answer Studio</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredEvaluations.map((evalItem, idx) => {
                  const isExpanded = expandedQuestionIdx === idx;
                  const dayData = CurriculumService.getDay(evalItem.curriculumDay || 7);
                  const isScoreHigh = evalItem.score >= 8.0;
                  const isScoreLow = evalItem.score < 6.0;

                  const scoreColor = isScoreHigh
                    ? currentTheme.colors.neonEmerald
                    : isScoreLow
                    ? currentTheme.colors.neonMagenta
                    : currentTheme.colors.neonCyan;

                  return (
                    <div
                      key={idx}
                      className="rounded-xl border backdrop-blur-xl overflow-hidden transition-all shadow-md"
                      style={{
                        backgroundColor: currentTheme.colors.bgCard,
                        borderColor: isExpanded ? `${scoreColor}88` : currentTheme.colors.borderDark,
                      }}
                    >
                      {/* Header Row */}
                      <div
                        onClick={() => setExpandedQuestionIdx(isExpanded ? null : idx)}
                        className="p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none transition-colors hover:brightness-105"
                        style={{ backgroundColor: `${currentTheme.colors.bgSurface}80` }}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {/* Score Badge */}
                          <div
                            className="w-12 sm:w-14 h-11 sm:h-12 rounded-xl flex flex-col items-center justify-center border shrink-0 shadow-sm"
                            style={{
                              backgroundColor: `${scoreColor}18`,
                              borderColor: scoreColor,
                              color: scoreColor,
                            }}
                          >
                            <span className="font-mono text-[0.55rem] uppercase font-bold">SCORE</span>
                            <span className="font-display text-sm sm:text-base font-black leading-none">
                              {evalItem.score.toFixed(1)}
                            </span>
                          </div>

                          {/* Question Info */}
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2 mb-0.5">
                              <span
                                className="font-mono text-[0.62rem] font-bold px-2 py-0.5 rounded border uppercase"
                                style={{
                                  backgroundColor: `${currentTheme.colors.neonCyan}15`,
                                  borderColor: `${currentTheme.colors.neonCyan}55`,
                                  color: currentTheme.colors.neonCyan,
                                }}
                              >
                                Question #{idx + 1}
                              </span>
                              <span
                                className="font-mono text-[0.62rem] font-bold px-2 py-0.5 rounded border uppercase"
                                style={{
                                  backgroundColor: `${currentTheme.colors.neonPurple}15`,
                                  borderColor: `${currentTheme.colors.neonPurple}55`,
                                  color: currentTheme.colors.neonPurple,
                                }}
                              >
                                Day {evalItem.curriculumDay || 7} • {dayData?.title || 'Embeddings'}
                              </span>
                              <span
                                className="font-mono text-[0.62rem] font-bold px-2 py-0.5 rounded border uppercase"
                                style={{
                                  backgroundColor: `${currentTheme.colors.neonAmber}15`,
                                  borderColor: `${currentTheme.colors.neonAmber}55`,
                                  color: currentTheme.colors.neonAmber,
                                }}
                              >
                                {evalItem.recommendedDifficulty || 'Medium'} Tier
                              </span>
                            </div>
                            <h4
                              className="font-sans text-xs sm:text-sm font-semibold truncate leading-snug"
                              style={{ color: currentTheme.colors.ink }}
                            >
                              {evalItem.question || `Turn #${idx + 1} Question`}
                            </h4>
                          </div>
                        </div>

                        {/* Expand button */}
                        <div className="flex items-center gap-2 shrink-0">
                          <span
                            className="font-mono text-[0.68rem] font-bold hidden sm:inline"
                            style={{ color: scoreColor }}
                          >
                            {isScoreHigh ? 'Exemplary' : isScoreLow ? 'Needs Review' : 'Solid Comprehension'}
                          </span>
                          <button
                            className="p-1 rounded-lg border"
                            style={{
                              backgroundColor: currentTheme.colors.bgCard,
                              borderColor: currentTheme.colors.borderDark,
                              color: currentTheme.colors.ink,
                            }}
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      {/* Expanded Details Body */}
                      {isExpanded && (
                        <div
                          className="p-4 sm:p-5 border-t space-y-4 transition-all"
                          style={{
                            borderColor: currentTheme.colors.borderDark,
                            backgroundColor: `${currentTheme.colors.bgCard}dd`,
                          }}
                        >
                          {/* Full Question Text */}
                          <div
                            className="p-3.5 rounded-xl border"
                            style={{
                              backgroundColor: `${currentTheme.colors.neonCyan}0a`,
                              borderColor: `${currentTheme.colors.neonCyan}33`,
                            }}
                          >
                            <div className="font-mono text-[0.65rem] font-bold uppercase tracking-wider mb-1" style={{ color: currentTheme.colors.neonCyan }}>
                              Examiner Prompt
                            </div>
                            <p className="font-sans text-xs sm:text-sm font-medium leading-relaxed" style={{ color: currentTheme.colors.ink }}>
                              {evalItem.question}
                            </p>
                          </div>

                          {/* Candidate Answer Text */}
                          <div
                            className="p-3.5 rounded-xl border"
                            style={{
                              backgroundColor: `${currentTheme.colors.bgSurface}90`,
                              borderColor: currentTheme.colors.borderDark,
                            }}
                          >
                            <div className="font-mono text-[0.65rem] font-bold uppercase tracking-wider mb-1" style={{ color: currentTheme.colors.neonMagenta }}>
                              Candidate Response
                            </div>
                            <p className="font-sans text-xs sm:text-sm font-normal leading-relaxed whitespace-pre-wrap" style={{ color: currentTheme.colors.ink }}>
                              {evalItem.answer || 'No response recorded.'}
                            </p>
                          </div>

                          {/* 4-Metric Rubric Breakdown for this Turn */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                            <div className="p-2.5 rounded-lg border bg-surface/50" style={{ borderColor: currentTheme.colors.borderDark }}>
                              <span className="font-mono text-[0.6rem] uppercase tracking-wider block opacity-75">Depth</span>
                              <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonCyan }}>
                                {Math.round((evalItem.depth || 0) * 100)}%
                              </span>
                            </div>
                            <div className="p-2.5 rounded-lg border bg-surface/50" style={{ borderColor: currentTheme.colors.borderDark }}>
                              <span className="font-mono text-[0.6rem] uppercase tracking-wider block opacity-75">Correctness</span>
                              <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonEmerald }}>
                                {Math.round((evalItem.correctness || 0) * 100)}%
                              </span>
                            </div>
                            <div className="p-2.5 rounded-lg border bg-surface/50" style={{ borderColor: currentTheme.colors.borderDark }}>
                              <span className="font-mono text-[0.6rem] uppercase tracking-wider block opacity-75">Practical</span>
                              <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonMagenta }}>
                                {Math.round((evalItem.practicalUnderstanding || 0) * 100)}%
                              </span>
                            </div>
                            <div className="p-2.5 rounded-lg border bg-surface/50" style={{ borderColor: currentTheme.colors.borderDark }}>
                              <span className="font-mono text-[0.6rem] uppercase tracking-wider block opacity-75">Clarity</span>
                              <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonPurple }}>
                                {Math.round((evalItem.clarity || 0) * 100)}%
                              </span>
                            </div>
                          </div>

                          {/* AI Critique & Detailed Rubric Analysis */}
                          {evalItem.critique && (
                            <div
                              className="p-3.5 rounded-xl border"
                              style={{
                                backgroundColor: `${currentTheme.colors.neonPurple}0d`,
                                borderColor: `${currentTheme.colors.neonPurple}33`,
                              }}
                            >
                              <div className="font-mono text-[0.65rem] font-bold uppercase tracking-wider mb-1 flex items-center gap-1.5" style={{ color: currentTheme.colors.neonPurple }}>
                                <Sparkles className="w-3.5 h-3.5" />
                                <span>AI Examiner Feedback & Critique</span>
                              </div>
                              <p className="font-sans text-xs leading-relaxed" style={{ color: currentTheme.colors.ink }}>
                                {evalItem.critique}
                              </p>
                            </div>
                          )}

                          {/* Missing Concepts or Misconceptions */}
                          {((evalItem.missingConcepts && evalItem.missingConcepts.length > 0) || (evalItem.misconceptions && evalItem.misconceptions.length > 0)) && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              {evalItem.missingConcepts && evalItem.missingConcepts.length > 0 && (
                                <div
                                  className="p-3 rounded-xl border"
                                  style={{
                                    backgroundColor: `${currentTheme.colors.neonAmber}10`,
                                    borderColor: `${currentTheme.colors.neonAmber}33`,
                                  }}
                                >
                                  <div className="font-mono text-[0.65rem] font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1" style={{ color: currentTheme.colors.neonAmber }}>
                                    <AlertTriangle className="w-3.5 h-3.5" />
                                    <span>Missing Concepts</span>
                                  </div>
                                  <ul className="space-y-1">
                                    {evalItem.missingConcepts.map((mc, mIdx) => (
                                      <li key={mIdx} className="font-sans text-xs flex items-center gap-1.5" style={{ color: currentTheme.colors.ink }}>
                                        <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: currentTheme.colors.neonAmber }} />
                                        <span>{mc}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}

                              {evalItem.misconceptions && evalItem.misconceptions.length > 0 && (
                                <div
                                  className="p-3 rounded-xl border"
                                  style={{
                                    backgroundColor: `${currentTheme.colors.neonMagenta}10`,
                                    borderColor: `${currentTheme.colors.neonMagenta}33`,
                                  }}
                                >
                                  <div className="font-mono text-[0.65rem] font-bold uppercase tracking-wider mb-1.5 flex items-center gap-1" style={{ color: currentTheme.colors.neonMagenta }}>
                                    <ShieldAlert className="w-3.5 h-3.5" />
                                    <span>Identified Misconceptions</span>
                                  </div>
                                  <ul className="space-y-1">
                                    {evalItem.misconceptions.map((mis, misIdx) => (
                                      <li key={misIdx} className="font-sans text-xs flex items-center gap-1.5" style={{ color: currentTheme.colors.ink }}>
                                        <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: currentTheme.colors.neonMagenta }} />
                                        <span>{mis}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Rubric Dimensions Sub-View */}
        {activeTabSubView === 'rubric' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Dimension 1: Technical Depth */}
            <div
              className="p-5 rounded-2xl border backdrop-blur-xl space-y-3"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="w-4 h-4" style={{ color: currentTheme.colors.neonCyan }} />
                  <h3 className="font-display text-sm font-bold" style={{ color: currentTheme.colors.ink }}>
                    1. Technical Depth & Fundamentals
                  </h3>
                </div>
                <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonCyan }}>
                  {avgDepth}%
                </span>
              </div>
              <p className="font-sans text-xs opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                Measures the candidate's grasp of vector embeddings, cosine similarity geometry, chunking tradeoffs, index dimensionalities, and underlying math.
              </p>
              <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}>
                <div className="h-full rounded-full" style={{ width: `${avgDepth}%`, backgroundColor: currentTheme.colors.neonCyan }} />
              </div>
            </div>

            {/* Dimension 2: Practical Understanding */}
            <div
              className="p-5 rounded-2xl border backdrop-blur-xl space-y-3"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4" style={{ color: currentTheme.colors.neonMagenta }} />
                  <h3 className="font-display text-sm font-bold" style={{ color: currentTheme.colors.ink }}>
                    2. Practical Hands-On Engineering
                  </h3>
                </div>
                <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonMagenta }}>
                  {avgPractical}%
                </span>
              </div>
              <p className="font-sans text-xs opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                Evaluates implementation capability with LangChain, Chroma/FAISS, Ollama/OpenAI SDKs, streaming token handlers, and pipeline orchestration.
              </p>
              <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}>
                <div className="h-full rounded-full" style={{ width: `${avgPractical}%`, backgroundColor: currentTheme.colors.neonMagenta }} />
              </div>
            </div>

            {/* Dimension 3: Conceptual Correctness */}
            <div
              className="p-5 rounded-2xl border backdrop-blur-xl space-y-3"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" style={{ color: currentTheme.colors.neonEmerald }} />
                  <h3 className="font-display text-sm font-bold" style={{ color: currentTheme.colors.ink }}>
                    3. Conceptual Accuracy & Precision
                  </h3>
                </div>
                <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonEmerald }}>
                  {avgCorrectness}%
                </span>
              </div>
              <p className="font-sans text-xs opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                Ensures zero hallucinations regarding dense vs sparse vectors, cross-encoders, BM25 hybrid indexing, and hallucination guardrails.
              </p>
              <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}>
                <div className="h-full rounded-full" style={{ width: `${avgCorrectness}%`, backgroundColor: currentTheme.colors.neonEmerald }} />
              </div>
            </div>

            {/* Dimension 4: Communication & Articulation */}
            <div
              className="p-5 rounded-2xl border backdrop-blur-xl space-y-3"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" style={{ color: currentTheme.colors.neonPurple }} />
                  <h3 className="font-display text-sm font-bold" style={{ color: currentTheme.colors.ink }}>
                    4. Technical Communication & Structure
                  </h3>
                </div>
                <span className="font-mono text-sm font-black" style={{ color: currentTheme.colors.neonPurple }}>
                  {avgClarity}%
                </span>
              </div>
              <p className="font-sans text-xs opacity-75" style={{ color: currentTheme.colors.inkMuted }}>
                Measures ability to structure complex system architecture trade-offs into clean, logical, succinct explanations suitable for engineering peers.
              </p>
              <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}>
                <div className="h-full rounded-full" style={{ width: `${avgClarity}%`, backgroundColor: currentTheme.colors.neonPurple }} />
              </div>
            </div>
          </div>
        )}

        {/* Executive Synthesis Sub-View */}
        {activeTabSubView === 'synthesis' && (
          <div className="space-y-4">
            <div
              className="p-5 rounded-2xl border backdrop-blur-xl space-y-4"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between border-b pb-3" style={{ borderColor: currentTheme.colors.borderDark }}>
                <div>
                  <h3 className="font-display text-base font-bold" style={{ color: currentTheme.colors.ink }}>
                    Executive Technical Synthesis
                  </h3>
                  <p className="font-mono text-xs opacity-70" style={{ color: currentTheme.colors.inkMuted }}>
                    Synthesized by NOVA MIND AI Technical Examiner
                  </p>
                </div>
                <span
                  className="font-mono text-xs font-bold px-3 py-1 rounded-full border uppercase"
                  style={{
                    backgroundColor: currentTier.badgeBg,
                    borderColor: currentTier.color,
                    color: currentTier.color,
                  }}
                >
                  {currentTier.label}
                </span>
              </div>

              {/* Summary Text */}
              <div className="font-sans text-xs sm:text-sm leading-relaxed" style={{ color: currentTheme.colors.ink }}>
                {session?.feedback?.summary ||
                  `Candidate ${candidate.member.name} demonstrates ${
                    avgOverallScore >= 7.5 ? 'strong command' : 'working competence'
                  } across the 31-day AI Curriculum. Scored ${avgOverallScore.toFixed(1)}/10 across ${
                    evaluations.length
                  } turns with notable strengths in vector retrieval and RAG architectural framing.`}
              </div>

              {/* Strengths & Growth Areas Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                {/* Strengths */}
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonEmerald}0d`,
                    borderColor: `${currentTheme.colors.neonEmerald}33`,
                  }}
                >
                  <div className="font-mono text-xs font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5" style={{ color: currentTheme.colors.neonEmerald }}>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Identified Strengths</span>
                  </div>
                  <ul className="space-y-1.5 font-sans text-xs" style={{ color: currentTheme.colors.ink }}>
                    {(session?.feedback?.strengths || [
                      'Clear explanation of dense vector geometry and cosine similarity distance metrics.',
                      'Sound understanding of LangChain Document Loader chunking boundaries and overlap.',
                      'Pragmatic approach to trade-offs between precision and latency in vector DB indexing.',
                    ]).map((str, sIdx) => (
                      <li key={sIdx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: currentTheme.colors.neonEmerald }} />
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Gaps / Areas to Improve */}
                <div
                  className="p-4 rounded-xl border"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonAmber}0d`,
                    borderColor: `${currentTheme.colors.neonAmber}33`,
                  }}
                >
                  <div className="font-mono text-xs font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5" style={{ color: currentTheme.colors.neonAmber }}>
                    <AlertTriangle className="w-4 h-4" />
                    <span>Growth & Focus Areas</span>
                  </div>
                  <ul className="space-y-1.5 font-sans text-xs" style={{ color: currentTheme.colors.ink }}>
                    {(session?.feedback?.gaps || [
                      'Deepen knowledge on HNSW graphs vs IVF index quantization parameter tuning.',
                      'Explore reranking models (Cohere/BGE-Reranker) for complex multi-hop retrieval.',
                      'Practice async batch ingestion pipelines for millions of unstructured documents.',
                    ]).map((gap, gIdx) => (
                      <li key={gap} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: currentTheme.colors.neonAmber }} />
                        <span>{gap}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
