import React, { useState } from 'react';
import {
  Palette,
  Sparkles,
  Check,
  X,
  RefreshCw,
  Sliders,
  Sun,
  Moon,
  Zap,
  Layers,
  Wand2,
  CheckCircle2,
} from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';
import { AppTheme, BackgroundPattern } from '../theme/themeTypes';

interface ThemeModalProps {
  onClose: () => void;
}

export const ThemeModal: React.FC<ThemeModalProps> = ({ onClose }) => {
  const {
    currentTheme,
    presets,
    selectPreset,
    setTheme,
    generateAndApplyTheme,
    resetToDefaultTheme,
    cycleNextTheme,
  } = useTheme();

  const [promptInput, setPromptInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'presets' | 'ai' | 'custom'>('presets');
  const [copiedNotification, setCopiedNotification] = useState(false);

  const inspirationPrompts = [
    'Solar Magma & Gold Dust',
    'Deep Cosmic Nebula Violet',
    'Emerald Moss & Cyber Canopy',
    'Arctic Glacial Ice & Diamond Blue',
    'Vaporwave Sunset 1984',
    'Titanium Stealth Minimalist',
    'Sakura Tokyo Blossom',
    'Clean Editorial Light Porcelain',
    'Crimson Blood Moon Gothic',
    'Deep Sea Bioluminescence',
  ];

  const handleGenerate = (textToUse?: string) => {
    const text = textToUse || promptInput;
    if (!text.trim()) return;

    setIsGenerating(true);
    setTimeout(() => {
      generateAndApplyTheme(text);
      setIsGenerating(false);
    }, 150);
  };

  const handlePatternChange = (pattern: BackgroundPattern) => {
    setTheme({
      ...currentTheme,
      pattern,
    });
  };

  const handleColorChange = (key: 'neonCyan' | 'neonMagenta' | 'neonPurple' | 'neonEmerald' | 'neonAmber', value: string) => {
    setTheme({
      ...currentTheme,
      colors: {
        ...currentTheme.colors,
        [key]: value,
      },
    });
  };

  return (
    <div
      id="theme-studio-modal-overlay"
      className="fixed inset-0 z-50 bg-[#000000]/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto select-none animate-in fade-in duration-200"
    >
      <div
        id="theme-studio-modal-card"
        className="bg-[#0c0d15] border border-[#222538] w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden rounded-2xl shadow-[0_0_60px_rgba(0,240,255,0.2)] relative"
      >
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span className="font-display text-[16vw] font-black tracking-[0.2em] text-[#00f0ff] uppercase -rotate-6">
            NOVA MIND
          </span>
        </div>

        {/* Modal Header */}
        <div className="bg-[#121422] p-5 md:p-6 flex items-start justify-between border-b border-[#222538] shrink-0 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Palette className="w-4 h-4 text-[#00f0ff]" />
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold">
                Theme Studio & Dynamic Customizer
              </span>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <h3 className="font-display text-[1.5rem] md:text-[1.7rem] font-bold text-white tracking-tight">
                Dynamic Theme Engine
              </h3>
              <span className="font-mono text-[0.65rem] uppercase tracking-wider bg-gradient-to-r from-[#00f0ff]/20 to-[#a855f7]/20 text-[#00f0ff] border border-[#00f0ff]/40 px-2.5 py-0.5 rounded font-bold shadow-[0_0_10px_rgba(0,240,255,0.25)] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: currentTheme.colors.neonCyan }} />
                Active: {currentTheme.name}
              </span>
            </div>
            <p className="font-mono text-[0.7rem] text-[#94a3b8] mt-1">
              Switch curated presets, generate dynamic palettes from natural language prompts, or customize accents live.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={cycleNextTheme}
              className="px-2.5 py-1.5 rounded-lg border border-[#222538] bg-[#080910] text-[#cbd5e1] hover:border-[#00f0ff] hover:text-[#00f0ff] transition-all cursor-pointer font-mono text-[0.68rem] flex items-center gap-1.5"
              title="Quick cycle next theme"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Quick Cycle</span>
            </button>
            <button
              id="btn-close-theme-modal"
              onClick={onClose}
              className="text-[#94a3b8] hover:text-[#ff007f] p-1.5 rounded-lg border border-[#222538] hover:border-[#ff007f] transition-colors cursor-pointer bg-[#0c0d15]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="bg-[#0e101a] px-6 py-2.5 border-b border-[#222538] flex items-center justify-between gap-4 flex-wrap relative z-10">
          <div className="flex items-center gap-2 font-mono text-[0.7rem]">
            <button
              onClick={() => setActiveTab('presets')}
              className={`px-3 py-1.5 rounded-lg border font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'presets'
                  ? 'bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] border-[#00f0ff] shadow-[0_0_12px_rgba(0,240,255,0.3)]'
                  : 'bg-[#121422] border-[#222538] text-[#94a3b8] hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Curated Presets ({presets.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('ai')}
              className={`px-3 py-1.5 rounded-lg border font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'ai'
                  ? 'bg-gradient-to-r from-[#a855f7] to-[#c084fc] text-[#07070a] border-[#a855f7] shadow-[0_0_12px_rgba(168,85,247,0.3)]'
                  : 'bg-[#121422] border-[#222538] text-[#94a3b8] hover:text-white'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>AI Prompt Generator</span>
            </button>

            <button
              onClick={() => setActiveTab('custom')}
              className={`px-3 py-1.5 rounded-lg border font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'custom'
                  ? 'bg-gradient-to-r from-[#00ff9d] to-[#10b981] text-[#07070a] border-[#00ff9d] shadow-[0_0_12px_rgba(0,255,157,0.3)]'
                  : 'bg-[#121422] border-[#222538] text-[#94a3b8] hover:text-white'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Fine-Tuning Studio</span>
            </button>
          </div>

          <div className="flex items-center gap-2 font-mono text-[0.68rem] text-[#94a3b8]">
            <span className="flex items-center gap-1">
              {currentTheme.mode === 'light' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-[#00f0ff]" />}
              {currentTheme.mode.toUpperCase()} MODE
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-[#f8fafc] relative z-10">
          {/* TAB 1: CURATED PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold">
                  Select Visual Architecture Preset
                </span>
                <span className="font-mono text-[0.65rem] text-[#94a3b8]">
                  Click any theme card to activate live
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {presets.map((preset) => {
                  const isActive = currentTheme.id === preset.id;
                  return (
                    <div
                      key={preset.id}
                      onClick={() => selectPreset(preset.id)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between group relative overflow-hidden ${
                        isActive
                          ? 'bg-[#121422] border-[#00f0ff] shadow-[0_0_20px_rgba(0,240,255,0.2)]'
                          : 'bg-[#0e101a] border-[#222538] hover:border-[#384060] hover:bg-[#141624]'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <span className="font-display text-[1.1rem] font-bold text-white group-hover:text-[#00f0ff] transition-colors">
                              {preset.name}
                            </span>
                            {preset.mode === 'light' && (
                              <span className="font-mono text-[0.58rem] bg-amber-400/20 text-amber-300 border border-amber-400/40 px-1.5 py-0.2 rounded font-bold">
                                LIGHT
                              </span>
                            )}
                          </div>
                          {isActive && (
                            <span className="flex items-center gap-1 font-mono text-[0.62rem] text-[#00ff9d] bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 rounded font-bold shadow-[0_0_8px_rgba(0,255,157,0.3)]">
                              <CheckCircle2 className="w-3 h-3" /> ACTIVE
                            </span>
                          )}
                        </div>

                        <p className="font-sans text-[0.78rem] text-[#94a3b8] leading-relaxed line-clamp-2">
                          {preset.description}
                        </p>
                      </div>

                      {/* Swatch preview bar */}
                      <div className="mt-3.5 pt-3 border-t border-[#1d2030] flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.colors.bg }}
                            title="Background"
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.colors.neonCyan }}
                            title="Primary Accent"
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.colors.neonMagenta }}
                            title="Secondary Accent"
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.colors.neonPurple }}
                            title="Tertiary Accent"
                          />
                          <span
                            className="w-4 h-4 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: preset.colors.neonEmerald }}
                            title="Emerald Accent"
                          />
                        </div>

                        <span className="font-mono text-[0.62rem] uppercase text-[#64748b] group-hover:text-white transition-colors">
                          {preset.pattern}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: AI THEME GENERATOR */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              {/* Prompt Input Box */}
              <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 shadow-xl space-y-4">
                <div>
                  <label className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#a855f7] font-bold block mb-1.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#c084fc]" />
                    Natural Language Theme Synthesizer
                  </label>
                  <p className="font-sans text-[0.82rem] text-[#94a3b8] leading-relaxed">
                    Type any mood, color pair, game theme, or visual concept. The dynamic engine will compute a cohesive, WCAG-harmonized palette with 5 neon highlights.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <input
                    type="text"
                    value={promptInput}
                    onChange={(e) => setPromptInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleGenerate();
                    }}
                    placeholder="e.g. 'Volcanic magma & solar gold', 'Nordic glacier ice', 'Cyberpunk purple neon'..."
                    className="flex-1 px-4 py-2.5 bg-[#080910] border border-[#222538] rounded-lg font-mono text-[0.82rem] text-white outline-none focus:border-[#a855f7] focus:ring-1 focus:ring-[#a855f7] shadow-inner"
                  />
                  <button
                    onClick={() => handleGenerate()}
                    disabled={isGenerating || !promptInput.trim()}
                    className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#a855f7] to-[#c084fc] text-[#07070a] font-mono text-[0.75rem] font-bold uppercase tracking-wider hover:brightness-110 shadow-[0_0_15px_rgba(168,85,247,0.4)] transition-all disabled:opacity-40 cursor-pointer flex items-center justify-center gap-2 shrink-0"
                  >
                    <Wand2 className="w-4 h-4" />
                    <span>{isGenerating ? 'Synthesizing...' : 'Synthesize Theme'}</span>
                  </button>
                </div>

                {/* Prompt Suggestions */}
                <div>
                  <span className="font-mono text-[0.62rem] uppercase text-[#64748b] block mb-2 font-bold">
                    Quick Inspiration Prompts:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {inspirationPrompts.map((prompt, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setPromptInput(prompt);
                          handleGenerate(prompt);
                        }}
                        className="font-mono text-[0.68rem] px-2.5 py-1 rounded-md border border-[#222538] bg-[#0c0d15] text-[#94a3b8] hover:border-[#a855f7] hover:text-white transition-all cursor-pointer"
                      >
                        {prompt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Current Active Theme Preview Card */}
              <div className="bg-[#0e101a] border border-[#222538] rounded-xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold">
                    Active Generated Result
                  </span>
                  <span className="font-mono text-[0.65rem] text-[#94a3b8]">
                    ID: {currentTheme.id}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="font-display text-[1.3rem] font-bold text-white">
                    {currentTheme.name}
                  </div>
                  <span className="font-mono text-[0.65rem] uppercase px-2 py-0.5 rounded border border-[#00f0ff]/40 bg-[#00f0ff]/10 text-[#00f0ff]">
                    {currentTheme.pattern}
                  </span>
                </div>

                <p className="font-sans text-[0.82rem] text-[#94a3b8]">
                  {currentTheme.description}
                </p>

                <div className="flex items-center gap-2 pt-2 border-t border-[#1f2235]">
                  <span className="font-mono text-[0.65rem] text-[#64748b]">Active Palette:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-md shadow-md border border-white/10" style={{ backgroundColor: currentTheme.colors.neonCyan }} title="Cyan Accent" />
                    <span className="w-5 h-5 rounded-md shadow-md border border-white/10" style={{ backgroundColor: currentTheme.colors.neonMagenta }} title="Magenta Accent" />
                    <span className="w-5 h-5 rounded-md shadow-md border border-white/10" style={{ backgroundColor: currentTheme.colors.neonPurple }} title="Purple Accent" />
                    <span className="w-5 h-5 rounded-md shadow-md border border-white/10" style={{ backgroundColor: currentTheme.colors.neonEmerald }} title="Emerald Accent" />
                    <span className="w-5 h-5 rounded-md shadow-md border border-white/10" style={{ backgroundColor: currentTheme.colors.neonAmber }} title="Amber Accent" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FINE TUNING */}
          {activeTab === 'custom' && (
            <div className="space-y-6">
              {/* Pattern Selector */}
              <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 space-y-3">
                <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#00f0ff] font-bold block">
                  Background Watermark & Geometry Grid
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {(['cyber-grid', 'dot-matrix', 'hex-mesh', 'aurora-waves', 'minimal-clean'] as BackgroundPattern[]).map((pat) => {
                    const isSelected = currentTheme.pattern === pat;
                    return (
                      <button
                        key={pat}
                        onClick={() => handlePatternChange(pat)}
                        className={`p-3 rounded-lg border font-mono text-[0.7rem] uppercase font-bold transition-all cursor-pointer text-center ${
                          isSelected
                            ? 'bg-[#00f0ff]/20 text-[#00f0ff] border-[#00f0ff] shadow-[0_0_10px_rgba(0,240,255,0.3)]'
                            : 'bg-[#080910] border-[#222538] text-[#94a3b8] hover:text-white'
                        }`}
                      >
                        {pat.replace('-', ' ')}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Accent Color Customizers */}
              <div className="bg-[#121422] border border-[#222538] rounded-xl p-5 space-y-4">
                <span className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-[#00ff9d] font-bold block">
                  Interactive Accent Color Override
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="font-mono text-[0.65rem] text-[#94a3b8] block mb-1.5">
                      Primary Electric Accent:
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={currentTheme.colors.neonCyan}
                        onChange={(e) => handleColorChange('neonCyan', e.target.value)}
                        className="w-8 h-8 rounded border border-[#222538] bg-transparent cursor-pointer"
                      />
                      <input
                        type="text"
                        value={currentTheme.colors.neonCyan}
                        onChange={(e) => handleColorChange('neonCyan', e.target.value)}
                        className="flex-1 px-3 py-1 bg-[#080910] border border-[#222538] rounded font-mono text-[0.75rem] text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-mono text-[0.65rem] text-[#94a3b8] block mb-1.5">
                      Secondary Pulse Accent:
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={currentTheme.colors.neonMagenta}
                        onChange={(e) => handleColorChange('neonMagenta', e.target.value)}
                        className="w-8 h-8 rounded border border-[#222538] bg-transparent cursor-pointer"
                      />
                      <input
                        type="text"
                        value={currentTheme.colors.neonMagenta}
                        onChange={(e) => handleColorChange('neonMagenta', e.target.value)}
                        className="flex-1 px-3 py-1 bg-[#080910] border border-[#222538] rounded font-mono text-[0.75rem] text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-mono text-[0.65rem] text-[#94a3b8] block mb-1.5">
                      Tertiary Luminescence:
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={currentTheme.colors.neonPurple}
                        onChange={(e) => handleColorChange('neonPurple', e.target.value)}
                        className="w-8 h-8 rounded border border-[#222538] bg-transparent cursor-pointer"
                      />
                      <input
                        type="text"
                        value={currentTheme.colors.neonPurple}
                        onChange={(e) => handleColorChange('neonPurple', e.target.value)}
                        className="flex-1 px-3 py-1 bg-[#080910] border border-[#222538] rounded font-mono text-[0.75rem] text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Live Preview Sample */}
          <div className="bg-[#0e101a] border border-[#222538] rounded-xl p-5 space-y-3">
            <span className="font-mono text-[0.62rem] uppercase tracking-[0.2em] text-[#ffbe0b] font-bold block">
              Live Component Preview in "{currentTheme.name}"
            </span>

            <div className="flex flex-wrap items-center gap-3">
              <button
                className="px-4 py-2 rounded-lg font-mono text-[0.7rem] font-bold uppercase tracking-wider"
                style={{
                  background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonMagenta})`,
                  color: '#07070a',
                  boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                Sample Action Button
              </button>

              <span
                className="px-3 py-1 rounded font-mono text-[0.65rem] font-bold uppercase"
                style={{
                  backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                  color: currentTheme.colors.neonEmerald,
                  border: `1px solid ${currentTheme.colors.neonEmerald}50`,
                }}
              >
                Passed 10/10
              </span>

              <span
                className="px-3 py-1 rounded font-mono text-[0.65rem] font-bold uppercase"
                style={{
                  backgroundColor: `${currentTheme.colors.neonPurple}20`,
                  color: currentTheme.colors.neonPurple,
                  border: `1px solid ${currentTheme.colors.neonPurple}50`,
                }}
              >
                Curriculum Day 07
              </span>

              <span
                className="px-3 py-1 rounded font-mono text-[0.65rem] font-bold uppercase"
                style={{
                  backgroundColor: `${currentTheme.colors.neonAmber}20`,
                  color: currentTheme.colors.neonAmber,
                  border: `1px solid ${currentTheme.colors.neonAmber}50`,
                }}
              >
                Medium Difficulty
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-[#121422] border-t border-[#222538] p-4 flex items-center justify-between shrink-0 relative z-10">
          <button
            onClick={resetToDefaultTheme}
            className="font-mono text-[0.68rem] text-[#94a3b8] hover:text-white px-3 py-1.5 rounded-lg border border-[#222538] hover:border-[#475569] transition-all cursor-pointer"
          >
            Reset to Cyberpunk Nova
          </button>

          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-[#00f0ff] to-[#38bdf8] text-[#07070a] font-mono text-[0.72rem] font-black uppercase tracking-wider hover:brightness-110 shadow-[0_0_15px_rgba(0,240,255,0.4)] transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Apply & Save Theme</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
