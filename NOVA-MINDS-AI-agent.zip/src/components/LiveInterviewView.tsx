import React, { useState, useRef, useEffect } from 'react';
import {
  CheckCircle2,
  Zap,
  Send,
  BrainCircuit,
  Activity,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  HelpCircle,
  Code,
  Layers,
  ChevronRight,
  TrendingUp,
  User,
  ShieldAlert,
  Sparkles,
  Terminal,
  Award,
  BarChart3,
  RefreshCw,
  Maximize2,
  FileCode,
  Radio,
  Play,
  Flame,
  Check,
  RotateCcw,
  Compass,
  MessageSquare,
  Users,
} from 'lucide-react';
import {
  CandidateProfile,
  InterviewSessionState,
  AnswerEvaluation,
} from '../server/types';
import { CurriculumService } from '../server/curriculumService';
import { useTheme } from '../theme/ThemeContext';

interface LiveInterviewViewProps {
  session: InterviewSessionState | null;
  candidate: CandidateProfile;
  candidates?: CandidateProfile[];
  onSendMessage: (message: string) => Promise<void>;
  isLoading: boolean;
  onViewFeedback: () => void;
  onSelectCandidate?: (candidate: CandidateProfile) => void;
  onOpenCatchAllChats?: () => void;
  onOpenDedicatedQA?: () => void;
  onOpenScoreDisplay?: () => void;
}

export const LiveInterviewView: React.FC<LiveInterviewViewProps> = ({
  session,
  candidate,
  candidates = [],
  onSendMessage,
  isLoading,
  onViewFeedback,
  onSelectCandidate,
  onOpenCatchAllChats,
  onOpenDedicatedQA,
  onOpenScoreDisplay,
}) => {
  const { currentTheme } = useTheme();
  const [mobileView, setMobileView] = useState<'chat' | 'intel'>('chat');
  const [inputText, setInputText] = useState('');
  const [isAudioEnabled, setIsAudioEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [qaBarHeight, setQaBarHeight] = useState<'standard' | 'large' | 'massive'>('large');
  const [showCodeScratchpad, setShowCodeScratchpad] = useState(false);
  const [scratchpadCode, setScratchpadCode] = useState(
    `# Python / FastAPI + ChromaDB Scratchpad
from fastapi import FastAPI
from chromadb import PersistentClient
from sentence_transformers import SentenceTransformer

app = FastAPI(title="Healthcare RAG Service")
encoder = SentenceTransformer("all-MiniLM-L6-v2")
chroma = PersistentClient(path="./chroma_db")
collection = chroma.get_or_create_collection("clinical_guidelines")

@app.post("/query")
async def query_kb(text: str, top_k: int = 5):
    query_vec = encoder.encode([text])[0].tolist()
    results = collection.query(query_embeddings=[query_vec], n_results=top_k)
    return {"matches": results["documents"][0], "distances": results["distances"][0]}`
  );
  const [activePresetCategory, setActivePresetCategory] = useState<'all' | 'senior' | 'hands_on' | 'flawed' | 'clarify'>('all');
  const [showPresets, setShowPresets] = useState(true);

  const chatBottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-scroll chat to latest message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.conversationHistory, isLoading]);

  // Web Speech API: Text-to-Speech for Interviewer Questions
  useEffect(() => {
    if (!isAudioEnabled || !session?.conversationHistory?.length) return;
    const lastTurn = session.conversationHistory[session.conversationHistory.length - 1];
    if (lastTurn.role === 'interviewer' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(lastTurn.content);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    }
  }, [session?.conversationHistory?.length, isAudioEnabled]);

  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setStatusNotice(msg);
    setTimeout(() => setStatusNotice(null), 4000);
  };

  // Web Speech API: Speech-to-Text Dictation for Candidate
  const toggleSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      showNotice('Speech recognition is not supported in this browser environment. You can type or use the presets below.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          transcript += event.results[i][0].transcript;
        }
        setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.onerror = (err: any) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
      recognitionRef.current = recognition;
      setIsListening(true);
    } catch (e) {
      console.warn('Failed to start speech recognition:', e);
      setIsListening(false);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;
    const msg = inputText.trim();
    setInputText('');
    await onSendMessage(msg);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Rich, realistic candidate answer presets representing diverse archetypes
  const allAnswerPresets = [
    {
      category: 'senior',
      badge: '🌟 Senior Staff Architecture',
      title: 'Dense Vectors & HNSW Indexing',
      text: 'In our pipeline, we generated 384-dimensional dense vectors using Sentence Transformers (all-MiniLM-L6-v2) across 512-token chunks with 50-token overlap. For similarity, we used cosine distance in ChromaDB with HNSW indexing, and paired it with an SQLite query router for structured claims metadata lookups before passing the top-5 re-ranked chunks to the LLM at 0.2 temperature.',
    },
    {
      category: 'hands_on',
      badge: '🛠️ Production Implementation',
      title: 'FastAPI Router & Deduplication',
      text: 'We built an asynchronous FastAPI service with a hybrid query router: structured queries match SQLite claim tables directly, while clinical notes hit ChromaDB with a score threshold of 0.72. We then deduplicate results using a reciprocal rank fusion (RRF) algorithm to balance keyword precision and semantic recall within a 120ms latency SLA.',
    },
    {
      category: 'senior',
      badge: '🤖 Multi-Agent Orchestration',
      title: 'MCP Server & CrewAI Routing',
      text: 'On Day 22 and 23, we decoupled our healthcare tools into an MCP server with strict JSON-RPC schemas. The coordinator agent delegates between a claims verification specialist and a triage specialist. The trade-off is a 180ms latency overhead for tool negotiation versus clean modularity and isolated error handling.',
    },
    {
      category: 'flawed',
      badge: '⚠️ Missing Real-World Trade-offs',
      title: 'Theoretical / Surface Answer',
      text: 'Vector databases store embeddings and we used ChromaDB to search documents and retrieve them for our chatbot to answer healthcare questions.',
    },
    {
      category: 'flawed',
      badge: '❌ Vague / Non-Technical',
      title: 'Buzzword Heavy Response',
      text: 'We just connected an AI model to our dataset and prompted it to generate answers without writing much custom code.',
    },
    {
      category: 'clarify',
      badge: '💡 Ask for Clarification',
      title: 'Clarify Latency & Token Budget',
      text: 'Could you clarify the expected QPS target and token budget for this healthcare endpoint? That will help me explain the exact chunk caching and index sharding strategy.',
    },
  ];

  const filteredPresets = activePresetCategory === 'all'
    ? allAnswerPresets
    : allAnswerPresets.filter((p) => p.category === activePresetCategory);

  // Automated 8-turn full adaptive simulation
  const handleAutoSimulate = async () => {
    if (isLoading || session?.status === 'completed') return;
    const simAnswers = [
      'Sentence transformers convert medical text into 384-dimensional dense vectors indexed in ChromaDB with cosine similarity.',
      'We implemented HNSW indexing in ChromaDB and combined semantic retrieval with SQLite metadata filtering.',
      'For the hybrid query router, structured claims data goes to SQL while clinical text searches vector embeddings.',
      'Prompt augmentation with low temperature (0.2) and BM25 re-ranking prevents hallucinations in clinical summarization.',
      'The FastAPI backend manages session state, conversation context, and response latency probes under 150ms.',
      'We built a multi-agent crew with a coordinator delegating between claims verification and triage specialists.',
      'The MCP server exposes standard JSON-RPC tools for LLM agent function calling.',
      'Containerized with Docker and deployed with Kubernetes readiness probes for enterprise healthcare compliance.',
    ];

    for (const ans of simAnswers) {
      if (session?.status === 'completed') break;
      await onSendMessage(ans);
    }
  };

  const currentDayData = session?.currentDay
    ? CurriculumService.getDay(session.currentDay)
    : CurriculumService.getDay(7);

  const latestEval: AnswerEvaluation | undefined =
    session?.answerEvaluations && session.answerEvaluations.length > 0
      ? session.answerEvaluations[session.answerEvaluations.length - 1]
      : undefined;

  // Calculate average scores across all turns for real-time trajectory
  const evals = session?.answerEvaluations || [];
  const avgScore = evals.length > 0 ? (evals.reduce((a, b) => a + b.score, 0) / evals.length).toFixed(1) : '—';
  const avgCorrectness = evals.length > 0 ? Math.round((evals.reduce((a, b) => a + b.correctness, 0) / evals.length) * 100) : 0;
  const avgDepth = evals.length > 0 ? Math.round((evals.reduce((a, b) => a + b.depth, 0) / evals.length) * 100) : 0;
  const avgPractical = evals.length > 0 ? Math.round((evals.reduce((a, b) => a + b.practicalUnderstanding, 0) / evals.length) * 100) : 0;

  return (
    <div id="live-interview-workspace" className="flex-1 flex flex-col min-h-0 overflow-hidden relative z-10">
      {/* Mobile & Tablet Section Switcher (< lg screens) */}
      <div
        className="lg:hidden flex items-center p-1 rounded-xl border mb-2.5 shrink-0 shadow-sm select-none"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <button
          onClick={() => setMobileView('chat')}
          className="flex-1 py-1.5 px-3 rounded-lg font-mono text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          style={{
            backgroundColor: mobileView === 'chat' ? `${currentTheme.colors.neonCyan}25` : 'transparent',
            borderColor: mobileView === 'chat' ? currentTheme.colors.neonCyan : 'transparent',
            borderWidth: '1px',
            color: mobileView === 'chat' ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
            boxShadow: mobileView === 'chat' ? `0 0 10px ${currentTheme.colors.primaryGlow}` : 'none',
          }}
        >
          <Radio className="w-3.5 h-3.5" />
          <span>Interactive Q/A Studio</span>
        </button>
        <button
          onClick={() => setMobileView('intel')}
          className="flex-1 py-1.5 px-3 rounded-lg font-mono text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          style={{
            backgroundColor: mobileView === 'intel' ? `${currentTheme.colors.neonMagenta}25` : 'transparent',
            borderColor: mobileView === 'intel' ? currentTheme.colors.neonMagenta : 'transparent',
            borderWidth: '1px',
            color: mobileView === 'intel' ? currentTheme.colors.neonMagenta : currentTheme.colors.inkMuted,
            boxShadow: mobileView === 'intel' ? `0 0 10px ${currentTheme.colors.secondaryGlow}` : 'none',
          }}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Candidate & Intel (Q{session?.questionCount || 1}/8)</span>
        </button>
      </div>

      {/* Main Grid / Stacked Workspace */}
      <div className="flex-1 flex flex-col lg:grid lg:grid-cols-[1fr_360px] gap-4 lg:gap-6 overflow-hidden min-h-0 relative">
        {/* Left: Interactive Interview Canvas */}
        <div
          className={`flex-1 flex flex-col rounded-xl overflow-hidden backdrop-blur-xl relative shadow-2xl border transition-colors ${
            mobileView === 'intel' ? 'hidden lg:flex' : 'flex'
          }`}
          style={{
            backgroundColor: `${currentTheme.colors.bgSurface}ee`,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
        {/* Virtual Ambient Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        {/* Top Canvas Bar with Catchy Mission Control & Candidate Quick-Switch */}
        <div
          className="p-4 md:p-5 border-b flex flex-col gap-3 select-none relative z-10 transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          {/* Top Row: Mission Control Header & Live Audio Equalizer */}
          <div className="flex flex-wrap justify-between items-center gap-3">
            <div className="flex items-center gap-3">
              <div
                className="w-9 h-9 rounded-xl p-[1.5px] shadow-md flex items-center justify-center shrink-0"
                style={{
                  background: `linear-gradient(to top right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple}, ${currentTheme.colors.neonMagenta})`,
                  boxShadow: `0 0 16px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                <div
                  className="w-full h-full rounded-[10px] flex items-center justify-center"
                  style={{ backgroundColor: currentTheme.colors.bg }}
                >
                  <Radio className="w-4 h-4 animate-pulse" style={{ color: currentTheme.colors.neonCyan }} />
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3
                    className="font-display text-[1.15rem] md:text-[1.3rem] font-black tracking-tight flex items-center gap-2"
                    style={{ color: currentTheme.colors.ink }}
                  >
                    <span>AI Technical Assessment & Candidate Engine</span>
                  </h3>
                  <span
                    className="font-mono text-[0.6rem] px-2 py-0.5 rounded-full border font-bold uppercase tracking-wider hidden sm:inline-flex items-center gap-1"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonCyan}18`,
                      borderColor: `${currentTheme.colors.neonCyan}44`,
                      color: currentTheme.colors.neonCyan,
                    }}
                  >
                    <Sparkles className="w-2.5 h-2.5" />
                    v3.8 Grounded
                  </span>
                </div>
                <p className="text-[0.72rem] font-sans flex items-center gap-2" style={{ color: currentTheme.colors.inkMuted }}>
                  <span>Evaluating live system architecture, vector indexing, and multi-agent coordination</span>
                  <span className="opacity-40">•</span>
                  <span className="font-mono font-bold" style={{ color: currentTheme.colors.neonPurple }}>
                    Day {session?.currentDay || 7}: {session?.currentTopic || 'Embeddings Explained'}
                  </span>
                </p>
              </div>
            </div>

            {/* Live Audio Equalizer Waveform & Voice Controls */}
            <div className="flex items-center gap-2.5">
              {/* Animated Sound Waveform Bars */}
              <div
                className="px-2.5 py-1.5 rounded-lg border flex items-center gap-1 shadow-xs"
                style={{
                  backgroundColor: currentTheme.colors.bgSurface,
                  borderColor: isAudioEnabled || isListening ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                }}
                title={isListening ? 'Microphone listening...' : isAudioEnabled ? 'Voice read-aloud active' : 'Audio telemetry standby'}
              >
                <div className="flex items-end gap-[3px] h-4">
                  {[0.4, 0.8, 0.5, 1.0, 0.7, 0.9, 0.6, 0.4].map((h, i) => (
                    <span
                      key={i}
                      className="w-[3px] rounded-full transition-all"
                      style={{
                        height: isAudioEnabled || isListening ? `${h * 100}%` : '30%',
                        backgroundColor: i % 2 === 0 ? currentTheme.colors.neonCyan : currentTheme.colors.neonMagenta,
                        animation: isAudioEnabled || isListening ? `pulse 1s infinite alternate ${i * 0.15}s` : 'none',
                      }}
                    />
                  ))}
                </div>
                <span className="font-mono text-[0.6rem] font-bold uppercase ml-1" style={{ color: isAudioEnabled || isListening ? currentTheme.colors.neonCyan : currentTheme.colors.inkFaint }}>
                  {isListening ? 'MIC REC' : isAudioEnabled ? 'VOICE ON' : 'AUDIO STANDBY'}
                </span>
              </div>

              {/* Audio Read-Aloud Toggle */}
              <button
                onClick={() => setIsAudioEnabled(!isAudioEnabled)}
                className="font-mono text-[0.65rem] font-bold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
                style={{
                  backgroundColor: isAudioEnabled ? `${currentTheme.colors.neonCyan}25` : currentTheme.colors.bgSurface,
                  borderColor: isAudioEnabled ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                  color: isAudioEnabled ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                }}
                title="Toggle Audio Read-Aloud for Interviewer Questions"
              >
                {isAudioEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{isAudioEnabled ? 'Voice ON' : 'Muted'}</span>
              </button>

              {/* Dedicated Q/A Studio Page Button */}
              {onOpenDedicatedQA && (
                <button
                  id="btn-live-open-dedicated-qa"
                  onClick={onOpenDedicatedQA}
                  className="font-mono text-[0.68rem] font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-sm hover:brightness-110"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}25`,
                    borderColor: currentTheme.colors.neonCyan,
                    color: currentTheme.colors.neonCyan,
                    boxShadow: `0 0 12px ${currentTheme.colors.primaryGlow}`,
                  }}
                  title="Open Dedicated Q&A Studio with Generous Space for Questions & Responses"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Q&A Studio</span>
                  <span
                    className="font-mono text-[0.55rem] px-1 rounded border font-black uppercase"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonCyan}33`,
                      borderColor: currentTheme.colors.neonCyan,
                      color: currentTheme.colors.neonCyan,
                    }}
                  >
                    SPACIOUS
                  </span>
                </button>
              )}

              {/* Dedicated Score Display Button */}
              {onOpenScoreDisplay && (
                <button
                  id="btn-live-open-scores"
                  onClick={onOpenScoreDisplay}
                  className="font-mono text-[0.68rem] font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-sm hover:brightness-110"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                    borderColor: currentTheme.colors.neonEmerald,
                    color: currentTheme.colors.neonEmerald,
                  }}
                  title="Open Dedicated Score Display & Performance Analytics Matrix"
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Score Display</span>
                  <span
                    className="font-mono text-[0.55rem] px-1 rounded border font-black uppercase"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonEmerald}33`,
                      borderColor: currentTheme.colors.neonEmerald,
                      color: currentTheme.colors.neonEmerald,
                    }}
                  >
                    LIVE
                  </span>
                </button>
              )}

              {/* Code Scratchpad Toggle */}
              <button
                onClick={() => setShowCodeScratchpad(!showCodeScratchpad)}
                className="font-mono text-[0.65rem] font-bold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
                style={{
                  backgroundColor: showCodeScratchpad ? `${currentTheme.colors.neonPurple}25` : currentTheme.colors.bgSurface,
                  borderColor: showCodeScratchpad ? currentTheme.colors.neonPurple : currentTheme.colors.borderDark,
                  color: showCodeScratchpad ? currentTheme.colors.neonPurple : currentTheme.colors.inkMuted,
                }}
                title="Open Technical Code & Architecture Scratchpad"
              >
                <Code className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Scratchpad</span>
              </button>

              {/* Catch All Chats Single-File Button */}
              {onOpenCatchAllChats && (
                <button
                  id="btn-live-catch-all-chats"
                  onClick={onOpenCatchAllChats}
                  className="font-mono text-[0.65rem] font-bold px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}20`,
                    borderColor: currentTheme.colors.neonCyan,
                    color: currentTheme.colors.neonCyan,
                  }}
                  title="Catch and export all chats and transcripts into a single file"
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Catch All Chats</span>
                  <span
                    className="font-mono text-[0.55rem] px-1 rounded border font-bold"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonEmerald}22`,
                      borderColor: currentTheme.colors.neonEmerald,
                      color: currentTheme.colors.neonEmerald,
                    }}
                  >
                    1 FILE
                  </span>
                </button>
              )}

              {session?.status === 'completed' ? (
                <button
                  id="btn-view-feedback-banner"
                  onClick={onViewFeedback}
                  className="font-mono text-[0.68rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-lg shadow-md hover:brightness-110 transition-all flex items-center gap-1.5 cursor-pointer font-black"
                  style={{
                    background: `linear-gradient(to right, ${currentTheme.colors.neonEmerald}, #10b981)`,
                    color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                    boxShadow: `0 0 14px ${currentTheme.colors.neonEmerald}77`,
                  }}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Evaluation Report</span>
                </button>
              ) : (
                <span
                  className="font-mono text-[0.62rem] uppercase tracking-[0.15em] px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-bold"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonEmerald}18`,
                    borderColor: `${currentTheme.colors.neonEmerald}40`,
                    color: currentTheme.colors.neonEmerald,
                  }}
                >
                  <span
                    className="w-1.5 h-1.5 rounded-full animate-ping"
                    style={{ backgroundColor: currentTheme.colors.neonEmerald }}
                  />
                  LIVE ASSESSMENT
                </span>
              )}
            </div>
          </div>

          {/* Bottom Row: Candidate Quick-Switch Carousel */}
          {candidates && candidates.length > 0 && onSelectCandidate && (
            <div className="flex items-center gap-2 pt-2 border-t overflow-x-auto no-scrollbar" style={{ borderColor: `${currentTheme.colors.borderDark}66` }}>
              <div className="flex items-center gap-1 shrink-0">
                <Users className="w-3 h-3" style={{ color: currentTheme.colors.neonMagenta }} />
                <span className="font-mono text-[0.58rem] uppercase font-bold tracking-wider" style={{ color: currentTheme.colors.inkMuted }}>
                  Quick Switch Candidate:
                </span>
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
                {candidates.slice(0, 8).map((c) => {
                  const isCurSelected = c.member.id === candidate.member.id;
                  return (
                    <button
                      key={c.member.id}
                      onClick={() => onSelectCandidate(c)}
                      className={`font-mono text-[0.62rem] px-2.5 py-1 rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-xs ${
                        isCurSelected ? 'font-black scale-[1.02]' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: isCurSelected
                          ? `${currentTheme.colors.neonCyan}25`
                          : currentTheme.colors.bgSurface,
                        borderColor: isCurSelected
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.borderDark,
                        color: isCurSelected
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.inkMuted,
                        boxShadow: isCurSelected ? `0 0 10px ${currentTheme.colors.primaryGlow}` : 'none',
                      }}
                      title={`Switch to ${c.member.name} (${c.member.jobRole})`}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full font-bold text-[0.5rem] flex items-center justify-center"
                        style={{
                          backgroundColor: isCurSelected
                            ? currentTheme.colors.neonCyan
                            : currentTheme.colors.borderDark,
                          color: isCurSelected ? '#000' : currentTheme.colors.ink,
                        }}
                      >
                        {c.member.name.charAt(0)}
                      </span>
                      <span className="truncate max-w-[90px]">{c.member.name.split(' ')[0]}</span>
                      <span className="opacity-60 text-[0.55rem] hidden sm:inline">({c.member.jobRole.split(' ')[0]})</span>
                      {isCurSelected && (
                        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: currentTheme.colors.neonCyan }} />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {statusNotice && (
            <div
              className="px-3.5 py-1.5 rounded-lg border font-mono text-[0.7rem] font-bold flex items-center justify-between animate-in fade-in slide-in-from-top-1"
              style={{
                backgroundColor: `${currentTheme.colors.neonMagenta}20`,
                borderColor: currentTheme.colors.neonMagenta,
                color: currentTheme.colors.neonMagenta,
              }}
            >
              <span>{statusNotice}</span>
              <button onClick={() => setStatusNotice(null)} className="cursor-pointer opacity-70 hover:opacity-100 ml-2">✕</button>
            </div>
          )}
        </div>

        {/* Code Scratchpad Overlay */}
        {showCodeScratchpad && (
          <div
            className="p-4 border-b relative z-20 flex flex-col gap-2 transition-all shadow-inner"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4" style={{ color: currentTheme.colors.neonCyan }} />
                <span className="font-mono text-[0.72rem] font-bold" style={{ color: currentTheme.colors.ink }}>
                  Technical Architecture & Code Scratchpad
                </span>
              </div>
              <button
                onClick={() => setInputText((prev) => `${prev}\n\n\`\`\`python\n${scratchpadCode}\n\`\`\``)}
                className="font-mono text-[0.62rem] px-2.5 py-1 rounded border font-bold hover:brightness-110 cursor-pointer"
                style={{
                  backgroundColor: `${currentTheme.colors.neonCyan}20`,
                  borderColor: currentTheme.colors.neonCyan,
                  color: currentTheme.colors.neonCyan,
                }}
              >
                Insert Code into Response
              </button>
            </div>
            <textarea
              rows={4}
              value={scratchpadCode}
              onChange={(e) => setScratchpadCode(e.target.value)}
              className="w-full font-mono text-[0.78rem] p-3 rounded-lg border outline-none resize-y"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.ink,
              }}
            />
          </div>
        )}

        {/* Conversation Message Log */}
        <div className="flex-1 p-6 md:p-7 overflow-y-auto space-y-6 relative z-10">
          {/* Active Question Spotlight Banner */}
          {(() => {
            const lastInterviewerTurn = session?.conversationHistory
              ? [...session.conversationHistory].reverse().find((t) => t.role === 'interviewer')
              : null;
            const activeQuestionText =
              lastInterviewerTurn?.content ||
              session?.currentQuestion ||
              `Welcome ${candidate.member.name}. Could you explain how you converted raw text documents into dense vector embeddings and how semantic similarity search works under the hood?`;

            return (
              <div
                className="p-5 md:p-6 rounded-2xl border shadow-lg relative select-none transition-all"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: `${currentTheme.colors.neonCyan}66`,
                  boxShadow: `0 0 20px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className="font-mono text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded border flex items-center gap-1.5"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}20`,
                        borderColor: currentTheme.colors.neonCyan,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      <BrainCircuit className="w-3.5 h-3.5" />
                      <span>ACTIVE QUESTION ASKED [Q{session?.questionCount || 1}/8]</span>
                    </span>
                    <span
                      className="font-mono text-xs px-2 py-0.5 rounded border font-bold"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonPurple}18`,
                        borderColor: `${currentTheme.colors.neonPurple}33`,
                        color: currentTheme.colors.neonPurple,
                      }}
                    >
                      Day {session?.currentDay || 7} • {session?.currentTopic || 'Embeddings Explained'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        if ('speechSynthesis' in window) {
                          window.speechSynthesis.cancel();
                          const utterance = new SpeechSynthesisUtterance(activeQuestionText.replace(/[*#`_-]/g, ' '));
                          window.speechSynthesis.speak(utterance);
                        }
                      }}
                      className="font-mono text-xs px-2.5 py-1 rounded-lg border font-bold flex items-center gap-1 transition-all cursor-pointer hover:brightness-110"
                      style={{
                        backgroundColor: currentTheme.colors.bgSurface,
                        borderColor: currentTheme.colors.neonCyan,
                        color: currentTheme.colors.neonCyan,
                      }}
                      title="Read active question aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Listen</span>
                    </button>

                    {onOpenDedicatedQA && (
                      <button
                        onClick={onOpenDedicatedQA}
                        className="font-mono text-xs px-2.5 py-1 rounded-lg border font-bold flex items-center gap-1 transition-all cursor-pointer hover:brightness-110 shadow-xs"
                        style={{
                          backgroundColor: `${currentTheme.colors.neonCyan}20`,
                          borderColor: currentTheme.colors.neonCyan,
                          color: currentTheme.colors.neonCyan,
                        }}
                        title="Open Dedicated Full-Screen Q/A Page"
                      >
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>Dedicated Q/A Page</span>
                      </button>
                    )}
                  </div>
                </div>

                <div
                  className="font-serif text-[1.18rem] md:text-[1.34rem] font-semibold leading-[1.65]"
                  style={{ color: currentTheme.colors.ink }}
                >
                  {activeQuestionText}
                </div>
              </div>
            );
          })()}

          {session?.conversationHistory.map((turn, index) => {
            const isInterviewer = turn.role === 'interviewer';
            const turnNum = String(Math.floor(index / 2) + 1).padStart(2, '0');

            return (
              <div
                key={index}
                className={`p-5 md:p-6 rounded-xl transition-all border shadow-sm ${
                  isInterviewer ? 'border' : 'ml-4 md:ml-10 border'
                }`}
                style={{
                  backgroundColor: isInterviewer
                    ? currentTheme.colors.bgCard
                    : `${currentTheme.colors.bgCardHover}ee`,
                  borderColor: isInterviewer
                    ? `${currentTheme.colors.neonCyan}44`
                    : currentTheme.colors.borderDark,
                }}
              >
                {/* Block Header */}
                <div className="mb-3.5 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className="font-mono text-[0.68rem] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded border flex items-center gap-1.5"
                      style={{
                        backgroundColor: isInterviewer
                          ? `${currentTheme.colors.neonCyan}18`
                          : `${currentTheme.colors.neonMagenta}18`,
                        color: isInterviewer
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.neonMagenta,
                        borderColor: isInterviewer
                          ? `${currentTheme.colors.neonCyan}40`
                          : `${currentTheme.colors.neonMagenta}40`,
                      }}
                    >
                      {isInterviewer ? (
                        <>
                          <BrainCircuit className="w-3 h-3" />
                          <span>NOVA MIND AGENT [{turnNum}]</span>
                        </>
                      ) : (
                        <>
                          <User className="w-3 h-3" />
                          <span>CANDIDATE: {candidate.member.name} [{turnNum}]</span>
                        </>
                      )}
                    </span>

                    {turn.curriculumDay && (
                      <span
                        className="font-mono text-[0.62rem] px-2 py-0.5 rounded border font-bold"
                        style={{
                          backgroundColor: `${currentTheme.colors.neonPurple}18`,
                          color: currentTheme.colors.neonPurple,
                          borderColor: `${currentTheme.colors.neonPurple}33`,
                        }}
                      >
                        Day {turn.curriculumDay} • {turn.topic || 'Core Architecture'}
                      </span>
                    )}

                    {turn.difficulty && (
                      <span
                        className="font-mono text-[0.6rem] px-2 py-0.5 rounded border uppercase"
                        style={{
                          backgroundColor: `${currentTheme.colors.neonEmerald}14`,
                          color: currentTheme.colors.neonEmerald,
                          borderColor: `${currentTheme.colors.neonEmerald}33`,
                        }}
                      >
                        {turn.difficulty}
                      </span>
                    )}
                  </div>

                  <span
                    className="font-mono text-[0.62rem]"
                    style={{ color: currentTheme.colors.inkFaint }}
                  >
                    {new Date(turn.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Text Content */}
                <div
                  className={
                    isInterviewer
                      ? 'font-serif text-[1.05rem] leading-[1.68] font-medium'
                      : 'font-sans text-[0.92rem] leading-relaxed'
                  }
                  style={{
                    color: isInterviewer
                      ? currentTheme.colors.ink
                      : currentTheme.colors.inkMuted,
                  }}
                >
                  {turn.content}
                </div>

                {/* Turn Evaluation Badge if available */}
                {turn.evaluation && (
                  <div
                    className="mt-3.5 pt-3 border-t flex flex-wrap items-center justify-between gap-2 text-[0.72rem] font-mono"
                    style={{ borderColor: currentTheme.colors.borderDark }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="font-bold" style={{ color: currentTheme.colors.neonEmerald }}>
                        Score: {turn.evaluation.score}/10
                      </span>
                      <span style={{ color: currentTheme.colors.inkFaint }}>
                        Correctness: {Math.round(turn.evaluation.correctness * 100)}%
                      </span>
                      <span style={{ color: currentTheme.colors.inkFaint }}>
                        Depth: {Math.round(turn.evaluation.depth * 100)}%
                      </span>
                    </div>
                    <span className="italic" style={{ color: currentTheme.colors.inkMuted }}>
                      "{turn.evaluation.critique}"
                    </span>
                  </div>
                )}
              </div>
            );
          })}

          {/* Loading Indicator */}
          {isLoading && (
            <div
              className="p-4 md:p-5 rounded-xl border shadow-md animate-pulse"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.neonCyan,
                boxShadow: `0 0 20px ${currentTheme.colors.primaryGlow}`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="font-mono text-[0.65rem] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded border"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}20`,
                    color: currentTheme.colors.neonCyan,
                    borderColor: `${currentTheme.colors.neonCyan}40`,
                  }}
                >
                  NOVA MIND REASONING TRACE
                </span>
                <BrainCircuit
                  className="w-3.5 h-3.5 animate-spin"
                  style={{ color: currentTheme.colors.neonCyan }}
                />
              </div>
              <div
                className="font-serif italic text-[1.02rem]"
                style={{ color: currentTheme.colors.inkMuted }}
              >
                Analyzing technical mechanics against curriculum objectives & calibrating adaptive difficulty...
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Bottom Response & Simulation Control Tray */}
        <div
          className="p-4 md:p-6 border-t relative z-10 transition-colors flex flex-col gap-4 shadow-lg"
          style={{
            borderColor: currentTheme.colors.borderDark,
            backgroundColor: currentTheme.colors.bgCard,
          }}
        >
          {/* Active Question Dock Tab (Directly Above Input Q/A for Crystal-Clear Visibility) */}
          {(() => {
            const lastInterviewerTurn = session?.conversationHistory
              ? [...session.conversationHistory].reverse().find((t) => t.role === 'interviewer')
              : null;
            const activeQuestionText =
              lastInterviewerTurn?.content ||
              session?.currentQuestion ||
              `Welcome ${candidate.member.name}. Could you explain how you converted raw text documents into dense vector embeddings and how semantic similarity search works under the hood?`;

            return (
              <div
                className="p-4 md:p-5 rounded-2xl border shadow-md relative transition-all"
                style={{
                  backgroundColor: currentTheme.colors.bgSurface,
                  borderColor: `${currentTheme.colors.neonCyan}88`,
                  boxShadow: `0 0 16px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-3 mb-2.5 pb-2.5 border-b" style={{ borderColor: `${currentTheme.colors.borderDark}99` }}>
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="font-mono text-xs font-black uppercase tracking-wider px-3 py-1 rounded-lg border flex items-center gap-1.5 shadow-xs"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}25`,
                        borderColor: currentTheme.colors.neonCyan,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      <BrainCircuit className="w-4 h-4 animate-pulse" />
                      <span>ACTIVE QUESTION ASKED • [Q{session?.questionCount || 1}/8]</span>
                    </span>

                    <span
                      className="font-mono text-xs px-3 py-1 rounded-lg border font-bold"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonPurple}20`,
                        borderColor: `${currentTheme.colors.neonPurple}50`,
                        color: currentTheme.colors.neonPurple,
                      }}
                    >
                      Day {session?.currentDay || 7} • {session?.currentTopic || 'Embeddings Explained'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        if ('speechSynthesis' in window) {
                          window.speechSynthesis.cancel();
                          const utterance = new SpeechSynthesisUtterance(activeQuestionText.replace(/[*#`_-]/g, ' '));
                          window.speechSynthesis.speak(utterance);
                        }
                      }}
                      className="font-mono text-xs px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110 shadow-xs"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}15`,
                        borderColor: currentTheme.colors.neonCyan,
                        color: currentTheme.colors.neonCyan,
                      }}
                      title="Read active question aloud"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Listen Aloud</span>
                    </button>

                    {onOpenDedicatedQA && (
                      <button
                        onClick={onOpenDedicatedQA}
                        className="font-mono text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110 shadow-sm"
                        style={{
                          backgroundColor: `${currentTheme.colors.neonPurple}25`,
                          borderColor: currentTheme.colors.neonPurple,
                          color: currentTheme.colors.neonPurple,
                        }}
                        title="Open Dedicated Full-Screen Q/A Page with Extra-Large Canvas"
                      >
                        <Maximize2 className="w-4 h-4" />
                        <span>Dedicated Q/A Page</span>
                      </button>
                    )}
                  </div>
                </div>

                <div
                  className="font-serif text-base md:text-[1.18rem] font-semibold leading-relaxed"
                  style={{ color: currentTheme.colors.ink }}
                >
                  {activeQuestionText}
                </div>
              </div>
            );
          })()}

          {/* Expanded Tab Bar Above Input Q/A (Controls, Heights, Code & Dedicated Mode) */}
          <div
            className="p-3 md:p-3.5 rounded-xl border flex flex-wrap items-center justify-between gap-3 select-none"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            {/* Input Height Tabs */}
            <div className="flex flex-wrap items-center gap-2">
              <span
                className="font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5"
                style={{ color: currentTheme.colors.neonCyan }}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Q/A Input Height:</span>
              </span>
              <div className="flex items-center gap-1.5">
                {(
                  [
                    { id: 'standard', label: 'Standard (3 rows)' },
                    { id: 'large', label: 'Large (5 rows)' },
                    { id: 'massive', label: 'Massive (9 rows)' },
                  ] as const
                ).map((size) => (
                  <button
                    key={size.id}
                    onClick={() => setQaBarHeight(size.id)}
                    className={`font-mono text-xs px-3.5 py-1.5 rounded-lg border font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      qaBarHeight === size.id ? 'shadow-sm scale-[1.02]' : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      backgroundColor:
                        qaBarHeight === size.id
                          ? `${currentTheme.colors.neonCyan}30`
                          : `${currentTheme.colors.bgCard}`,
                      borderColor:
                        qaBarHeight === size.id
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.borderDark,
                      color:
                        qaBarHeight === size.id
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.inkMuted,
                      boxShadow: qaBarHeight === size.id ? `0 0 10px ${currentTheme.colors.primaryGlow}` : 'none',
                    }}
                  >
                    <span>{size.label}</span>
                    {qaBarHeight === size.id && <Check className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Code Scratchpad & Presets Quick Toggles */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setShowCodeScratchpad(!showCodeScratchpad)}
                className={`font-mono text-xs px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  showCodeScratchpad ? 'shadow-sm' : 'opacity-80 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: showCodeScratchpad ? `${currentTheme.colors.neonCyan}25` : currentTheme.colors.bgCard,
                  borderColor: showCodeScratchpad ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                  color: showCodeScratchpad ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                }}
                title="Toggle Python / FastAPI / Vector DB code scratchpad"
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>Code Scratchpad</span>
              </button>

              {inputText.length > 0 && (
                <span className="font-mono text-xs font-semibold px-2 py-1 rounded bg-black/10 dark:bg-white/5" style={{ color: currentTheme.colors.inkFaint }}>
                  {inputText.length} chars • {inputText.trim().split(/\s+/).filter(Boolean).length} words
                </span>
              )}

              {inputText.length > 0 && (
                <button
                  onClick={() => setInputText('')}
                  className="font-mono text-xs px-2.5 py-1 rounded-lg border font-bold opacity-80 hover:opacity-100 cursor-pointer"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.neonMagenta,
                  }}
                >
                  Clear
                </button>
              )}

              {onOpenDedicatedQA && (
                <button
                  onClick={onOpenDedicatedQA}
                  className="font-mono text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110 shadow-sm"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}20`,
                    borderColor: currentTheme.colors.neonCyan,
                    color: currentTheme.colors.neonCyan,
                    boxShadow: `0 0 10px ${currentTheme.colors.primaryGlow}`,
                  }}
                  title="Open Dedicated Full-Screen Q/A Page with Split Layout"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>Open Dedicated Q/A Page ↗</span>
                </button>
              )}
            </div>
          </div>

          {/* 1. Primary Message Input & Action Bar */}
          <div className="flex gap-3 items-end">
            <textarea
              id="interview-answer-input"
              rows={qaBarHeight === 'massive' ? 9 : qaBarHeight === 'large' ? 5 : 3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading || session?.status === 'completed'}
              placeholder={
                session?.status === 'completed'
                  ? 'Interview completed. Click "Evaluation Report" above to review.'
                  : 'Type candidate technical response, dictate via microphone, or choose a simulation preset below...'
              }
              className="flex-1 border rounded-xl px-4 py-3 font-sans text-[0.98rem] md:text-[1.02rem] leading-relaxed outline-none resize-y transition-all shadow-inner"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.ink,
                minHeight: qaBarHeight === 'massive' ? '200px' : qaBarHeight === 'large' ? '120px' : '75px',
              }}
            />

            {/* Mic Dictation Button */}
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              disabled={isLoading || session?.status === 'completed'}
              className="p-3.5 rounded-xl border font-mono transition-all cursor-pointer disabled:opacity-30 flex items-center justify-center shrink-0"
              style={{
                backgroundColor: isListening ? `${currentTheme.colors.neonMagenta}33` : currentTheme.colors.bgSurface,
                borderColor: isListening ? currentTheme.colors.neonMagenta : currentTheme.colors.borderDark,
                color: isListening ? currentTheme.colors.neonMagenta : currentTheme.colors.inkMuted,
              }}
              title={isListening ? 'Stop speech dictation' : 'Start speech dictation (Microphone)'}
            >
              {isListening ? <MicOff className="w-4 h-4 animate-pulse" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Submit Button */}
            <button
              id="btn-send-answer"
              onClick={handleSend}
              disabled={!inputText.trim() || isLoading || session?.status === 'completed'}
              className="px-6 py-4 rounded-xl font-mono text-[0.76rem] font-black uppercase tracking-wider hover:brightness-110 transition-all disabled:opacity-20 cursor-pointer shrink-0 flex items-center gap-2"
              style={{
                background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonMagenta})`,
                color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
              }}
            >
              <span>SUBMIT RESPONSE</span>
              <Send className="w-4 h-4" />
            </button>
          </div>

          {/* 2. Simulation Presets Tray */}
          <div
            className="pt-3 border-t flex flex-col gap-2.5"
            style={{ borderColor: `${currentTheme.colors.borderDark}88` }}
          >
            {/* Category Filter Pills & Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className="font-mono text-xs uppercase tracking-wider font-black flex items-center gap-1.5"
                  style={{ color: currentTheme.colors.neonCyan }}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Simulation Presets:</span>
                </span>
                {(['all', 'senior', 'hands_on', 'flawed', 'clarify'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setActivePresetCategory(cat);
                      setShowPresets(true);
                    }}
                    className={`font-mono text-xs px-3 py-1 rounded-lg border transition-all cursor-pointer font-bold ${
                      activePresetCategory === cat ? 'shadow-sm scale-[1.02]' : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      backgroundColor: activePresetCategory === cat ? `${currentTheme.colors.neonCyan}25` : currentTheme.colors.bgSurface,
                      borderColor: activePresetCategory === cat ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                      color: activePresetCategory === cat ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                      boxShadow: activePresetCategory === cat ? `0 0 8px ${currentTheme.colors.primaryGlow}` : 'none',
                    }}
                  >
                    {cat.toUpperCase()}
                  </button>
                ))}

                {/* Compact / Collapse Presets Toggle */}
                <button
                  onClick={() => setShowPresets(!showPresets)}
                  className="font-mono text-xs px-2.5 py-1 rounded-lg border ml-1 opacity-80 hover:opacity-100 cursor-pointer font-semibold"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.inkMuted,
                  }}
                  title={showPresets ? 'Collapse simulation presets' : 'Expand simulation presets'}
                >
                  {showPresets ? 'Hide Presets ▲' : 'Show Presets ▼'}
                </button>
              </div>

              {/* 1-Click 8-Turn Full Simulation */}
              <button
                id="btn-auto-simulate-interview"
                onClick={handleAutoSimulate}
                disabled={isLoading || session?.status === 'completed'}
                className="font-mono text-xs font-black uppercase tracking-wider px-3.5 py-1.5 rounded-lg border transition-all cursor-pointer disabled:opacity-30 shadow-sm flex items-center gap-2 hover:brightness-110"
                style={{
                  backgroundColor: `${currentTheme.colors.neonPurple}25`,
                  borderColor: currentTheme.colors.neonPurple,
                  color: currentTheme.colors.neonPurple,
                }}
                title="Auto-run full 8 questions to immediately generate final synthesis & report"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>1-Click 8-Turn Simulation</span>
              </button>
            </div>

            {/* Quick Preset Buttons (Rendered below input when expanded) */}
            {showPresets && (
              <div className="flex flex-wrap items-center gap-1.5 max-h-20 overflow-y-auto pr-1">
                {filteredPresets.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => setInputText(preset.text)}
                    disabled={isLoading || session?.status === 'completed'}
                    className="font-mono text-[0.62rem] px-2 py-1 rounded-md border transition-all cursor-pointer disabled:opacity-30 shadow-xs text-left hover:brightness-110 flex items-center gap-1.5 max-w-[280px] truncate"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                      color: currentTheme.colors.inkMuted,
                    }}
                    title={preset.text}
                  >
                    <span className="font-bold shrink-0" style={{ color: currentTheme.colors.ink }}>
                      {preset.badge}
                    </span>
                    <span className="opacity-80 truncate">{preset.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Sidebar Diagnostics & Real-Time Performance Trajectory */}
      <div
        className={`flex-1 lg:flex-none lg:w-[360px] flex flex-col gap-4 sm:gap-5 overflow-y-auto select-none relative z-10 ${
          mobileView === 'chat' ? 'hidden lg:flex' : 'flex'
        }`}
      >
        {/* Candidate Profile Context Card */}
        <div
          className="rounded-xl p-5 backdrop-blur-xl shadow-md border transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <span
              className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Candidate Context
            </span>
            <span
              className="font-mono text-[0.6rem] px-2 py-0.5 rounded border font-bold"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}18`,
                color: currentTheme.colors.neonCyan,
                borderColor: `${currentTheme.colors.neonCyan}33`,
              }}
            >
              {candidate.member.id}
            </span>
          </div>

          <div className="flex items-center gap-3 mb-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-black text-sm border shadow-xs"
              style={{
                backgroundColor: `${currentTheme.colors.neonPurple}20`,
                borderColor: `${currentTheme.colors.neonPurple}40`,
                color: currentTheme.colors.neonPurple,
              }}
            >
              {candidate.member.name.split(' ').map((n) => n[0]).join('')}
            </div>
            <div>
              <h4 className="font-bold text-[0.95rem] leading-tight" style={{ color: currentTheme.colors.ink }}>
                {candidate.member.name}
              </h4>
              <p className="text-[0.75rem] leading-tight mt-0.5" style={{ color: currentTheme.colors.inkMuted }}>
                {candidate.member.jobRole} • {candidate.member.yearsExperience} yrs exp
              </p>
            </div>
          </div>

          <div
            className="grid grid-cols-3 gap-2 text-center text-[0.72rem] font-mono border-t pt-2.5"
            style={{ borderColor: currentTheme.colors.borderDark }}
          >
            <div>
              <span className="block text-[0.58rem]" style={{ color: currentTheme.colors.inkFaint }}>Completed</span>
              <span className="font-bold" style={{ color: currentTheme.colors.neonEmerald }}>
                {candidate.signals.missionsCompleted}
              </span>
            </div>
            <div>
              <span className="block text-[0.58rem]" style={{ color: currentTheme.colors.inkFaint }}>1st Try Pass</span>
              <span className="font-bold" style={{ color: currentTheme.colors.neonCyan }}>
                {candidate.signals.missionsFirstTry}
              </span>
            </div>
            <div>
              <span className="block text-[0.58rem]" style={{ color: currentTheme.colors.inkFaint }}>Commit Days</span>
              <span className="font-bold" style={{ color: currentTheme.colors.neonPurple }}>
                {candidate.signals.commitDays}
              </span>
            </div>
          </div>
        </div>

        {/* Curriculum Focus Section */}
        <div
          className="rounded-xl p-5 backdrop-blur-xl shadow-md border transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span
              className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
              style={{ color: currentTheme.colors.neonMagenta }}
            >
              Curriculum Grounding
            </span>
            <span
              className="font-mono text-[0.62rem] px-2 py-0.5 rounded border font-bold"
              style={{
                backgroundColor: `${currentTheme.colors.neonMagenta}18`,
                color: currentTheme.colors.neonMagenta,
                borderColor: `${currentTheme.colors.neonMagenta}33`,
              }}
            >
              Day {session?.currentDay || 7}
            </span>
          </div>
          <h3
            className="font-display text-[1.2rem] font-bold mb-2"
            style={{ color: currentTheme.colors.ink }}
          >
            {currentDayData?.title || 'Embeddings Explained'}
          </h3>
          <p
            className="text-[0.8rem] leading-relaxed mb-3"
            style={{ color: currentTheme.colors.inkMuted }}
          >
            Evaluating vector representations, semantic indexing, chunking trade-offs, and hybrid query architectures.
          </p>

          <div
            className="pt-3 border-t"
            style={{ borderColor: currentTheme.colors.borderDark }}
          >
            <span
              className="font-mono text-[0.6rem] uppercase tracking-[0.2em] font-bold block mb-2"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Core Day Objectives
            </span>
            <div className="space-y-2">
              {currentDayData?.objectives ? (
                currentDayData.objectives.slice(0, 3).map((obj, idx) => (
                  <div
                    key={idx}
                    className="flex gap-2.5 text-[0.76rem]"
                    style={{ color: currentTheme.colors.inkMuted }}
                  >
                    <span
                      className="font-mono text-[0.65rem] font-bold shrink-0 mt-0.5"
                      style={{ color: currentTheme.colors.neonCyan }}
                    >
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{obj}</span>
                  </div>
                ))
              ) : (
                <div className="text-[0.76rem]" style={{ color: currentTheme.colors.inkMuted }}>
                  Core technical objectives loaded from curriculum specification.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Live Question Milestone Step Progression Tracker */}
        <div
          className="rounded-xl p-5 backdrop-blur-xl shadow-md border transition-colors flex flex-col gap-3"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center justify-between">
            <span
              className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              8-Turn Milestone Tracker
            </span>
            <span
              className="font-mono text-[0.62rem] px-2 py-0.5 rounded border font-bold"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}18`,
                color: currentTheme.colors.neonCyan,
                borderColor: `${currentTheme.colors.neonCyan}33`,
              }}
            >
              Q{session?.questionCount || 1} of 8
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((qNum) => {
              const isPast = (session?.questionCount || 1) > qNum;
              const isCurrent = (session?.questionCount || 1) === qNum;
              const hasScore = session?.answerEvaluations && session.answerEvaluations[qNum - 1];

              return (
                <div
                  key={qNum}
                  className="p-2 rounded-lg border text-center transition-all flex flex-col items-center justify-center gap-0.5"
                  style={{
                    backgroundColor: isCurrent
                      ? `${currentTheme.colors.neonCyan}22`
                      : isPast
                      ? `${currentTheme.colors.neonEmerald}14`
                      : currentTheme.colors.bgSurface,
                    borderColor: isCurrent
                      ? currentTheme.colors.neonCyan
                      : isPast
                      ? currentTheme.colors.neonEmerald
                      : currentTheme.colors.borderDark,
                    color: isCurrent
                      ? currentTheme.colors.neonCyan
                      : isPast
                      ? currentTheme.colors.neonEmerald
                      : currentTheme.colors.inkFaint,
                  }}
                >
                  <span className="font-mono text-[0.6rem] font-black">Q{qNum}</span>
                  <span className="font-mono text-[0.55rem] font-bold">
                    {hasScore ? `${hasScore.score}/10` : isCurrent ? 'ACTIVE' : 'PENDING'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real-Time Evaluation & Trajectory Box */}
        {latestEval ? (
          <div
            className="rounded-xl p-5 backdrop-blur-xl shadow-md space-y-3.5 border transition-colors"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <div className="flex justify-between items-center">
              <span
                className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
                style={{ color: currentTheme.colors.neonEmerald }}
              >
                Latest Turn Evaluation
              </span>
              <span
                className="font-mono text-[0.85rem] font-black px-2.5 py-0.5 rounded border"
                style={{
                  backgroundColor: `${currentTheme.colors.neonEmerald}18`,
                  color: currentTheme.colors.neonEmerald,
                  borderColor: `${currentTheme.colors.neonEmerald}40`,
                }}
              >
                {latestEval.score} / 10
              </span>
            </div>

            {/* Performance Gauges */}
            <div
              className="grid grid-cols-2 gap-3 text-[0.75rem] font-mono border-y py-2.5"
              style={{ borderColor: currentTheme.colors.borderDark }}
            >
              <div>
                <span className="block text-[0.6rem]" style={{ color: currentTheme.colors.inkFaint }}>Correctness</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-bold" style={{ color: currentTheme.colors.ink }}>{Math.round(latestEval.correctness * 100)}%</span>
                  <div
                    className="flex-1 h-1.5 rounded-full overflow-hidden"
                    style={{ backgroundColor: currentTheme.colors.bgSurface }}
                  >
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${latestEval.correctness * 100}%`,
                        backgroundColor: currentTheme.colors.neonCyan,
                      }}
                    />
                  </div>
                </div>
              </div>
              <div>
                <span className="block text-[0.6rem]" style={{ color: currentTheme.colors.inkFaint }}>Depth</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-bold" style={{ color: currentTheme.colors.ink }}>{Math.round(latestEval.depth * 100)}%</span>
                  <div
                    className="flex-1 h-1.5 rounded-full overflow-hidden"
                    style={{ backgroundColor: currentTheme.colors.bgSurface }}
                  >
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${latestEval.depth * 100}%`,
                        backgroundColor: currentTheme.colors.neonPurple,
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Missing Concepts Badges */}
            {latestEval.missingConcepts && latestEval.missingConcepts.length > 0 && (
              <div>
                <span className="block font-mono text-[0.58rem] uppercase font-bold mb-1" style={{ color: currentTheme.colors.neonMagenta }}>
                  Targeted Concepts for Next Probe:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {latestEval.missingConcepts.map((c, i) => (
                    <span
                      key={i}
                      className="font-mono text-[0.62rem] px-2 py-0.5 rounded border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonMagenta}14`,
                        borderColor: `${currentTheme.colors.neonMagenta}33`,
                        color: currentTheme.colors.neonMagenta,
                      }}
                    >
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <p
              className="text-[0.8rem] font-sans italic leading-relaxed"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              "{latestEval.critique}"
            </p>
          </div>
        ) : (
          <div
            className="rounded-xl p-5 backdrop-blur-xl shadow-md border transition-colors flex flex-col gap-2.5"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <div className="flex items-center justify-between">
              <span
                className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
                style={{ color: currentTheme.colors.neonAmber }}
              >
                Grounded Rubric Guidance
              </span>
              <Sparkles className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonAmber }} />
            </div>
            <p className="text-[0.78rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
              NOVA MIND dynamically grades each technical turn for <span className="font-bold text-[var(--ink)]">mathematical correctness</span>, <span className="font-bold text-[var(--ink)]">concrete API depth</span>, and <span className="font-bold text-[var(--ink)]">real-world architectural trade-offs</span>.
            </p>
            <div
              className="p-2.5 rounded-lg border text-[0.72rem] font-mono"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.neonCyan,
              }}
            >
              Pro-Tip: Try mentioning HNSW indexing, chunk overlap, or FastAPI hybrid query routers to see deep reasoning score increase!
            </div>
          </div>
        )}
      </div>
    </div>
    </div>
  );
};
