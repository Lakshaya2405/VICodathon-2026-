import React, { useState } from 'react';
import {
  Download,
  Copy,
  Check,
  X,
  RefreshCw,
  Sparkles,
  Award,
  TrendingUp,
} from 'lucide-react';
import { FinalFeedback, CandidateProfile } from '../server/types';
import { useTheme } from '../theme/ThemeContext';

interface FeedbackModalProps {
  feedback: FinalFeedback;
  candidate: CandidateProfile;
  onClose: () => void;
  onResetSession: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  feedback,
  candidate,
  onClose,
  onResetSession,
}) => {
  const { currentTheme } = useTheme();
  const [copied, setCopied] = useState(false);

  const scores = feedback.detailedScores || {
    overallScore: 82,
    technicalScore: 84,
    conceptualDepthScore: 80,
    problemSolvingScore: 82,
    practicalUnderstandingScore: 80,
    communicationScore: 85,
    engineeringJudgmentScore: 80,
  };

  const handleCopy = () => {
    const text = JSON.stringify(feedback, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(feedback, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute(
      'download',
      `interview-feedback-${candidate.member.id}-${Date.now()}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div
      id="feedback-modal-overlay"
      className="fixed inset-0 z-50 bg-[#000000]/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto select-none"
    >
      <div
        id="feedback-modal-card"
        className="w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden rounded-2xl shadow-2xl relative border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
          boxShadow: `0 0 50px ${currentTheme.colors.primaryGlow}`,
        }}
      >
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        {/* Header */}
        <div
          className="p-6 flex items-start justify-between border-b shrink-0 relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
            color: currentTheme.colors.ink,
          }}
        >
          <div>
            <span
              className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Final Synthesis & Decision Report
            </span>
            <div className="flex items-center gap-3">
              <h3
                className="font-display text-[1.65rem] font-bold tracking-tight"
                style={{ color: currentTheme.colors.ink }}
              >
                Interview Evaluation Report
              </h3>
              <span
                className="font-mono text-[0.65rem] uppercase tracking-wider px-2 py-0.5 rounded font-bold border shadow-sm"
                style={{
                  backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                  borderColor: `${currentTheme.colors.neonEmerald}40`,
                  color: currentTheme.colors.neonEmerald,
                }}
              >
                Completed
              </span>
            </div>
            <p
              className="font-mono text-[0.7rem] mt-1"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              Candidate:{' '}
              <span className="font-semibold" style={{ color: currentTheme.colors.ink }}>
                {candidate.member.name}
              </span>{' '}
              • {candidate.member.jobRole} ({candidate.member.id})
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border transition-colors cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.inkMuted,
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 relative z-10">
          {/* Executive Summary */}
          <div
            className="border rounded-xl p-5 shadow-md"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <span
                className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold"
                style={{ color: currentTheme.colors.neonPurple }}
              >
                Executive Assessment Summary
              </span>
              <div className="flex items-baseline gap-2 font-mono text-[0.75rem]">
                <span style={{ color: currentTheme.colors.inkMuted }}>Overall Score:</span>
                <span
                  className="font-bold px-2.5 py-0.5 rounded shadow-sm"
                  style={{
                    background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`,
                    color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                  }}
                >
                  {scores.overallScore} / 100
                </span>
              </div>
            </div>
            <p
              className="font-serif text-[1.08rem] leading-relaxed font-normal italic"
              style={{ color: currentTheme.colors.ink }}
            >
              "{feedback.summary}"
            </p>
          </div>

          {/* Scoring Grid */}
          <div>
            <span
              className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold block mb-3"
              style={{ color: currentTheme.colors.neonEmerald }}
            >
              Competency Breakdown & Evaluation Scores
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { label: 'Technical Knowledge', val: scores.technicalScore, weight: '30%', color: currentTheme.colors.neonCyan },
                { label: 'Conceptual Depth', val: scores.conceptualDepthScore, weight: '20%', color: currentTheme.colors.neonPurple },
                { label: 'Problem Solving', val: scores.problemSolvingScore, weight: '20%', color: currentTheme.colors.neonMagenta },
                {
                  label: 'Practical Understanding',
                  val: scores.practicalUnderstandingScore,
                  weight: '15%',
                  color: currentTheme.colors.neonEmerald,
                },
                { label: 'Communication', val: scores.communicationScore, weight: '10%', color: currentTheme.colors.neonCyan },
                {
                  label: 'Engineering Judgment',
                  val: scores.engineeringJudgmentScore,
                  weight: '5%',
                  color: currentTheme.colors.neonAmber,
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="border rounded-xl p-3.5 flex flex-col justify-between shadow-xs"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="font-mono text-[0.68rem] font-medium"
                      style={{ color: currentTheme.colors.ink }}
                    >
                      {item.label}
                    </span>
                    <span
                      className="font-mono text-[0.6rem]"
                      style={{ color: currentTheme.colors.inkFaint }}
                    >
                      wt: {item.weight}
                    </span>
                  </div>
                  <div className="flex items-baseline justify-between mt-2 font-mono">
                    <span
                      className="font-bold text-base"
                      style={{ color: currentTheme.colors.ink }}
                    >
                      {item.val}%
                    </span>
                    <span
                      className="text-[0.62rem] uppercase font-bold px-1.5 py-0.5 rounded border"
                      style={{
                        backgroundColor: `${item.color}20`,
                        color: item.color,
                        borderColor: `${item.color}40`,
                      }}
                    >
                      {item.val >= 80 ? 'Exceeds' : item.val >= 60 ? 'Meets' : 'Needs Review'}
                    </span>
                  </div>
                  <div
                    className="w-full rounded-full h-1.5 overflow-hidden mt-2 border"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${item.val}%`,
                        backgroundColor: item.color,
                        boxShadow: `0 0 8px ${item.color}`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Strengths & Gaps Two-Column */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Strengths */}
            <div
              className="border rounded-xl p-5 shadow-sm"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <span
                className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold block mb-3"
                style={{ color: currentTheme.colors.neonEmerald }}
              >
                Demonstrated Strengths
              </span>
              <ul className="space-y-2.5">
                {feedback.strengths.map((str, idx) => (
                  <li
                    key={idx}
                    className="font-serif text-[0.95rem] leading-relaxed flex items-start gap-2.5"
                    style={{ color: currentTheme.colors.ink }}
                  >
                    <span
                      className="font-mono text-[0.65rem] px-1.5 py-0.5 rounded shrink-0 mt-0.5 font-bold border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonEmerald}15`,
                        borderColor: `${currentTheme.colors.neonEmerald}33`,
                        color: currentTheme.colors.neonEmerald,
                      }}
                    >
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{str}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Knowledge Gaps */}
            <div
              className="border rounded-xl p-5 shadow-sm"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <span
                className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold block mb-3"
                style={{ color: currentTheme.colors.neonMagenta }}
              >
                Identified Knowledge Gaps
              </span>
              <ul className="space-y-2.5">
                {feedback.gaps.map((gap, idx) => (
                  <li
                    key={idx}
                    className="font-serif text-[0.95rem] leading-relaxed flex items-start gap-2.5"
                    style={{ color: currentTheme.colors.ink }}
                  >
                    <span
                      className="font-mono text-[0.65rem] px-1.5 py-0.5 rounded shrink-0 mt-0.5 font-bold border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonMagenta}15`,
                        borderColor: `${currentTheme.colors.neonMagenta}33`,
                        color: currentTheme.colors.neonMagenta,
                      }}
                    >
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span>{gap}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Actionable Next Steps */}
          <div
            className="border rounded-xl p-5 shadow-sm"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <span
              className="font-mono text-[0.65rem] uppercase tracking-[0.2em] font-bold block mb-3"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Actionable Next Steps & Study Recommendations
            </span>
            <div className="space-y-2.5">
              {feedback.next.map((step, idx) => (
                <div
                  key={idx}
                  className="rounded-lg p-3 text-[0.92rem] font-serif leading-relaxed flex items-start gap-3 border"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.ink,
                  }}
                >
                  <span
                    className="font-mono text-[0.65rem] px-2 py-0.5 rounded font-bold shrink-0 border"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonCyan}20`,
                      borderColor: `${currentTheme.colors.neonCyan}40`,
                      color: currentTheme.colors.neonCyan,
                    }}
                  >
                    Step {idx + 1}
                  </span>
                  <span className="flex-1">{step}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          className="border-t p-4 flex items-center justify-between shrink-0 relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-2 font-mono text-[0.7rem]">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors cursor-pointer uppercase tracking-wider shadow-xs"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.ink,
              }}
            >
              {copied ? <Check className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonEmerald }} /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-colors cursor-pointer uppercase tracking-wider shadow-xs"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.ink,
              }}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Report</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onResetSession();
                onClose();
              }}
              className="font-mono text-[0.7rem] uppercase tracking-wider font-black flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all cursor-pointer shadow-md hover:brightness-110"
              style={{
                background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`,
                color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
              }}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Next Candidate</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
