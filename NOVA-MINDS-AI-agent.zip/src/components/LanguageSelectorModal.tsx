import React, { useState } from 'react';
import {
  Globe,
  Volume2,
  Check,
  X,
  Sparkles,
  Play,
  Languages,
  Mic,
  MessageSquare,
} from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../data/languages';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onTestVoice: (lang: SupportedLanguage) => void;
}

export const LanguageSelectorModal: React.FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  onSelectLanguage,
  onTestVoice,
}) => {
  const { currentTheme } = useTheme();
  const [testingLangId, setTestingLangId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleTestAudio = (lang: SupportedLanguage) => {
    setTestingLangId(lang.id);
    onTestVoice(lang);
    setTimeout(() => {
      setTestingLangId(null);
    }, 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-3xl max-h-[90vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden relative"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
          color: currentTheme.colors.ink,
        }}
      >
        {/* Modal Header */}
        <div
          className="p-5 md:p-6 border-b flex justify-between items-center"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md shrink-0"
              style={{
                backgroundColor: `${currentTheme.colors.neonPurple}20`,
                borderColor: currentTheme.colors.neonPurple,
                borderWidth: '1px',
                color: currentTheme.colors.neonPurple,
              }}
            >
              <Languages className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display text-lg md:text-xl font-bold tracking-tight flex items-center gap-2">
                <span>Select Preferred Language & Voice Engine</span>
              </h3>
              <p className="text-xs font-sans mt-0.5" style={{ color: currentTheme.colors.inkMuted }}>
                The agent will ask questions, provide voice readouts, and understand technical voice commands in your selected language.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg border hover:brightness-125 transition-all cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.inkMuted,
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Language Banner */}
        <div
          className="px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 font-mono text-xs"
          style={{
            backgroundColor: `${currentTheme.colors.neonCyan}14`,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">{currentLanguage.flag}</span>
            <span className="font-bold" style={{ color: currentTheme.colors.neonCyan }}>
              Active Language: {currentLanguage.nativeName} ({currentLanguage.name})
            </span>
            <span className="opacity-50">•</span>
            <span style={{ color: currentTheme.colors.inkMuted }}>
              Speech Code: <span className="font-bold">{currentLanguage.speechCode}</span>
            </span>
          </div>

          <button
            onClick={() => handleTestAudio(currentLanguage)}
            className="px-3 py-1 rounded-md border flex items-center gap-1.5 font-bold transition-all cursor-pointer hover:brightness-110"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.neonCyan,
              color: currentTheme.colors.neonCyan,
            }}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>{testingLangId === currentLanguage.id ? 'Speaking Sample...' : 'Test Speech Synthesis'}</span>
          </button>
        </div>

        {/* Language Cards Grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {SUPPORTED_LANGUAGES.map((lang) => {
            const isSelected = currentLanguage.id === lang.id;
            const isTesting = testingLangId === lang.id;

            return (
              <div
                key={lang.id}
                onClick={() => onSelectLanguage(lang)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-3 relative group ${
                  isSelected ? 'scale-[1.01] shadow-lg' : 'hover:border-cyan-500/50'
                }`}
                style={{
                  backgroundColor: isSelected ? `${currentTheme.colors.neonCyan}18` : currentTheme.colors.bgCard,
                  borderColor: isSelected ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                }}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{lang.flag}</span>
                      <div>
                        <h4 className="font-display font-bold text-sm" style={{ color: currentTheme.colors.ink }}>
                          {lang.nativeName}
                        </h4>
                        <span className="font-mono text-[0.65rem]" style={{ color: currentTheme.colors.inkMuted }}>
                          {lang.name} • {lang.speechCode}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {isSelected ? (
                        <span
                          className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-black shadow-sm"
                          style={{
                            backgroundColor: currentTheme.colors.neonCyan,
                            color: currentTheme.mode === 'light' ? '#fff' : '#000',
                          }}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </span>
                      ) : (
                        <span
                          className="font-mono text-[0.6rem] px-2 py-0.5 rounded border opacity-60 group-hover:opacity-100"
                          style={{
                            backgroundColor: currentTheme.colors.bgSurface,
                            borderColor: currentTheme.colors.borderDark,
                            color: currentTheme.colors.inkMuted,
                          }}
                        >
                          Select
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs font-sans mt-2.5 italic leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                    "{lang.sampleGreeting}"
                  </p>
                </div>

                <div
                  className="pt-2 border-t flex items-center justify-between text-[0.68rem] font-mono"
                  style={{ borderColor: `${currentTheme.colors.borderDark}66` }}
                >
                  <span style={{ color: currentTheme.colors.neonPurple }} className="truncate max-w-[170px]">
                    Term: {lang.sampleTechnicalTerm}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleTestAudio(lang);
                    }}
                    className="px-2 py-1 rounded border flex items-center gap-1 font-bold transition-all hover:brightness-110"
                    style={{
                      backgroundColor: currentTheme.colors.bgSurface,
                      borderColor: currentTheme.colors.borderDark,
                      color: currentTheme.colors.neonEmerald,
                    }}
                    title={`Hear voice synthesis in ${lang.nativeName}`}
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>{isTesting ? 'Playing...' : 'Voice Sample'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div
          className="p-4 border-t flex justify-between items-center gap-3 select-none"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-2 text-xs font-sans" style={{ color: currentTheme.colors.inkMuted }}>
            <Sparkles className="w-4 h-4" style={{ color: currentTheme.colors.neonPurple }} />
            <span>You can also switch language at any time by saying: <span className="font-mono font-bold" style={{ color: currentTheme.colors.neonCyan }}>"Switch language to Spanish"</span></span>
          </div>

          <button
            onClick={onClose}
            className="font-mono text-xs font-bold uppercase tracking-wider px-4 py-2 rounded-lg cursor-pointer transition-all hover:brightness-110"
            style={{
              backgroundColor: currentTheme.colors.neonPurple,
              color: '#ffffff',
            }}
          >
            Apply & Continue
          </button>
        </div>
      </div>
    </div>
  );
};
