import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Copy,
  Check,
  Search,
  Users,
  MessageSquare,
  Sparkles,
  Terminal,
  Activity,
  Layers,
  Code,
  X,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { InterviewSessionState } from '../server/types';
import { ChatExporterService } from '../server/chatExporter';
import { useTheme } from '../theme/ThemeContext';

interface AllChatsArchiveModalProps {
  onClose: () => void;
  currentSession: InterviewSessionState | null;
  onSelectCandidateSession?: (candidateId: string) => void;
}

export const AllChatsArchiveModal: React.FC<AllChatsArchiveModalProps> = ({
  onClose,
  currentSession,
}) => {
  const { currentTheme } = useTheme();
  const [sessions, setSessions] = useState<InterviewSessionState[]>([]);
  const [activeFormat, setActiveFormat] = useState<'markdown' | 'dialogue' | 'json' | 'txt'>('markdown');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [selectedSessionFilter, setSelectedSessionFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);

  // Fetch all sessions from server
  const loadSessions = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/sessions');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setSessions(data);
        } else if (currentSession) {
          setSessions([currentSession]);
        }
      } else if (currentSession) {
        setSessions([currentSession]);
      }
    } catch (e) {
      if (currentSession) {
        setSessions([currentSession]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSessions();
  }, [currentSession]);

  const displayedSessions =
    selectedSessionFilter === 'all'
      ? sessions
      : sessions.filter((s) => s.sessionId === selectedSessionFilter || s.candidate.member.id === selectedSessionFilter);

  const totalTurns = sessions.reduce((sum, s) => sum + s.conversationHistory.length, 0);
  const totalEvaluations = sessions.reduce((sum, s) => sum + s.answerEvaluations.length, 0);

  // Generate single file content based on format
  const markdownContent = ChatExporterService.generateMarkdown(displayedSessions);
  const jsonContent = ChatExporterService.generateJson(displayedSessions);
  const txtContent = ChatExporterService.generatePlainText(displayedSessions);

  const activeContent =
    activeFormat === 'markdown'
      ? markdownContent
      : activeFormat === 'json'
      ? jsonContent
      : txtContent;

  const handleCopy = () => {
    navigator.clipboard.writeText(activeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleDownload = (formatToDownload?: 'markdown' | 'json' | 'txt') => {
    const fmt = formatToDownload || (activeFormat === 'dialogue' ? 'markdown' : activeFormat);
    const content =
      fmt === 'markdown' ? markdownContent : fmt === 'json' ? jsonContent : txtContent;
    const extension = fmt === 'markdown' ? 'md' : fmt === 'json' ? 'json' : 'txt';
    const mimeType =
      fmt === 'json' ? 'application/json' : fmt === 'markdown' ? 'text/markdown' : 'text/plain';

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `all-interview-chats-${new Date().toISOString().slice(0, 10)}.${extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      id="all-chats-archive-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-6 backdrop-blur-xl animate-in fade-in duration-200"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.75)' }}
    >
      <div
        className="w-full max-w-5xl h-[90vh] rounded-2xl flex flex-col overflow-hidden shadow-2xl border transition-colors relative z-10"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
          color: currentTheme.colors.ink,
        }}
      >
        {/* Virtual Ambient Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[14vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        {/* Modal Header */}
        <div
          className="px-6 py-4 border-b flex flex-wrap items-center justify-between gap-4 backdrop-blur-xl relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center border shadow-xs"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}20`,
                borderColor: `${currentTheme.colors.neonCyan}50`,
                color: currentTheme.colors.neonCyan,
              }}
            >
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span
                  className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold"
                  style={{ color: currentTheme.colors.neonCyan }}
                >
                  Unified Single-File Archive Engine
                </span>
                <span
                  className="font-mono text-[0.62rem] px-2 py-0.5 rounded border font-bold"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonEmerald}18`,
                    color: currentTheme.colors.neonEmerald,
                    borderColor: `${currentTheme.colors.neonEmerald}40`,
                  }}
                >
                  {totalTurns} Total Turns
                </span>
              </div>
              <h3 className="font-display text-[1.3rem] font-bold leading-tight" style={{ color: currentTheme.colors.ink }}>
                All Chats & Telemetry in a Single File
              </h3>
            </div>
          </div>

          {/* Quick Metrics & Close */}
          <div className="flex items-center gap-2">
            <button
              onClick={loadSessions}
              disabled={isLoading}
              className="p-2 rounded-lg border font-mono text-[0.72rem] transition-all cursor-pointer shadow-xs"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.inkMuted,
              }}
              title="Refresh Chat Logs from Server"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg border transition-all cursor-pointer shadow-xs hover:brightness-125"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.inkMuted,
              }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Toolbar & Filter Bar */}
        <div
          className="px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-[0.78rem] font-mono relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCardHover,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          {/* Format Tabs */}
          <div className="flex items-center gap-1.5">
            <span className="font-bold mr-1 text-[0.65rem] uppercase" style={{ color: currentTheme.colors.inkFaint }}>
              Format:
            </span>
            {(
              [
                { id: 'markdown', label: 'Markdown (.md)', icon: FileText },
                { id: 'dialogue', label: 'Visual Dialogue', icon: MessageSquare },
                { id: 'json', label: 'Raw JSON (.json)', icon: Code },
                { id: 'txt', label: 'Plain Text (.txt)', icon: Terminal },
              ] as const
            ).map((fmt) => {
              const Icon = fmt.icon;
              const isActive = activeFormat === fmt.id;
              return (
                <button
                  key={fmt.id}
                  onClick={() => setActiveFormat(fmt.id)}
                  className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                    isActive ? 'shadow-sm' : 'opacity-70 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: isActive
                      ? `${currentTheme.colors.neonCyan}25`
                      : currentTheme.colors.bgSurface,
                    borderColor: isActive
                      ? currentTheme.colors.neonCyan
                      : currentTheme.colors.borderDark,
                    color: isActive ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                  }}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{fmt.label}</span>
                </button>
              );
            })}
          </div>

          {/* Session / Candidate Filter Selector */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonPurple }} />
              <select
                value={selectedSessionFilter}
                onChange={(e) => setSelectedSessionFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border font-mono text-[0.72rem] font-bold outline-none cursor-pointer"
                style={{
                  backgroundColor: currentTheme.colors.bgSurface,
                  borderColor: currentTheme.colors.borderDark,
                  color: currentTheme.colors.ink,
                }}
              >
                <option value="all">All Sessions ({sessions.length} Cohort Candidates)</option>
                {sessions.map((s) => (
                  <option key={s.sessionId} value={s.sessionId}>
                    {s.candidate.member.name} ({s.candidate.member.jobRole}) — {s.conversationHistory.length} turns
                  </option>
                ))}
              </select>
            </div>

            {/* Copy Button */}
            <button
              id="btn-copy-all-chats"
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-lg border flex items-center gap-1.5 font-bold transition-all cursor-pointer shadow-xs"
              style={{
                backgroundColor: copied
                  ? `${currentTheme.colors.neonEmerald}25`
                  : currentTheme.colors.bgSurface,
                borderColor: copied
                  ? currentTheme.colors.neonEmerald
                  : currentTheme.colors.borderDark,
                color: copied ? currentTheme.colors.neonEmerald : currentTheme.colors.ink,
              }}
              title="Copy the entire single file transcript to clipboard"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Transcript'}</span>
            </button>

            {/* Download Button */}
            <button
              id="btn-download-all-chats"
              onClick={() => handleDownload()}
              className="px-4 py-1.5 rounded-lg font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-md hover:brightness-110"
              style={{
                background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonMagenta})`,
                color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                boxShadow: `0 0 12px ${currentTheme.colors.primaryGlow}`,
              }}
              title="Download entire transcript as a single file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>

        {/* Content Viewer Workspace */}
        <div className="flex-1 overflow-y-auto p-6 relative z-10">
          {activeFormat === 'dialogue' ? (
            /* Visual Dialogue Stream */
            <div className="space-y-6 max-w-4xl mx-auto">
              {displayedSessions.map((sess, sIdx) => (
                <div
                  key={sess.sessionId}
                  className="p-5 rounded-xl border shadow-sm space-y-4"
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    borderColor: currentTheme.colors.borderDark,
                  }}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-3 font-mono text-[0.72rem]" style={{ borderColor: currentTheme.colors.borderDark }}>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: currentTheme.colors.neonCyan }} />
                      <span className="font-bold" style={{ color: currentTheme.colors.ink }}>
                        Candidate: {sess.candidate.member.name} ({sess.candidate.member.jobRole})
                      </span>
                      <span className="px-2 py-0.5 rounded border" style={{ backgroundColor: `${currentTheme.colors.neonPurple}18`, borderColor: `${currentTheme.colors.neonPurple}33`, color: currentTheme.colors.neonPurple }}>
                        {sess.candidate.member.id}
                      </span>
                    </div>
                    <span style={{ color: currentTheme.colors.inkMuted }}>
                      {sess.conversationHistory.length} turns • {sess.curriculumDaysCovered.length} days covered
                    </span>
                  </div>

                  {sess.conversationHistory.length === 0 ? (
                    <div className="py-6 text-center italic text-[0.85rem]" style={{ color: currentTheme.colors.inkFaint }}>
                      No turns recorded in this session yet.
                    </div>
                  ) : (
                    sess.conversationHistory.map((turn, tIdx) => {
                      const isInterviewer = turn.role === 'interviewer';
                      return (
                        <div
                          key={tIdx}
                          className="p-4 rounded-xl border"
                          style={{
                            backgroundColor: isInterviewer
                              ? currentTheme.colors.bgSurface
                              : `${currentTheme.colors.bgCardHover}bb`,
                            borderColor: isInterviewer
                              ? `${currentTheme.colors.neonCyan}44`
                              : currentTheme.colors.borderDark,
                          }}
                        >
                          <div className="flex items-center justify-between mb-2 font-mono text-[0.65rem] uppercase">
                            <span
                              className="font-bold px-2 py-0.5 rounded border"
                              style={{
                                backgroundColor: isInterviewer
                                  ? `${currentTheme.colors.neonCyan}18`
                                  : `${currentTheme.colors.neonMagenta}18`,
                                color: isInterviewer
                                  ? currentTheme.colors.neonCyan
                                  : currentTheme.colors.neonMagenta,
                                borderColor: isInterviewer
                                  ? `${currentTheme.colors.neonCyan}33`
                                  : `${currentTheme.colors.neonMagenta}33`,
                              }}
                            >
                              Turn {tIdx + 1}: {isInterviewer ? 'Interviewer (NOVA MIND)' : `Candidate (${sess.candidate.member.name})`}
                            </span>
                            <span style={{ color: currentTheme.colors.inkFaint }}>
                              {new Date(turn.timestamp).toLocaleTimeString()}
                            </span>
                          </div>

                          <div
                            className={isInterviewer ? 'font-serif text-[1rem] leading-relaxed' : 'font-sans text-[0.9rem] leading-relaxed'}
                            style={{ color: isInterviewer ? currentTheme.colors.ink : currentTheme.colors.inkMuted }}
                          >
                            {turn.content}
                          </div>

                          {turn.evaluation && (
                            <div
                              className="mt-3 pt-2.5 border-t flex flex-wrap items-center justify-between gap-2 font-mono text-[0.7rem]"
                              style={{ borderColor: currentTheme.colors.borderDark }}
                            >
                              <div className="flex items-center gap-3">
                                <span className="font-bold" style={{ color: currentTheme.colors.neonEmerald }}>
                                  Score: {turn.evaluation.score}/10
                                </span>
                                <span>Correctness: {Math.round(turn.evaluation.correctness * 100)}%</span>
                                <span>Depth: {Math.round(turn.evaluation.depth * 100)}%</span>
                              </div>
                              <span className="italic" style={{ color: currentTheme.colors.inkMuted }}>
                                "{turn.evaluation.critique}"
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              ))}
            </div>
          ) : (
            /* Monospace Single-File Raw Editor View (Markdown / JSON / Plain Text) */
            <div className="h-full flex flex-col">
              <pre
                className="flex-1 p-5 rounded-xl font-mono text-[0.78rem] leading-relaxed overflow-auto border shadow-inner selection:bg-cyan-500 selection:text-white"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                  color: currentTheme.colors.ink,
                }}
              >
                <code>{activeContent}</code>
              </pre>
            </div>
          )}
        </div>

        {/* Modal Bottom Status Bar */}
        <div
          className="px-6 py-3 border-t flex flex-wrap items-center justify-between gap-3 font-mono text-[0.7rem] relative z-10"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
            color: currentTheme.colors.inkMuted,
          }}
        >
          <div className="flex items-center gap-3">
            <span>
              Sessions captured: <strong style={{ color: currentTheme.colors.neonCyan }}>{displayedSessions.length}</strong>
            </span>
            <span>•</span>
            <span>
              Total conversation turns: <strong style={{ color: currentTheme.colors.neonPurple }}>{totalTurns}</strong>
            </span>
            <span>•</span>
            <span>
              Evaluations: <strong style={{ color: currentTheme.colors.neonEmerald }}>{totalEvaluations}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => handleDownload('markdown')}
              className="hover:underline cursor-pointer flex items-center gap-1 font-bold"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              <Download className="w-3 h-3" />
              <span>.MD</span>
            </button>
            <button
              onClick={() => handleDownload('json')}
              className="hover:underline cursor-pointer flex items-center gap-1 font-bold"
              style={{ color: currentTheme.colors.neonPurple }}
            >
              <Download className="w-3 h-3" />
              <span>.JSON</span>
            </button>
            <button
              onClick={() => handleDownload('txt')}
              className="hover:underline cursor-pointer flex items-center gap-1 font-bold"
              style={{ color: currentTheme.colors.neonEmerald }}
            >
              <Download className="w-3 h-3" />
              <span>.TXT</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
