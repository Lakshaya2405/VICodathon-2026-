import React, { useState } from 'react';
import {
  Mic,
  Volume2,
  Sparkles,
  X,
  Play,
  Check,
  Zap,
  Globe,
  Radio,
  HelpCircle,
  Code,
  FileCode,
  FileText,
  User,
  Layers,
} from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../data/languages';

interface VoiceCommandModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onExecuteCommand: (commandName: string) => void;
  isHandsFreeMode: boolean;
  setIsHandsFreeMode: (active: boolean) => void;
  isAudioEnabled: boolean;
  setIsAudioEnabled: (enabled: boolean) => void;
}

export const VoiceCommandModal: React.FC<VoiceCommandModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  onSelectLanguage,
  onExecuteCommand,
  isHandsFreeMode,
  setIsHandsFreeMode,
  isAudioEnabled,
  setIsAudioEnabled,
}) => {
  const { currentTheme } = useTheme();
  const [activeCategory, setActiveCategory] = useState<'all' | 'interview' | 'navigation' | 'audio' | 'languages'>('all');
  const [testResult, setTestResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const commandCategories = [
    {
      id: 'interview',
      title: 'Interview & Answers',
      icon: <Radio className="w-4 h-4" />,
      items: [
        {
          command: currentLanguage.commands.submit[0] || 'submit answer',
          aliases: currentLanguage.commands.submit.slice(1),
          description: 'Submits the current spoken or typed technical answer to the AI evaluator.',
          action: 'submit',
        },
        {
          command: currentLanguage.commands.nextQuestion[0] || 'next question',
          aliases: currentLanguage.commands.nextQuestion.slice(1),
          description: 'Advances to the next curriculum milestone question or skips current turn.',
          action: 'next',
        },
        {
          command: currentLanguage.commands.repeatQuestion[0] || 'repeat question',
          aliases: currentLanguage.commands.repeatQuestion.slice(1),
          description: 'Reads the active technical question aloud again using voice synthesis in your language.',
          action: 'repeat',
        },
        {
          command: currentLanguage.commands.explainConcept[0] || 'explain concept',
          aliases: currentLanguage.commands.explainConcept.slice(1),
          description: 'Asks the agent to provide a conceptual clarification or rubric hint.',
          action: 'explain',
        },
        {
          command: currentLanguage.commands.clearInput[0] || 'clear input',
          aliases: currentLanguage.commands.clearInput.slice(1),
          description: 'Clears the current text input draft or spoken transcript.',
          action: 'clear',
        },
      ],
    },
    {
      id: 'navigation',
      title: 'Navigation & Roster',
      icon: <Layers className="w-4 h-4" />,
      items: [
        {
          command: 'switch candidate to [Name]',
          aliases: ['next candidate', 'cambiar candidato', 'changer candidat'],
          description: 'Switches the active candidate in the cohort roster (e.g. "Switch candidate to Elena").',
          action: 'switch_candidate',
        },
        {
          command: currentLanguage.commands.viewFeedback[0] || 'view feedback',
          aliases: currentLanguage.commands.viewFeedback.slice(1),
          description: 'Opens the comprehensive multi-dimensional evaluation report and scores.',
          action: 'feedback',
        },
        {
          command: currentLanguage.commands.catchAllChats[0] || 'catch all chats',
          aliases: currentLanguage.commands.catchAllChats.slice(1),
          description: 'Exports and catches all chats and transcripts into a unified single file (MD, JSON, TXT).',
          action: 'catch_all',
        },
        {
          command: currentLanguage.commands.openScratchpad[0] || 'open scratchpad',
          aliases: currentLanguage.commands.openScratchpad.slice(1),
          description: 'Toggles the technical code and system architecture scratchpad overlay.',
          action: 'scratchpad',
        },
        {
          command: currentLanguage.commands.switchTheme[0] || 'switch theme',
          aliases: currentLanguage.commands.switchTheme.slice(1),
          description: 'Cycles to the next visual theme preset (Cyberpunk, Matrix, Dark Obsidian, etc.).',
          action: 'theme',
        },
      ],
    },
    {
      id: 'audio',
      title: 'Voice & Hands-Free Mode',
      icon: <Mic className="w-4 h-4" />,
      items: [
        {
          command: currentLanguage.commands.toggleVoice[0] || 'toggle voice',
          aliases: currentLanguage.commands.toggleVoice.slice(1),
          description: 'Turns audio question read-aloud voice on or off.',
          action: 'toggle_voice',
        },
        {
          command: 'hands-free voice mode',
          aliases: ['enable hands free', 'continuous interview', 'modo manos libres'],
          description: 'Enables continuous voice agent mode: agent speaks, mic auto-listens, and advances naturally.',
          action: 'hands_free',
        },
        {
          command: currentLanguage.commands.autoSimulate[0] || 'auto simulate',
          aliases: currentLanguage.commands.autoSimulate.slice(1),
          description: 'Runs an automated 8-turn technical interview simulation with real-world answers.',
          action: 'simulate',
        },
      ],
    },
    {
      id: 'languages',
      title: 'Multilingual Switching',
      icon: <Globe className="w-4 h-4" />,
      items: SUPPORTED_LANGUAGES.map((lang) => ({
        command: `switch language to ${lang.name}`,
        aliases: [`hablar ${lang.nativeName}`, `parler ${lang.name}`, `sprache ${lang.name}`],
        description: `Changes AI interviewer language, TTS voice, and speech recognition to ${lang.flag} ${lang.nativeName}.`,
        action: `lang_${lang.id}`,
      })),
    },
  ];

  const filteredCategories =
    activeCategory === 'all'
      ? commandCategories
      : commandCategories.filter((c) => c.id === activeCategory);

  const handleTestClick = (actionName: string, label: string) => {
    setTestResult(`⚡ Executed Voice Command: "${label}"`);
    onExecuteCommand(actionName);
    setTimeout(() => {
      setTestResult(null);
    }, 2800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-4xl max-h-[90vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden relative"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
          color: currentTheme.colors.ink,
        }}
      >
        {/* Header */}
        <div
          className="p-5 md:p-6 border-b flex justify-between items-center"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shadow-md shrink-0"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}20`,
                borderColor: currentTheme.colors.neonCyan,
                borderWidth: '1px',
                color: currentTheme.colors.neonCyan,
              }}
            >
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display text-lg md:text-xl font-bold tracking-tight">
                  Voice Commands & Multilingual Agent Console
                </h3>
                <span
                  className="font-mono text-[0.62rem] px-2 py-0.5 rounded-full border font-bold uppercase"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonEmerald}18`,
                    borderColor: currentTheme.colors.neonEmerald,
                    color: currentTheme.colors.neonEmerald,
                  }}
                >
                  Active: {currentLanguage.flag} {currentLanguage.nativeName}
                </span>
              </div>
              <p className="text-xs font-sans mt-0.5" style={{ color: currentTheme.colors.inkMuted }}>
                Speak naturally in your preferred language or use voice commands to control the assessment hands-free.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg border hover:brightness-125 transition-all cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.inkMuted,
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Toggles Bar */}
        <div
          className="px-6 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs"
          style={{
            backgroundColor: `${currentTheme.colors.bgCard}99`,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-4">
            {/* Hands-Free Mode Toggle */}
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isHandsFreeMode}
                onChange={(e) => setIsHandsFreeMode(e.target.checked)}
                className="rounded cursor-pointer accent-cyan-500"
              />
              <span className="font-bold flex items-center gap-1">
                <Radio className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonCyan }} />
                Hands-Free Voice Mode
              </span>
            </label>

            {/* Audio Voice Readout Toggle */}
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isAudioEnabled}
                onChange={(e) => setIsAudioEnabled(e.target.checked)}
                className="rounded cursor-pointer accent-purple-500"
              />
              <span className="font-bold flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonPurple }} />
                Question Voice Readout
              </span>
            </label>
          </div>

          {/* Quick Language Selector */}
          <div className="flex items-center gap-2">
            <span className="font-mono text-[0.68rem] font-bold" style={{ color: currentTheme.colors.inkMuted }}>
              Language:
            </span>
            <select
              value={currentLanguage.id}
              onChange={(e) => {
                const l = SUPPORTED_LANGUAGES.find((lang) => lang.id === e.target.value);
                if (l) onSelectLanguage(l);
              }}
              className="font-mono text-[0.72rem] px-2.5 py-1 rounded-lg border cursor-pointer font-bold outline-none"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.neonCyan,
                color: currentTheme.colors.neonCyan,
              }}
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.id} value={lang.id} style={{ backgroundColor: currentTheme.colors.bgSurface, color: currentTheme.colors.ink }}>
                  {lang.flag} {lang.nativeName} ({lang.name})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Test Result Banner */}
        {testResult && (
          <div
            className="px-6 py-2 border-b flex items-center gap-2 font-mono text-xs font-bold animate-in slide-in-from-top-2"
            style={{
              backgroundColor: `${currentTheme.colors.neonEmerald}22`,
              borderColor: currentTheme.colors.neonEmerald,
              color: currentTheme.colors.neonEmerald,
            }}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{testResult}</span>
          </div>
        )}

        {/* Category Tabs */}
        <div
          className="px-6 pt-3 pb-2 border-b flex items-center gap-2 overflow-x-auto no-scrollbar"
          style={{ borderColor: currentTheme.colors.borderDark }}
        >
          {[
            { id: 'all', label: 'All Voice Commands' },
            { id: 'interview', label: 'Interview & Answers' },
            { id: 'navigation', label: 'Navigation & Roster' },
            { id: 'audio', label: 'Hands-Free & Audio' },
            { id: 'languages', label: 'Multilingual Switching' },
          ].map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`font-mono text-xs px-3 py-1.5 rounded-lg border transition-all cursor-pointer shrink-0 font-bold ${
                  isActive ? 'shadow-sm scale-[1.02]' : 'opacity-70 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: isActive ? `${currentTheme.colors.neonCyan}20` : currentTheme.colors.bgSurface,
                  borderColor: isActive ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
                  color: isActive ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                }}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Command List Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {filteredCategories.map((cat) => (
            <div key={cat.id} className="space-y-3">
              <div className="flex items-center gap-2 pb-1 border-b" style={{ borderColor: `${currentTheme.colors.borderDark}66` }}>
                <span style={{ color: currentTheme.colors.neonPurple }}>{cat.icon}</span>
                <h4 className="font-display text-sm font-bold tracking-tight uppercase" style={{ color: currentTheme.colors.neonPurple }}>
                  {cat.title}
                </h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {cat.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border transition-all flex flex-col justify-between gap-2.5 group hover:border-cyan-500/60"
                    style={{
                      backgroundColor: currentTheme.colors.bgCard,
                      borderColor: currentTheme.colors.borderDark,
                    }}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className="font-mono text-xs font-black px-2 py-0.5 rounded border flex items-center gap-1.5"
                          style={{
                            backgroundColor: `${currentTheme.colors.neonCyan}15`,
                            borderColor: `${currentTheme.colors.neonCyan}44`,
                            color: currentTheme.colors.neonCyan,
                          }}
                        >
                          <Mic className="w-3 h-3" />
                          "{item.command}"
                        </span>

                        <button
                          onClick={() => handleTestClick(item.action, item.command)}
                          className="font-mono text-[0.62rem] px-2 py-1 rounded border font-bold flex items-center gap-1 transition-all cursor-pointer opacity-80 group-hover:opacity-100 hover:brightness-110"
                          style={{
                            backgroundColor: currentTheme.colors.bgSurface,
                            borderColor: currentTheme.colors.borderDark,
                            color: currentTheme.colors.neonEmerald,
                          }}
                          title="Test executing this voice command directly"
                        >
                          <Play className="w-2.5 h-2.5 fill-current" />
                          Test
                        </button>
                      </div>

                      <p className="text-xs font-sans mt-2 leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                        {item.description}
                      </p>
                    </div>

                    {item.aliases && item.aliases.length > 0 && (
                      <div className="pt-2 border-t flex flex-wrap items-center gap-1.5" style={{ borderColor: `${currentTheme.colors.borderDark}44` }}>
                        <span className="font-mono text-[0.6rem] uppercase opacity-50">Also matches:</span>
                        {item.aliases.map((alias, aIdx) => (
                          <span
                            key={aIdx}
                            className="font-mono text-[0.58rem] px-1.5 py-0.2 rounded border"
                            style={{
                              backgroundColor: currentTheme.colors.bgSurface,
                              borderColor: currentTheme.colors.borderDark,
                              color: currentTheme.colors.inkFaint,
                            }}
                          >
                            "{alias}"
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div
          className="p-4 border-t flex flex-wrap justify-between items-center gap-3 select-none"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center gap-2 text-xs font-sans" style={{ color: currentTheme.colors.inkMuted }}>
            <Sparkles className="w-4 h-4" style={{ color: currentTheme.colors.neonCyan }} />
            <span>Voice commands work simultaneously with text input & answer presets in {SUPPORTED_LANGUAGES.length} languages.</span>
          </div>

          <button
            onClick={onClose}
            className="font-mono text-xs font-bold uppercase tracking-wider px-4 py-2 rounded-lg cursor-pointer transition-all hover:brightness-110"
            style={{
              backgroundColor: currentTheme.colors.neonCyan,
              color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
            }}
          >
            Got It, Back to Interview
          </button>
        </div>
      </div>
    </div>
  );
};
