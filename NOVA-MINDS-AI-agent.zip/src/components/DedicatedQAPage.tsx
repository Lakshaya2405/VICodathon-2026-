import React, { useState, useEffect, useRef } from 'react';
import {
  BrainCircuit,
  User,
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Maximize2,
  Minimize2,
  FileCode,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  Zap,
  Code,
  Layers,
  ChevronRight,
  BookOpen,
  Copy,
  Check,
  Split,
  Eye,
  Radio,
  FileText,
  Edit3,
  BarChart3,
} from 'lucide-react';
import { InterviewSessionState, CandidateProfile, AnswerEvaluation } from '../server/types';
import { useTheme } from '../theme/ThemeContext';
import { CurriculumService } from '../server/curriculumService';
import { SUPPORTED_LANGUAGES, SupportedLanguage } from '../data/languages';
import { parseVoiceCommand } from '../utils/voiceCommands';

interface DedicatedQAPageProps {
  session: InterviewSessionState | null;
  candidate: CandidateProfile;
  candidates: CandidateProfile[];
  onSelectCandidate: (candidate: CandidateProfile) => void;
  onSendMessage: (message: string) => Promise<void>;
  isLoading: boolean;
  onViewFeedback: () => void;
  onOpenCatchAllChats: () => void;
  onBackToConsole: () => void;
  onNavigateToScores?: () => void;
}

export const DedicatedQAPage: React.FC<DedicatedQAPageProps> = ({
  session,
  candidate,
  candidates,
  onSelectCandidate,
  onSendMessage,
  isLoading,
  onViewFeedback,
  onOpenCatchAllChats,
  onBackToConsole,
  onNavigateToScores,
}) => {
  const { currentTheme } = useTheme();
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [layoutMode, setLayoutMode] = useState<'split' | 'stacked' | 'zen'>('split');
  const [mobileQATab, setMobileQATab] = useState<'question' | 'response'>('response');
  const [fontSizeLevel, setFontSizeLevel] = useState<'normal' | 'large' | 'huge'>('large');
  const [activeCodeSnippet, setActiveCodeSnippet] = useState<string | null>(null);
  const [copiedQuestion, setCopiedQuestion] = useState(false);
  const [activePresetCategory, setActivePresetCategory] = useState<'all' | 'senior' | 'hands_on' | 'flawed' | 'clarify'>('all');
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [hintOpen, setHintOpen] = useState(false);

  const recognitionRef = useRef<any>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Extract the latest active question asked by the interviewer
  const lastInterviewerTurn = session?.conversationHistory
    ? [...session.conversationHistory].reverse().find((t) => t.role === 'interviewer')
    : null;

  const currentQuestionText =
    lastInterviewerTurn?.content ||
    session?.currentQuestion ||
    `Welcome ${candidate.member.name}. Could you explain how you converted raw text documents into dense vector embeddings and how semantic similarity search works under the hood?`;

  const currentDayData = session?.currentDay
    ? CurriculumService.getDay(session.currentDay)
    : CurriculumService.getDay(7);

  // Text to Speech logic
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window) || !isAudioEnabled) return;
    window.speechSynthesis.cancel();
    const clean = text.replace(/[*#`_-]/g, ' ');
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = speechRate;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  // Trigger TTS on new question if audio is enabled
  useEffect(() => {
    if (isAudioEnabled && currentQuestionText && session?.conversationHistory?.length) {
      const lastTurn = session.conversationHistory[session.conversationHistory.length - 1];
      if (lastTurn && lastTurn.role === 'interviewer') {
        speakText(lastTurn.content);
      }
    }
  }, [session?.conversationHistory?.length, isAudioEnabled]);

  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setStatusNotice(msg);
    setTimeout(() => setStatusNotice(null), 4000);
  };

  // Speech Recognition
  const toggleSpeechRecognition = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      showNotice('Speech recognition is not supported in this browser. Please type or use presets.');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }

        // Check if voice command
        const parsed = parseVoiceCommand(currentTranscript, SUPPORTED_LANGUAGES[0], candidates);
        if (parsed.isCommand && parsed.action) {
          if (parsed.action.type === 'SUBMIT_ANSWER') {
            handleSend();
            recognition.stop();
            setIsListening(false);
            return;
          } else if (parsed.action.type === 'REPEAT_QUESTION') {
            speakText(currentQuestionText);
            return;
          } else if (parsed.action.type === 'CLEAR_INPUT') {
            setInputText('');
            return;
          }
        }

        setInputText((prev) => {
          if (!prev.includes(currentTranscript)) {
            return `${prev} ${currentTranscript}`.trim();
          }
          return prev;
        });
      };

      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
      recognitionRef.current = recognition;
      setIsListening(true);
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  const handleSend = async () => {
    if (!inputText.trim() || isLoading || session?.status === 'completed') return;
    const msg = inputText.trim();
    setInputText('');
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
    await onSendMessage(msg);
    setTimeout(() => {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 150);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyQuestionToClipboard = () => {
    navigator.clipboard.writeText(currentQuestionText);
    setCopiedQuestion(true);
    setTimeout(() => setCopiedQuestion(false), 2000);
  };

  // Technical snippet templates
  const codeSnippets = [
    {
      label: 'Python Vector Embeddings',
      code: `from sentence_transformers import SentenceTransformer
import chromadb

# Initialize embedding model (384-dimensional dense vectors)
embedder = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.PersistentClient(path="./chroma_db")
collection = client.get_or_create_collection(
    name="clinical_docs",
    metadata={"hnsw:space": "cosine"}
)

# Generate dense vector embeddings with chunk overlap
embeddings = embedder.encode(chunks, show_progress_bar=False)`,
    },
    {
      label: 'FastAPI Hybrid Query Router',
      code: `@app.post("/api/query")
async def hybrid_query(req: QueryRequest):
    # Route structured filters to SQL, unstructured text to ChromaDB
    vector_results = collection.query(
        query_texts=[req.query],
        n_results=5,
        where={"department": req.dept_filter}
    )
    return {"results": vector_results, "latency_ms": 42}`,
    },
    {
      label: 'BM25 + Semantic Re-ranking',
      code: `# Hybrid search combining BM25 keyword matching with Dense Vectors
dense_hits = vector_db.search(query_vec, top_k=20)
sparse_hits = bm25_index.get_top_n(query_tokens, corpus, n=20)
# Reciprocal Rank Fusion (RRF) for hallucination reduction
final_context = rrf_merge(dense_hits, sparse_hits, alpha=0.6)`,
    },
  ];

  // Presets
  const simulationPresets = [
    {
      badge: '👑 Senior Deep Architecture',
      title: 'HNSW Indexing & Sentence Transformers',
      text: 'We selected Sentence Transformers (all-MiniLM-L6-v2) for 384-dimensional vector embeddings with 512-token chunks and 10% overlap. In ChromaDB, we configured HNSW graph indexing with cosine distance to balance recall vs sub-20ms search latency.',
    },
    {
      badge: '⚡ Production Hybrid Query',
      title: 'FastAPI Routing & Structured SQLite Filtering',
      text: 'Our hybrid architecture directs structured metadata queries into SQLite while routing unstructured symptoms into vector similarity search, merging rankings with Reciprocal Rank Fusion before LLM context injection.',
    },
    {
      badge: '🛡️ Safety & Guardrails',
      title: 'BM25 Re-Ranking & Zero Hallucination',
      text: 'To avoid hallucinations in medical context, we pair semantic embeddings with BM25 keyword filtering and a cross-encoder re-ranker, enforcing strict ground-truth prompt citations with temperature 0.2.',
    },
    {
      badge: '💡 Clarify Technical Constraints',
      title: 'Ask about QPS & Memory Target',
      text: 'Could you clarify the expected QPS target and memory budget for this vector search tier? That will determine whether in-memory Flat indexing or HNSW graph quantization is optimal.',
    },
  ];

  // Dynamic font sizing classes
  const questionFontClass =
    fontSizeLevel === 'huge'
      ? 'font-serif text-[1.45rem] md:text-[1.75rem] leading-[1.65]'
      : fontSizeLevel === 'large'
      ? 'font-serif text-[1.25rem] md:text-[1.48rem] leading-[1.65]'
      : 'font-serif text-[1.1rem] md:text-[1.25rem] leading-[1.6]';

  const responseFontClass =
    fontSizeLevel === 'huge'
      ? 'text-[1.15rem] leading-relaxed'
      : fontSizeLevel === 'large'
      ? 'text-[1.02rem] leading-relaxed'
      : 'text-[0.92rem] leading-relaxed';

  return (
    <div
      id="dedicated-qa-page-workspace"
      className="flex-1 flex flex-col h-full overflow-hidden relative z-10 animate-in fade-in duration-200"
    >
      {/* Top Header Control Toolbar */}
      <div
        className="px-6 py-3.5 border-b flex flex-wrap items-center justify-between gap-3 backdrop-blur-xl shadow-xs"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToConsole}
            className="font-mono text-xs px-3 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.inkMuted,
            }}
          >
            <span>← Standard Console</span>
          </button>

          <div className="h-4 w-[1px]" style={{ backgroundColor: currentTheme.colors.borderDark }} />

          <div className="flex items-center gap-2">
            <span
              className="font-mono text-xs font-black px-2.5 py-1 rounded-lg border uppercase tracking-wider flex items-center gap-1.5"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}20`,
                borderColor: currentTheme.colors.neonCyan,
                color: currentTheme.colors.neonCyan,
              }}
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>DEDICATED Q/A FOCUS PAGE</span>
            </span>

            <span className="font-mono text-xs font-bold hidden sm:inline" style={{ color: currentTheme.colors.inkMuted }}>
              Candidate: <span style={{ color: currentTheme.colors.ink }}>{candidate.member.name}</span> ({candidate.member.jobRole})
            </span>
          </div>
        </div>

        {/* Right View & Sizing Toggles */}
        <div className="flex items-center gap-2.5">
          {/* Font Size Selector */}
          <div className="flex items-center gap-1 bg-black/20 p-1 rounded-lg border" style={{ borderColor: currentTheme.colors.borderDark }}>
            <span className="font-mono text-[0.62rem] px-1 font-bold" style={{ color: currentTheme.colors.inkMuted }}>
              Font:
            </span>
            {(['normal', 'large', 'huge'] as const).map((sz) => (
              <button
                key={sz}
                onClick={() => setFontSizeLevel(sz)}
                className={`font-mono text-[0.65rem] px-2 py-0.5 rounded cursor-pointer font-bold transition-all ${
                  fontSizeLevel === sz ? 'shadow-xs' : 'opacity-60 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: fontSizeLevel === sz ? currentTheme.colors.neonCyan : 'transparent',
                  color: fontSizeLevel === sz ? '#000' : currentTheme.colors.ink,
                }}
              >
                {sz.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Layout Mode (Split / Stacked / Zen) */}
          <div className="flex items-center gap-1 bg-black/20 p-1 rounded-lg border" style={{ borderColor: currentTheme.colors.borderDark }}>
            <button
              onClick={() => setLayoutMode('split')}
              className={`font-mono text-[0.65rem] px-2 py-0.5 rounded cursor-pointer font-bold flex items-center gap-1 transition-all ${
                layoutMode === 'split' ? 'shadow-xs' : 'opacity-60 hover:opacity-100'
              }`}
              style={{
                backgroundColor: layoutMode === 'split' ? currentTheme.colors.neonPurple : 'transparent',
                color: layoutMode === 'split' ? '#fff' : currentTheme.colors.ink,
              }}
              title="Split View: Side-by-side question & response view"
            >
              <Split className="w-3 h-3" />
              <span>Split</span>
            </button>

            <button
              onClick={() => setLayoutMode('stacked')}
              className={`font-mono text-[0.65rem] px-2 py-0.5 rounded cursor-pointer font-bold flex items-center gap-1 transition-all ${
                layoutMode === 'stacked' ? 'shadow-xs' : 'opacity-60 hover:opacity-100'
              }`}
              style={{
                backgroundColor: layoutMode === 'stacked' ? currentTheme.colors.neonPurple : 'transparent',
                color: layoutMode === 'stacked' ? '#fff' : currentTheme.colors.ink,
              }}
              title="Stacked View: Top question card stacked on full-width response canvas"
            >
              <Layers className="w-3 h-3" />
              <span>Stacked</span>
            </button>

            <button
              onClick={() => setLayoutMode('zen')}
              className={`font-mono text-[0.65rem] px-2 py-0.5 rounded cursor-pointer font-bold flex items-center gap-1 transition-all ${
                layoutMode === 'zen' ? 'shadow-xs' : 'opacity-60 hover:opacity-100'
              }`}
              style={{
                backgroundColor: layoutMode === 'zen' ? currentTheme.colors.neonCyan : 'transparent',
                color: layoutMode === 'zen' ? '#000' : currentTheme.colors.ink,
              }}
              title="Zen Mode: Maximum-space immersive response canvas with collapsible question"
            >
              <Maximize2 className="w-3 h-3" />
              <span>Zen</span>
            </button>
          </div>

          {/* Speech Rate Controls */}
          {isAudioEnabled && (
            <div className="hidden sm:flex items-center gap-1 bg-black/20 p-1 rounded-lg border" style={{ borderColor: currentTheme.colors.borderDark }}>
              {[1.0, 1.25, 1.5].map((rate) => (
                <button
                  key={rate}
                  onClick={() => setSpeechRate(rate)}
                  className={`font-mono text-[0.62rem] px-1.5 py-0.5 rounded cursor-pointer font-bold transition-all ${
                    speechRate === rate ? 'shadow-xs' : 'opacity-60 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: speechRate === rate ? `${currentTheme.colors.neonCyan}30` : 'transparent',
                    color: speechRate === rate ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                  }}
                >
                  {rate}x
                </button>
              ))}
            </div>
          )}

          {/* TTS Audio Voice Button */}
          <button
            onClick={() => setIsAudioEnabled(!isAudioEnabled)}
            className="p-2 rounded-lg border font-mono text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110"
            style={{
              backgroundColor: isAudioEnabled ? `${currentTheme.colors.neonCyan}25` : currentTheme.colors.bgSurface,
              borderColor: isAudioEnabled ? currentTheme.colors.neonCyan : currentTheme.colors.borderDark,
              color: isAudioEnabled ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
            }}
            title={isAudioEnabled ? 'Voice read-aloud active' : 'Voice muted'}
          >
            {isAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden md:inline">{isAudioEnabled ? 'Voice ON' : 'Muted'}</span>
          </button>

          {/* Jump to Score Display */}
          {onNavigateToScores && (
            <button
              onClick={onNavigateToScores}
              className="font-mono text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
              style={{
                backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                borderColor: currentTheme.colors.neonEmerald,
                color: currentTheme.colors.neonEmerald,
              }}
              title="Open Dedicated Score Display Matrix"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Score Display</span>
            </button>
          )}

          {/* Catch All Chats Single File Export */}
          <button
            onClick={onOpenCatchAllChats}
            className="font-mono text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
            style={{
              backgroundColor: `${currentTheme.colors.neonCyan}20`,
              borderColor: currentTheme.colors.neonCyan,
              color: currentTheme.colors.neonCyan,
            }}
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Catch All Chats</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Body */}
      <div className="flex-1 overflow-hidden p-4 md:p-6 flex flex-col gap-4">
        {statusNotice && (
          <div
            className="px-4 py-2 rounded-xl border font-mono text-xs font-bold flex items-center justify-between animate-in fade-in slide-in-from-top-2"
            style={{
              backgroundColor: `${currentTheme.colors.neonMagenta}20`,
              borderColor: currentTheme.colors.neonMagenta,
              color: currentTheme.colors.neonMagenta,
            }}
          >
            <span>{statusNotice}</span>
            <button onClick={() => setStatusNotice(null)} className="cursor-pointer opacity-70 hover:opacity-100">✕</button>
          </div>
        )}

        {/* Mobile Sub-view switcher for Split Mode on phone/tablet */}
        {layoutMode === 'split' && (
          <div
            className="lg:hidden flex items-center p-1 rounded-xl border mb-3 shrink-0 shadow-sm select-none"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <button
              onClick={() => setMobileQATab('question')}
              className="flex-1 py-2 px-3 rounded-lg font-mono text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor: mobileQATab === 'question' ? `${currentTheme.colors.neonCyan}25` : 'transparent',
                borderColor: mobileQATab === 'question' ? currentTheme.colors.neonCyan : 'transparent',
                borderWidth: '1px',
                color: mobileQATab === 'question' ? currentTheme.colors.neonCyan : currentTheme.colors.inkMuted,
                boxShadow: mobileQATab === 'question' ? `0 0 10px ${currentTheme.colors.primaryGlow}` : 'none',
              }}
            >
              <BrainCircuit className="w-3.5 h-3.5" />
              <span>Active Question (Q{session?.questionCount || 1})</span>
            </button>
            <button
              onClick={() => setMobileQATab('response')}
              className="flex-1 py-2 px-3 rounded-lg font-mono text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              style={{
                backgroundColor: mobileQATab === 'response' ? `${currentTheme.colors.neonMagenta}25` : 'transparent',
                borderColor: mobileQATab === 'response' ? currentTheme.colors.neonMagenta : 'transparent',
                borderWidth: '1px',
                color: mobileQATab === 'response' ? currentTheme.colors.neonMagenta : currentTheme.colors.inkMuted,
                boxShadow: mobileQATab === 'response' ? `0 0 10px ${currentTheme.colors.secondaryGlow}` : 'none',
              }}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Response Studio</span>
            </button>
          </div>
        )}

        {/* Layout Grid */}
        <div
          className={`flex-1 overflow-hidden ${
            layoutMode === 'split'
              ? 'grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-5'
              : layoutMode === 'stacked'
              ? 'flex flex-col gap-4 overflow-y-auto pr-1'
              : 'flex flex-col gap-3'
          }`}
        >
          {/* SECTION A: SUPER-SIZED ACTIVE QUESTION CARD & CONVERSATION TRANSCRIPT */}
          <div
            className={`flex flex-col rounded-2xl border shadow-xl overflow-hidden backdrop-blur-xl transition-all ${
              layoutMode === 'split'
                ? 'lg:col-span-6'
                : layoutMode === 'stacked'
                ? 'w-full shrink-0 min-h-[340px]'
                : 'w-full shrink-0'
            } ${layoutMode === 'split' && mobileQATab === 'response' ? 'hidden lg:flex' : 'flex'}`}
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: `${currentTheme.colors.neonCyan}44`,
            }}
          >
            {/* Question Card Banner Header */}
            <div
              className="p-4 md:p-5 border-b flex flex-wrap justify-between items-center gap-3 select-none"
              style={{
                backgroundColor: `${currentTheme.colors.bgSurface}ee`,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-bold shadow-md shrink-0"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonCyan}20`,
                    borderColor: currentTheme.colors.neonCyan,
                    borderWidth: '1px',
                    color: currentTheme.colors.neonCyan,
                  }}
                >
                  <BrainCircuit className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className="font-mono text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded border"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonCyan}18`,
                        borderColor: `${currentTheme.colors.neonCyan}40`,
                        color: currentTheme.colors.neonCyan,
                      }}
                    >
                      Question {session?.questionCount || 1} of 8
                    </span>
                    <span
                      className="font-mono text-xs px-2 py-0.5 rounded border font-bold"
                      style={{
                        backgroundColor: `${currentTheme.colors.neonPurple}18`,
                        borderColor: `${currentTheme.colors.neonPurple}40`,
                        color: currentTheme.colors.neonPurple,
                      }}
                    >
                      Day {session?.currentDay || 7} • {session?.currentTopic || 'Embeddings Explained'}
                    </span>
                  </div>
                  <span className="text-[0.72rem] font-sans" style={{ color: currentTheme.colors.inkMuted }}>
                    Calibrated Difficulty: <span className="font-bold uppercase text-[var(--ink)]">{session?.difficulty || 'Medium'}</span>
                  </span>
                </div>
              </div>

              {/* Question Actions */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => speakText(currentQuestionText)}
                  className="font-mono text-xs px-2.5 py-1.5 rounded-lg border font-bold flex items-center gap-1.5 transition-all cursor-pointer hover:brightness-110 shadow-xs"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.neonCyan,
                    color: currentTheme.colors.neonCyan,
                  }}
                  title="Read question aloud"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen</span>
                </button>

                <button
                  onClick={copyQuestionToClipboard}
                  className="p-1.5 rounded-lg border transition-all cursor-pointer hover:brightness-110"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                    color: copiedQuestion ? currentTheme.colors.neonEmerald : currentTheme.colors.inkMuted,
                  }}
                  title="Copy question text"
                >
                  {copiedQuestion ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>

                <button
                  onClick={() => setHintOpen(!hintOpen)}
                  className="font-mono text-xs px-2.5 py-1.5 rounded-lg border font-bold flex items-center gap-1 transition-all cursor-pointer hover:brightness-110"
                  style={{
                    backgroundColor: hintOpen ? `${currentTheme.colors.neonAmber}25` : currentTheme.colors.bgSurface,
                    borderColor: hintOpen ? currentTheme.colors.neonAmber : currentTheme.colors.borderDark,
                    color: hintOpen ? currentTheme.colors.neonAmber : currentTheme.colors.inkMuted,
                  }}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Rubric Hint</span>
                </button>
              </div>
            </div>

            {/* Rubric Hint Expandable Bar */}
            {hintOpen && (
              <div
                className="p-4 border-b text-xs font-sans space-y-1.5 animate-in slide-in-from-top-2"
                style={{
                  backgroundColor: `${currentTheme.colors.neonAmber}12`,
                  borderColor: currentTheme.colors.neonAmber,
                  color: currentTheme.colors.ink,
                }}
              >
                <div className="flex items-center gap-2 font-bold" style={{ color: currentTheme.colors.neonAmber }}>
                  <Sparkles className="w-4 h-4" />
                  <span>Evaluation Objectives for Day {session?.currentDay || 7}:</span>
                </div>
                <ul className="list-disc list-inside space-y-1 pl-1 text-[0.82rem] leading-relaxed">
                  {currentDayData?.objectives?.map((obj, i) => (
                    <li key={i}>{obj}</li>
                  )) || <li>Explain dense vector embeddings, cosine distance, and chunk overlap.</li>}
                </ul>
              </div>
            )}

            {/* SUPER-SIZED ACTIVE QUESTION HERO DISPLAY */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6">
              {/* Primary Active Question Box */}
              <div
                className="p-6 md:p-7 rounded-2xl border shadow-md relative"
                style={{
                  backgroundColor: `${currentTheme.colors.bgSurface}ee`,
                  borderColor: currentTheme.colors.neonCyan,
                  boxShadow: `0 0 25px ${currentTheme.colors.primaryGlow}`,
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <span
                    className="font-mono text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded border"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonCyan}20`,
                      borderColor: currentTheme.colors.neonCyan,
                      color: currentTheme.colors.neonCyan,
                    }}
                  >
                    CURRENT TECHNICAL QUESTION
                  </span>
                </div>

                <div
                  className={`${questionFontClass} font-semibold`}
                  style={{ color: currentTheme.colors.ink }}
                >
                  {currentQuestionText}
                </div>
              </div>

              {/* Previous Conversation History Stream */}
              {session?.conversationHistory && session.conversationHistory.length > 1 && (
                <div className="space-y-4 pt-4 border-t" style={{ borderColor: currentTheme.colors.borderDark }}>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold uppercase tracking-wider" style={{ color: currentTheme.colors.inkMuted }}>
                      Full Transcript History ({session.conversationHistory.length} turns)
                    </span>
                  </div>

                  {session.conversationHistory.slice(0, -1).map((turn, idx) => {
                    const isAgent = turn.role === 'interviewer';
                    return (
                      <div
                        key={idx}
                        className={`p-4 rounded-xl border ${isAgent ? 'border' : 'ml-4 md:ml-8'}`}
                        style={{
                          backgroundColor: isAgent ? currentTheme.colors.bgSurface : `${currentTheme.colors.bgCardHover}ee`,
                          borderColor: isAgent ? `${currentTheme.colors.neonCyan}33` : currentTheme.colors.borderDark,
                        }}
                      >
                        <div className="flex items-center justify-between gap-2 mb-1.5 font-mono text-[0.68rem] font-bold">
                          <span style={{ color: isAgent ? currentTheme.colors.neonCyan : currentTheme.colors.neonMagenta }}>
                            {isAgent ? 'NOVA MIND AGENT' : `CANDIDATE (${candidate.member.name})`}
                          </span>
                          <span style={{ color: currentTheme.colors.inkFaint }}>
                            {new Date(turn.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <div className="font-sans text-[0.92rem] leading-relaxed" style={{ color: currentTheme.colors.inkMuted }}>
                          {turn.content}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              <div ref={chatBottomRef} />
            </div>
          </div>

          {/* SECTION B: MASSIVE TECHNICAL RESPONSE EDITOR & ACTION CANVAS */}
          <div
            className={`flex flex-col rounded-2xl border shadow-xl overflow-hidden backdrop-blur-xl transition-all ${
              layoutMode === 'split'
                ? 'lg:col-span-6'
                : layoutMode === 'stacked'
                ? 'w-full shrink-0 min-h-[480px]'
                : 'flex-1'
            } ${layoutMode === 'split' && mobileQATab === 'question' ? 'hidden lg:flex' : 'flex'}`}
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            {/* Editor Header & Snippet Toolbar */}
            <div
              className="p-4 md:p-5 border-b flex flex-wrap justify-between items-center gap-3 select-none"
              style={{
                backgroundColor: `${currentTheme.colors.bgSurface}ee`,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center font-bold"
                  style={{
                    backgroundColor: `${currentTheme.colors.neonMagenta}20`,
                    borderColor: currentTheme.colors.neonMagenta,
                    borderWidth: '1px',
                    color: currentTheme.colors.neonMagenta,
                  }}
                >
                  <User className="w-4 h-4" />
                </div>
                <h3 className="font-display font-bold text-base md:text-lg tracking-tight" style={{ color: currentTheme.colors.ink }}>
                  Technical Response Canvas
                </h3>
              </div>

              {/* Character & Word Counter */}
              <div className="flex items-center gap-3 font-mono text-xs font-semibold" style={{ color: currentTheme.colors.inkMuted }}>
                <span className="px-2.5 py-1 rounded bg-black/10 dark:bg-white/5">{inputText.trim().split(/\s+/).filter(Boolean).length} words</span>
                <span>•</span>
                <span className="px-2.5 py-1 rounded bg-black/10 dark:bg-white/5">{inputText.length} chars</span>
              </div>
            </div>

            {/* Expanded Architecture & Code Insert Tabs (Above Q/A Input) */}
            <div
              className="px-5 py-3 border-b flex flex-wrap items-center justify-between gap-3 text-xs shadow-xs"
              style={{
                backgroundColor: `${currentTheme.colors.bgSurface}ee`,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-xs uppercase font-black flex items-center gap-1.5" style={{ color: currentTheme.colors.neonCyan }}>
                  <Code className="w-3.5 h-3.5" />
                  <span>Insert Architecture Tab:</span>
                </span>
                {codeSnippets.map((snip, i) => (
                  <button
                    key={i}
                    onClick={() => setInputText((prev) => `${prev}\n\n\`\`\`python\n${snip.code}\n\`\`\`\n`)}
                    className="font-mono text-xs px-3 py-1.5 rounded-lg border font-bold transition-all cursor-pointer hover:brightness-110 shadow-xs hover:scale-[1.02]"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonCyan}15`,
                      borderColor: currentTheme.colors.neonCyan,
                      color: currentTheme.colors.neonCyan,
                    }}
                  >
                    + {snip.label}
                  </button>
                ))}
              </div>

              {/* Clear Input */}
              {inputText && (
                <button
                  onClick={() => setInputText('')}
                  className="font-mono text-xs px-3 py-1.5 rounded-lg border font-bold opacity-80 hover:opacity-100 cursor-pointer"
                  style={{
                    backgroundColor: currentTheme.colors.bgSurface,
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.neonMagenta,
                  }}
                >
                  Clear Draft
                </button>
              )}
            </div>

            {/* MASSIVE EXPANDED TEXTAREA CANVAS */}
            <div className="flex-1 p-5 md:p-6 flex flex-col gap-4 overflow-hidden relative">
              <textarea
                ref={textareaRef}
                id="dedicated-qa-textarea"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading || session?.status === 'completed'}
                placeholder={
                  session?.status === 'completed'
                    ? 'Interview completed. Click "View Final Evaluation Report" to inspect multi-dimensional scores.'
                    : 'Craft detailed technical response... Explain mathematical formulas, chunking tradeoffs, vector indexing (HNSW, Cosine), FastAPI endpoints, or paste Python snippets.\n\nTip: Press Ctrl + Enter (or Cmd + Enter) to instantly submit.'
                }
                className={`w-full flex-1 p-5 rounded-xl border outline-none font-mono ${responseFontClass} resize-none transition-all shadow-inner leading-relaxed`}
                style={{
                  backgroundColor: currentTheme.colors.bgSurface,
                  borderColor: currentTheme.colors.borderDark,
                  color: currentTheme.colors.ink,
                  minHeight: '260px',
                }}
              />

              {/* Quick Simulation Presets Row */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[0.65rem] uppercase font-bold tracking-wider" style={{ color: currentTheme.colors.neonPurple }}>
                    1-Click High-Scoring Response Presets:
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-32 overflow-y-auto pr-1">
                  {simulationPresets.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => setInputText(p.text)}
                      className="p-2.5 rounded-lg border text-left transition-all cursor-pointer hover:brightness-110 flex flex-col gap-1 shadow-xs"
                      style={{
                        backgroundColor: currentTheme.colors.bgSurface,
                        borderColor: currentTheme.colors.borderDark,
                        color: currentTheme.colors.ink,
                      }}
                    >
                      <span className="font-mono text-[0.62rem] font-black" style={{ color: currentTheme.colors.neonCyan }}>
                        {p.badge}
                      </span>
                      <span className="text-[0.72rem] font-sans line-clamp-2" style={{ color: currentTheme.colors.inkMuted }}>
                        {p.text}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Action Footer */}
            <div
              className="p-4 md:p-5 border-t flex flex-wrap justify-between items-center gap-3"
              style={{
                backgroundColor: `${currentTheme.colors.bgSurface}ee`,
                borderColor: currentTheme.colors.borderDark,
              }}
            >
              {/* Voice Speech Recognition Button */}
              <button
                type="button"
                onClick={toggleSpeechRecognition}
                disabled={isLoading || session?.status === 'completed'}
                className="px-4 py-3 rounded-xl border font-mono text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-xs hover:brightness-110 disabled:opacity-30"
                style={{
                  backgroundColor: isListening ? `${currentTheme.colors.neonMagenta}33` : currentTheme.colors.bgSurface,
                  borderColor: isListening ? currentTheme.colors.neonMagenta : currentTheme.colors.borderDark,
                  color: isListening ? currentTheme.colors.neonMagenta : currentTheme.colors.ink,
                }}
              >
                {isListening ? <MicOff className="w-4 h-4 animate-pulse" /> : <Mic className="w-4 h-4" />}
                <span>{isListening ? 'Stop Listening (Mic Active)' : 'Dictate Answer (Mic)'}</span>
              </button>

              {/* Submit Button */}
              <div className="flex items-center gap-3">
                <span className="font-mono text-[0.65rem] opacity-60 hidden sm:inline">
                  Shortcut: <kbd className="px-1.5 py-0.5 rounded border bg-black/20">Ctrl + Enter</kbd>
                </span>

                <button
                  id="btn-dedicated-qa-submit"
                  onClick={handleSend}
                  disabled={!inputText.trim() || isLoading || session?.status === 'completed'}
                  className="px-8 py-3.5 rounded-xl font-mono text-xs font-black uppercase tracking-wider hover:brightness-110 transition-all disabled:opacity-20 cursor-pointer flex items-center gap-2 shadow-lg"
                  style={{
                    background: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonMagenta})`,
                    color: currentTheme.mode === 'light' ? '#ffffff' : '#07070a',
                    boxShadow: `0 0 20px ${currentTheme.colors.primaryGlow}`,
                  }}
                >
                  <span>SUBMIT TECHNICAL ANSWER</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
