import React, { useState } from 'react';
import { Search, Play, Users, Sparkles, Filter } from 'lucide-react';
import { CandidateProfile } from '../server/types';
import { CandidateService } from '../server/candidateService';
import { useTheme } from '../theme/ThemeContext';

interface CandidateRosterViewProps {
  candidates: CandidateProfile[];
  selectedCandidate: CandidateProfile | null;
  onSelectAndStart: (candidate: CandidateProfile) => void;
}

export const CandidateRosterView: React.FC<CandidateRosterViewProps> = ({
  candidates,
  selectedCandidate,
  onSelectAndStart,
}) => {
  const { currentTheme } = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');

  const roles = ['ALL', ...Array.from(new Set(candidates.map((c) => c.member.jobRole)))];

  const filtered = candidates.filter((c) => {
    const matchesSearch =
      c.member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.member.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.member.jobRole.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'ALL' || c.member.jobRole === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div id="candidate-roster-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Header controls */}
      <div
        className="p-5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-md border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div>
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
            style={{ color: currentTheme.colors.neonMagenta }}
          >
            Cohort Database • N=20
          </span>
          <h3
            className="font-display text-[1.4rem] font-bold tracking-tight"
            style={{ color: currentTheme.colors.ink }}
          >
            Candidate Evaluation Roster
          </h3>
        </div>

        {/* Search & Filter */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search
              className="w-3.5 h-3.5 absolute left-3 top-2.5"
              style={{ color: currentTheme.colors.inkFaint }}
            />
            <input
              type="text"
              placeholder="Search name, role, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-lg font-sans text-[0.8rem] outline-none transition-all border"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.ink,
              }}
            />
          </div>

          <div className="relative">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg font-mono text-[0.72rem] font-bold cursor-pointer outline-none transition-all border"
              style={{
                backgroundColor: currentTheme.colors.bgSurface,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.neonCyan,
              }}
            >
              {roles.map((r) => (
                <option
                  key={r}
                  value={r}
                  style={{
                    backgroundColor: currentTheme.colors.bgCard,
                    color: currentTheme.colors.ink,
                  }}
                >
                  {r}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Roster Table / Grid with Virtual Background Watermark */}
      <div
        className="flex-1 rounded-xl overflow-auto backdrop-blur-xl shadow-xl relative border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgSurface,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        {/* Ambient watermark inside roster */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonMagenta }}
          >
            NOVA MIND
          </span>
        </div>

        <div className="min-w-[700px] w-full overflow-x-auto">
          <table className="w-full text-left border-collapse relative z-10">
          <thead>
            <tr
              className="border-b font-mono text-[0.62rem] uppercase tracking-wider font-bold"
              style={{
                backgroundColor: currentTheme.colors.bgCard,
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.inkMuted,
              }}
            >
              <th className="py-3 px-4">Candidate Profile</th>
              <th className="py-3 px-4">Role & Experience</th>
              <th className="py-3 px-4">Curriculum Completed</th>
              <th className="py-3 px-4">Attempt Pattern</th>
              <th className="py-3 px-4">Completion Status</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody
            className="divide-y"
            style={{ borderColor: currentTheme.colors.borderDark }}
          >
            {filtered.map((candidate) => {
              const insight = CandidateService.analyzeCandidate(candidate);
              const isSelected = selectedCandidate?.member.id === candidate.member.id;

              return (
                <tr
                  key={candidate.member.id}
                  className="transition-colors"
                  style={{
                    backgroundColor: isSelected
                      ? `${currentTheme.colors.neonCyan}18`
                      : 'transparent',
                    borderLeft: isSelected
                      ? `3px solid ${currentTheme.colors.neonCyan}`
                      : '3px solid transparent',
                  }}
                >
                  {/* Candidate Name & ID */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg font-mono font-black text-[0.72rem] flex items-center justify-center shrink-0 border shadow-xs"
                        style={{
                          background: `linear-gradient(to top right, ${currentTheme.colors.neonCyan}30, ${currentTheme.colors.neonMagenta}30)`,
                          borderColor: currentTheme.colors.borderDark,
                          color: currentTheme.colors.ink,
                        }}
                      >
                        {candidate.member.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')}
                      </div>
                      <div>
                        <span
                          className="font-display text-[0.95rem] font-bold block leading-tight"
                          style={{ color: currentTheme.colors.ink }}
                        >
                          {candidate.member.name}
                        </span>
                        <span
                          className="font-mono text-[0.62rem] font-bold"
                          style={{ color: currentTheme.colors.neonCyan }}
                        >
                          {candidate.member.id}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Role */}
                  <td className="py-3.5 px-4">
                    <span
                      className="font-semibold text-xs block"
                      style={{ color: currentTheme.colors.ink }}
                    >
                      {candidate.member.jobRole}
                    </span>
                    <span
                      className="font-mono text-[0.62rem]"
                      style={{ color: currentTheme.colors.inkMuted }}
                    >
                      {candidate.member.yearsExperience} yrs experience
                    </span>
                  </td>

                  {/* Completed Days */}
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-1.5">
                      <span
                        className="font-mono font-bold text-xs"
                        style={{ color: currentTheme.colors.neonEmerald }}
                      >
                        {insight.completedDays.length}
                      </span>
                      <span
                        className="font-mono text-[0.65rem]"
                        style={{ color: currentTheme.colors.inkFaint }}
                      >
                        / 31
                      </span>
                      <div className="flex gap-1 ml-2">
                        {insight.completedDays.slice(0, 3).map((d) => (
                          <span
                            key={d}
                            className="font-mono text-[0.58rem] px-1.5 py-0.5 rounded border font-bold"
                            style={{
                              backgroundColor: `${currentTheme.colors.neonPurple}18`,
                              borderColor: `${currentTheme.colors.neonPurple}33`,
                              color: currentTheme.colors.neonPurple,
                            }}
                          >
                            D{d}
                          </span>
                        ))}
                      </div>
                    </div>
                  </td>

                  {/* Struggles */}
                  <td className="py-3.5 px-4">
                    {insight.struggledDays.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {insight.struggledDays.slice(0, 2).map((d) => (
                          <span
                            key={d}
                            className="font-mono text-[0.58rem] px-1.5 py-0.5 rounded border font-bold"
                            style={{
                              backgroundColor: `${currentTheme.colors.neonAmber}18`,
                              borderColor: `${currentTheme.colors.neonAmber}33`,
                              color: currentTheme.colors.neonAmber,
                            }}
                          >
                            Day {d} (Retry)
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span
                        className="font-mono text-[0.62rem] font-bold"
                        style={{ color: currentTheme.colors.neonEmerald }}
                      >
                        First-try passes
                      </span>
                    )}
                  </td>

                  {/* Skipped */}
                  <td className="py-3.5 px-4">
                    {insight.skippedDays.length > 0 ? (
                      <span
                        className="font-mono text-[0.62rem]"
                        style={{ color: currentTheme.colors.inkMuted }}
                      >
                        Skipped {insight.skippedDays.length} days
                      </span>
                    ) : (
                      <span
                        className="font-mono text-[0.62rem] font-bold"
                        style={{ color: currentTheme.colors.neonEmerald }}
                      >
                        100% Completed
                      </span>
                    )}
                  </td>

                  {/* Action */}
                  <td className="py-3.5 px-4 text-right">
                    <button
                      id={`btn-start-${candidate.member.id}`}
                      onClick={() => onSelectAndStart(candidate)}
                      className="font-mono text-[0.68rem] font-bold uppercase tracking-wider px-3.5 py-1.5 rounded-lg border transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
                      style={{
                        background: isSelected
                          ? `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple})`
                          : currentTheme.colors.bgCard,
                        color: isSelected
                          ? currentTheme.mode === 'light'
                            ? '#ffffff'
                            : '#07070a'
                          : currentTheme.colors.ink,
                        borderColor: isSelected
                          ? currentTheme.colors.neonCyan
                          : currentTheme.colors.borderDark,
                        boxShadow: isSelected
                          ? `0 0 12px ${currentTheme.colors.primaryGlow}`
                          : 'none',
                      }}
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>{isSelected ? 'Active' : 'Interview'}</span>
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
};
