import React from 'react';
import { DifficultyLevel } from '../server/types';
import { HelpCircle, BookOpen, Flame, Award } from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';

interface StatsRowProps {
  questionCount: number;
  minimumQuestions: number;
  curriculumDaysCovered: number[];
  minimumDays: number;
  difficulty: DifficultyLevel;
  averageScore: number;
  isComplete: boolean;
}

export const StatsRow: React.FC<StatsRowProps> = ({
  questionCount,
  minimumQuestions,
  curriculumDaysCovered,
  minimumDays,
  difficulty,
  averageScore,
  isComplete,
}) => {
  const { currentTheme } = useTheme();

  const getDifficultyLabel = (diff: DifficultyLevel) => {
    switch (diff) {
      case 'easy':
        return 'EASY';
      case 'hard':
        return 'ADVANCED';
      default:
        return 'STANDARD';
    }
  };

  const currDaysLabel =
    curriculumDaysCovered.length > 0
      ? curriculumDaysCovered.map((d) => `D${d}`).join(' ')
      : 'D7';

  return (
    <div id="stats-row" className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3.5 select-none relative z-10 shrink-0">
      {/* Metric 1: Questions (Primary / Cyan) */}
      <div
        className="rounded-xl p-2.5 sm:p-3.5 flex flex-col justify-between backdrop-blur-md transition-all shadow-sm border"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center justify-between mb-1">
          <span
            className="font-mono text-[0.55rem] sm:text-[0.62rem] uppercase tracking-[0.15em] sm:tracking-[0.2em] font-bold truncate"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            Questions
          </span>
          <HelpCircle
            className="w-3 sm:w-3.5 h-3 sm:h-3.5 opacity-70 shrink-0"
            style={{ color: currentTheme.colors.neonCyan }}
          />
        </div>
        <div className="font-display text-lg sm:text-2xl md:text-[1.75rem] font-black leading-none flex items-baseline gap-1">
          <span style={{ color: currentTheme.colors.neonCyan }}>{questionCount}</span>
          <span
            className="text-xs sm:text-sm font-normal"
            style={{ color: currentTheme.colors.inkFaint }}
          >
            /{minimumQuestions}
          </span>
        </div>
        <div
          className="w-full h-1 sm:h-1.5 rounded-full overflow-hidden mt-2 sm:mt-2.5"
          style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}
        >
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: `${Math.min(100, (questionCount / minimumQuestions) * 100)}%`,
              backgroundColor: currentTheme.colors.neonCyan,
              boxShadow: `0 0 8px ${currentTheme.colors.neonCyan}`,
            }}
          />
        </div>
      </div>

      {/* Metric 2: Curriculum (Neon Magenta/Purple) */}
      <div
        className="rounded-xl p-2.5 sm:p-3.5 flex flex-col justify-between backdrop-blur-md transition-all shadow-sm border"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center justify-between mb-1">
          <span
            className="font-mono text-[0.55rem] sm:text-[0.62rem] uppercase tracking-[0.15em] sm:tracking-[0.2em] font-bold truncate"
            style={{ color: currentTheme.colors.neonMagenta }}
          >
            Curriculum
          </span>
          <BookOpen
            className="w-3 sm:w-3.5 h-3 sm:h-3.5 opacity-70 shrink-0"
            style={{ color: currentTheme.colors.neonMagenta }}
          />
        </div>
        <div
          className="font-display text-base sm:text-xl md:text-[1.5rem] font-bold leading-none truncate"
          style={{ color: currentTheme.colors.neonMagenta }}
          title={currDaysLabel}
        >
          {currDaysLabel}
        </div>
        <div
          className="w-full h-1 sm:h-1.5 rounded-full overflow-hidden mt-2 sm:mt-2.5"
          style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}
        >
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: `${Math.min(100, (curriculumDaysCovered.length / minimumDays) * 100)}%`,
              backgroundColor: currentTheme.colors.neonMagenta,
              boxShadow: `0 0 8px ${currentTheme.colors.neonMagenta}`,
            }}
          />
        </div>
      </div>

      {/* Metric 3: Difficulty (Electric Amber) */}
      <div
        className="rounded-xl p-2.5 sm:p-3.5 flex flex-col justify-between backdrop-blur-md transition-all shadow-sm border"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center justify-between mb-1">
          <span
            className="font-mono text-[0.55rem] sm:text-[0.62rem] uppercase tracking-[0.15em] sm:tracking-[0.2em] font-bold truncate"
            style={{ color: currentTheme.colors.neonAmber }}
          >
            Difficulty
          </span>
          <Flame
            className="w-3 sm:w-3.5 h-3 sm:h-3.5 opacity-70 shrink-0"
            style={{ color: currentTheme.colors.neonAmber }}
          />
        </div>
        <div
          className="font-mono text-base sm:text-lg md:text-[1.3rem] font-black leading-none uppercase tracking-wide truncate"
          style={{ color: currentTheme.colors.neonAmber }}
        >
          {getDifficultyLabel(difficulty)}
        </div>
        <div
          className="w-full h-1 sm:h-1.5 rounded-full overflow-hidden mt-2 sm:mt-2.5"
          style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}
        >
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: difficulty === 'hard' ? '100%' : difficulty === 'medium' ? '65%' : '35%',
              backgroundColor: currentTheme.colors.neonAmber,
              boxShadow: `0 0 8px ${currentTheme.colors.neonAmber}`,
            }}
          />
        </div>
      </div>

      {/* Metric 4: Score/Rating (Vibrant Emerald) */}
      <div
        className="rounded-xl p-2.5 sm:p-3.5 flex flex-col justify-between backdrop-blur-md transition-all shadow-sm border"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div className="flex items-center justify-between mb-1">
          <span
            className="font-mono text-[0.55rem] sm:text-[0.62rem] uppercase tracking-[0.15em] sm:tracking-[0.2em] font-bold truncate"
            style={{ color: currentTheme.colors.neonEmerald }}
          >
            Rating
          </span>
          <Award
            className="w-3 sm:w-3.5 h-3 sm:h-3.5 opacity-70 shrink-0"
            style={{ color: currentTheme.colors.neonEmerald }}
          />
        </div>
        <div
          className="font-display text-base sm:text-xl md:text-[1.5rem] font-bold leading-none truncate"
          style={{ color: currentTheme.colors.neonEmerald }}
        >
          {averageScore > 0 ? (
            <span>
              {averageScore.toFixed(1)}{' '}
              <span style={{ color: currentTheme.colors.inkFaint }} className="text-xs sm:text-sm">
                / 10
              </span>
            </span>
          ) : isComplete ? (
            'COMPLETED'
          ) : (
            'IN PROGRESS'
          )}
        </div>
        <div
          className="w-full h-1 sm:h-1.5 rounded-full overflow-hidden mt-2 sm:mt-2.5"
          style={{ backgroundColor: `${currentTheme.colors.borderDark}99` }}
        >
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: `${Math.min(100, (averageScore / 10) * 100 || 25)}%`,
              backgroundColor: currentTheme.colors.neonEmerald,
              boxShadow: `0 0 8px ${currentTheme.colors.neonEmerald}`,
            }}
          />
        </div>
      </div>
    </div>
  );
};


