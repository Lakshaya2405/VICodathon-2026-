import React from 'react';
import { Activity, Sparkles, BrainCircuit, Terminal, FileText, Download } from 'lucide-react';
import { InterviewSessionState } from '../server/types';
import { useTheme } from '../theme/ThemeContext';

interface SessionInspectorViewProps {
  session: InterviewSessionState | null;
  onOpenCatchAllChats?: () => void;
}

export const SessionInspectorView: React.FC<SessionInspectorViewProps> = ({ session, onOpenCatchAllChats }) => {
  const { currentTheme } = useTheme();

  if (!session) {
    return (
      <div
        className="flex-1 rounded-xl p-12 flex flex-col items-center justify-center text-center select-none backdrop-blur-xl relative border transition-colors shadow-xl"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>
        <Activity
          className="w-10 h-10 mb-3 animate-pulse opacity-70"
          style={{ color: currentTheme.colors.neonCyan }}
        />
        <h3
          className="font-display text-[1.4rem] font-bold"
          style={{ color: currentTheme.colors.ink }}
        >
          No Active Session Found
        </h3>
        <p
          className="font-mono text-[0.75rem] max-w-sm mt-1"
          style={{ color: currentTheme.colors.inkMuted }}
        >
          Start an interview session from the Live Interview or Candidate Roster tab to inspect session state in real-time.
        </p>
      </div>
    );
  }

  return (
    <div id="session-inspector-view" className="flex-1 flex flex-col gap-5 overflow-hidden select-none relative z-10">
      {/* Session Metadata Header */}
      <div
        className="p-5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-xl shadow-md border transition-colors"
        style={{
          backgroundColor: currentTheme.colors.bgCard,
          borderColor: currentTheme.colors.borderDark,
        }}
      >
        <div>
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            Reasoning & Telemetry Trace
          </span>
          <div className="flex items-baseline gap-3">
            <h3
              className="font-display text-[1.4rem] font-bold tracking-tight"
              style={{ color: currentTheme.colors.ink }}
            >
              Session Inspector ({session.sessionId})
            </h3>
            <span
              className="font-mono text-[0.65rem] uppercase tracking-wider px-2 py-0.5 rounded font-bold border shadow-sm"
              style={{
                backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                borderColor: `${currentTheme.colors.neonEmerald}40`,
                color: currentTheme.colors.neonEmerald,
              }}
            >
              {session.status}
            </span>
          </div>
          <p
            className="font-mono text-[0.7rem] mt-0.5"
            style={{ color: currentTheme.colors.inkMuted }}
          >
            Candidate:{' '}
            <span className="font-semibold" style={{ color: currentTheme.colors.ink }}>
              {session.candidate.member.name}
            </span>{' '}
            ({session.candidate.member.jobRole})
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-[0.72rem]">
          {onOpenCatchAllChats && (
            <button
              id="btn-inspector-catch-all-chats"
              onClick={onOpenCatchAllChats}
              className="px-3 py-1 rounded-lg font-bold border flex items-center gap-1.5 transition-all cursor-pointer shadow-xs hover:brightness-110"
              style={{
                borderColor: currentTheme.colors.neonEmerald,
                backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                color: currentTheme.colors.neonEmerald,
              }}
              title="Catch and export all chats and transcripts into a single file"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Catch All Chats (1 File)</span>
            </button>
          )}
          <span
            className="px-3 py-1 rounded-lg font-bold border"
            style={{
              borderColor: `${currentTheme.colors.neonCyan}40`,
              backgroundColor: `${currentTheme.colors.neonCyan}15`,
              color: currentTheme.colors.neonCyan,
            }}
          >
            {session.questionCount} Questions
          </span>
          <span
            className="px-3 py-1 rounded-lg font-bold border"
            style={{
              borderColor: `${currentTheme.colors.neonPurple}40`,
              backgroundColor: `${currentTheme.colors.neonPurple}15`,
              color: currentTheme.colors.neonPurple,
            }}
          >
            {session.curriculumDaysCovered.length} Days Covered
          </span>
        </div>
      </div>

      {/* Two Column Layout: Left (Turns), Right (Evaluations) */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-5 overflow-y-auto lg:overflow-hidden min-h-0 relative">
        {/* Virtual Background Watermark */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
          <span
            className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            NOVA MIND
          </span>
        </div>

        {/* Left: Chronological Turns */}
        <div
          className="rounded-xl p-5 overflow-y-auto space-y-4 backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgSurface,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-2"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            Conversation Turns ({session.conversationHistory.length})
          </span>
          {session.conversationHistory.map((turn, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border shadow-sm transition-colors"
              style={{
                backgroundColor:
                  turn.role === 'interviewer'
                    ? currentTheme.colors.bgCard
                    : `${currentTheme.colors.bgCardHover}bb`,
                borderColor:
                  turn.role === 'interviewer'
                    ? `${currentTheme.colors.neonCyan}44`
                    : currentTheme.colors.borderDark,
              }}
            >
              <div className="flex items-center justify-between mb-2 font-mono text-[0.65rem] uppercase">
                <span
                  className="font-bold px-2 py-0.5 rounded border"
                  style={{
                    backgroundColor:
                      turn.role === 'interviewer'
                        ? `${currentTheme.colors.neonCyan}20`
                        : `${currentTheme.colors.neonMagenta}20`,
                    borderColor:
                      turn.role === 'interviewer'
                        ? `${currentTheme.colors.neonCyan}40`
                        : `${currentTheme.colors.neonMagenta}40`,
                    color:
                      turn.role === 'interviewer'
                        ? currentTheme.colors.neonCyan
                        : currentTheme.colors.neonMagenta,
                  }}
                >
                  [{String(idx + 1).padStart(2, '0')}] {turn.role}
                </span>
                {turn.curriculumDay && (
                  <span
                    className="px-2 py-0.5 rounded border font-mono"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonPurple}15`,
                      borderColor: `${currentTheme.colors.neonPurple}33`,
                      color: currentTheme.colors.neonPurple,
                    }}
                  >
                    Day {turn.curriculumDay}: {turn.topic}
                  </span>
                )}
              </div>
              <p
                className={
                  turn.role === 'interviewer'
                    ? 'font-serif text-[1.02rem] leading-relaxed'
                    : 'font-sans text-[0.88rem] leading-relaxed'
                }
                style={{
                  color:
                    turn.role === 'interviewer'
                      ? currentTheme.colors.ink
                      : currentTheme.colors.inkMuted,
                }}
              >
                {turn.content}
              </p>
            </div>
          ))}
        </div>

        {/* Right: Answer Evaluations */}
        <div
          className="rounded-xl p-5 overflow-y-auto space-y-4 backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgSurface,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <span
            className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-2"
            style={{ color: currentTheme.colors.neonEmerald }}
          >
            Answer Evaluations & Critique Log ({session.answerEvaluations.length})
          </span>
          {session.answerEvaluations.length === 0 ? (
            <div
              className="border border-dashed rounded-xl p-8 text-center font-sans italic text-[0.85rem]"
              style={{
                borderColor: currentTheme.colors.borderDark,
                color: currentTheme.colors.inkFaint,
              }}
            >
              No answer evaluations recorded yet. Respond to questions in Live Interview to generate real-time evaluations.
            </div>
          ) : (
            session.answerEvaluations.map((evalItem, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl space-y-2.5 shadow-md border transition-colors"
                style={{
                  backgroundColor: currentTheme.colors.bgCard,
                  borderColor: currentTheme.colors.borderDark,
                }}
              >
                <div className="flex items-center justify-between font-mono text-[0.72rem]">
                  <span className="font-bold" style={{ color: currentTheme.colors.ink }}>
                    Turn {idx + 1}: Day {evalItem.curriculumDay} ({evalItem.topic})
                  </span>
                  <span
                    className="px-2 py-0.5 rounded font-bold border"
                    style={{
                      backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                      borderColor: `${currentTheme.colors.neonEmerald}40`,
                      color: currentTheme.colors.neonEmerald,
                    }}
                  >
                    Score: {evalItem.score} / 10
                  </span>
                </div>

                <div
                  className="grid grid-cols-3 gap-2 py-1.5 font-mono text-[0.65rem] border-y"
                  style={{
                    borderColor: currentTheme.colors.borderDark,
                    color: currentTheme.colors.inkMuted,
                  }}
                >
                  <div>
                    Correctness:{' '}
                    <strong style={{ color: currentTheme.colors.neonCyan }}>
                      {Math.round(evalItem.correctness * 100)}%
                    </strong>
                  </div>
                  <div>
                    Depth:{' '}
                    <strong style={{ color: currentTheme.colors.neonPurple }}>
                      {Math.round(evalItem.depth * 100)}%
                    </strong>
                  </div>
                  <div>
                    Clarity:{' '}
                    <strong style={{ color: currentTheme.colors.neonEmerald }}>
                      {Math.round(evalItem.clarity * 100)}%
                    </strong>
                  </div>
                </div>

                <p
                  className="font-serif italic text-[0.92rem] leading-relaxed"
                  style={{ color: currentTheme.colors.inkMuted }}
                >
                  "{evalItem.critique}"
                </p>

                {evalItem.missingConcepts && evalItem.missingConcepts.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1 font-mono text-[0.62rem]">
                    <span style={{ color: currentTheme.colors.inkFaint }}>Missing:</span>
                    {evalItem.missingConcepts.map((c, i) => (
                      <span
                        key={i}
                        className="px-1.5 py-0.5 rounded border"
                        style={{
                          backgroundColor: `${currentTheme.colors.neonAmber}18`,
                          borderColor: `${currentTheme.colors.neonAmber}40`,
                          color: currentTheme.colors.neonAmber,
                        }}
                      >
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
