import React from 'react';
import {
  MessageSquareCode,
  Users,
  BookOpen,
  Activity,
  Terminal,
  FileCode,
  Cpu,
  Palette,
  FileText,
  X,
  BarChart3,
  Award,
  Zap,
} from 'lucide-react';
import { CandidateProfile } from '../server/types';
import { useTheme } from '../theme/ThemeContext';

export type NavTab =
  | 'interview'
  | 'qa-focus'
  | 'scores'
  | 'candidates'
  | 'curriculum'
  | 'inspector'
  | 'sandbox'
  | 'spec';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  selectedCandidate: CandidateProfile | null;
  questionCount: number;
  daysCoveredCount: number;
  onOpenBeginnerGuide?: () => void;
  onOpenCatchAllChats?: () => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  selectedCandidate,
  questionCount,
  daysCoveredCount,
  onOpenBeginnerGuide,
  onOpenCatchAllChats,
  isOpenMobile = false,
  onCloseMobile,
}) => {
  const { currentTheme, setIsThemeModalOpen } = useTheme();

  const navItems = [
    {
      id: 'interview' as NavTab,
      label: 'Live Console',
      icon: MessageSquareCode,
      badge: `Q${questionCount || 1}/8`,
      accentColor: currentTheme.colors.neonCyan,
    },
    {
      id: 'qa-focus' as NavTab,
      label: 'Ask & Answer Studio',
      icon: Zap,
      badge: 'SPACIOUS',
      accentColor: currentTheme.colors.neonCyan,
    },
    {
      id: 'scores' as NavTab,
      label: 'Score Display',
      icon: BarChart3,
      badge: 'METRICS',
      accentColor: currentTheme.colors.neonEmerald,
    },
    {
      id: 'candidates' as NavTab,
      label: 'Candidate Roster',
      icon: Users,
      badge: 'N=20',
      accentColor: currentTheme.colors.neonMagenta,
    },
    {
      id: 'curriculum' as NavTab,
      label: 'Curriculum Grounding',
      icon: BookOpen,
      badge: `D${daysCoveredCount || 7}`,
      accentColor: currentTheme.colors.neonPurple,
    },
    {
      id: 'inspector' as NavTab,
      label: 'Reasoning Trace',
      icon: Activity,
      badge: 'LOGS',
      accentColor: currentTheme.colors.neonEmerald,
    },
    {
      id: 'sandbox' as NavTab,
      label: 'API Sandbox & Tests',
      icon: Terminal,
      badge: 'RPC',
      accentColor: currentTheme.colors.neonAmber,
    },
    {
      id: 'spec' as NavTab,
      label: 'Technical Spec',
      icon: FileCode,
      badge: 'SPEC',
      accentColor: currentTheme.colors.neonCyan,
    },
  ];

  const handleNavClick = (tab: NavTab) => {
    setActiveTab(tab);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  const sidebarContent = (
    <div className="h-full flex flex-col justify-between p-4 sm:p-5 select-none overflow-y-auto">
      {/* Brand Header & Navigation */}
      <div className="flex flex-col gap-5 sm:gap-6">
        {/* NOVA MIND Brand Logo with Mobile Close Button */}
        <div className="flex items-center justify-between px-1 pt-1">
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-lg p-[1.5px] shadow-md flex items-center justify-center shrink-0"
              style={{
                background: `linear-gradient(to top right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple}, ${currentTheme.colors.neonMagenta})`,
                boxShadow: `0 0 15px ${currentTheme.colors.primaryGlow}`,
              }}
            >
              <div
                className="w-full h-full rounded-[6px] flex items-center justify-center"
                style={{ backgroundColor: currentTheme.colors.bg }}
              >
                <Cpu className="w-4 h-4" style={{ color: currentTheme.colors.neonCyan }} />
              </div>
            </div>
            <div>
              <div className="font-display text-[1.35rem] sm:text-[1.45rem] font-black tracking-[0.1em] flex items-center gap-1.5 leading-none">
                <span
                  className="bg-clip-text text-transparent font-black"
                  style={{
                    backgroundImage: `linear-gradient(to right, ${currentTheme.colors.neonCyan}, ${currentTheme.colors.neonPurple}, ${currentTheme.colors.neonMagenta})`,
                  }}
                >
                  NOVA MIND
                </span>
              </div>
              <span
                className="font-mono text-[0.55rem] tracking-[0.25em] uppercase font-semibold block mt-1"
                style={{ color: currentTheme.colors.neonCyan }}
              >
                AI Technical Examiner
              </span>
            </div>
          </div>

          {/* Close button on mobile/tablet drawer */}
          <button
            onClick={onCloseMobile}
            className="lg:hidden p-2 rounded-lg border opacity-80 hover:opacity-100 cursor-pointer"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.ink,
            }}
            aria-label="Close Navigation"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation List */}
        <div>
          <span
            className="font-mono text-[0.6rem] uppercase tracking-[0.2em] block mb-2 px-2 font-bold opacity-70"
            style={{ color: currentTheme.colors.inkMuted }}
          >
            Virtual Workspace
          </span>
          <nav className="space-y-1 sm:space-y-1.5">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  id={`nav-btn-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[0.82rem] font-semibold transition-all cursor-pointer text-left border"
                  style={{
                    backgroundColor: isActive
                      ? `${currentTheme.colors.neonCyan}18`
                      : 'transparent',
                    borderColor: isActive
                      ? currentTheme.colors.neonCyan
                      : 'transparent',
                    color: isActive
                      ? currentTheme.colors.ink
                      : currentTheme.colors.inkMuted,
                    boxShadow: isActive
                      ? `0 0 12px ${currentTheme.colors.primaryGlow}`
                      : 'none',
                  }}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className="w-4 h-4 shrink-0 transition-colors"
                      style={{
                        color: isActive
                          ? item.accentColor
                          : currentTheme.colors.inkFaint,
                      }}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>
                  <span
                    className="font-mono text-[0.62rem] font-bold px-1.5 py-0.5 rounded border tracking-tight shrink-0"
                    style={{
                      color: isActive ? item.accentColor : currentTheme.colors.inkFaint,
                      backgroundColor: isActive
                        ? `${item.accentColor}18`
                        : currentTheme.colors.bgCard,
                      borderColor: isActive
                        ? `${item.accentColor}50`
                        : currentTheme.colors.borderDark,
                    }}
                  >
                    {item.badge}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Theme Studio & Candidate Profile Footer */}
      <div
        className="pt-4 border-t px-1 space-y-2.5 sm:space-y-3 mt-4"
        style={{ borderColor: currentTheme.colors.borderDark }}
      >
        {/* Dynamic Theme Launcher in Sidebar */}
        <button
          id="sidebar-btn-theme"
          onClick={() => {
            setIsThemeModalOpen(true);
            if (onCloseMobile) onCloseMobile();
          }}
          className="w-full flex items-center justify-between px-3 py-2 rounded-lg border transition-all cursor-pointer text-[0.75rem] font-mono group shadow-sm"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
            color: currentTheme.colors.ink,
          }}
        >
          <div className="flex items-center gap-2">
            <Palette
              className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform"
              style={{ color: currentTheme.colors.neonMagenta }}
            />
            <span className="font-bold">Theme Studio</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full shadow-sm"
              style={{ backgroundColor: currentTheme.colors.neonCyan }}
            />
            <span
              className="text-[0.65rem] uppercase truncate max-w-[65px]"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              {currentTheme.name.split(' ')[0]}
            </span>
          </div>
        </button>

        {/* Beginner Guide Launcher in Sidebar */}
        {onOpenBeginnerGuide && (
          <button
            id="sidebar-btn-beginner-guide"
            onClick={() => {
              onOpenBeginnerGuide();
              if (onCloseMobile) onCloseMobile();
            }}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg border transition-all cursor-pointer text-[0.75rem] font-mono group shadow-sm"
            style={{
              backgroundColor: `${currentTheme.colors.neonCyan}15`,
              borderColor: `${currentTheme.colors.neonCyan}44`,
              color: currentTheme.colors.neonCyan,
            }}
          >
            <div className="flex items-center gap-2">
              <BookOpen className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonCyan }} />
              <span className="font-bold">Beginner Guide</span>
            </div>
            <span
              className="text-[0.6rem] font-bold px-1.5 py-0.5 rounded border"
              style={{
                backgroundColor: `${currentTheme.colors.neonCyan}20`,
                borderColor: `${currentTheme.colors.neonCyan}40`,
                color: currentTheme.colors.neonCyan,
              }}
            >
              DOCS
            </span>
          </button>
        )}

        {/* Catch All Chats Single-File Exporter in Sidebar */}
        {onOpenCatchAllChats && (
          <button
            id="sidebar-btn-catch-all-chats"
            onClick={() => {
              onOpenCatchAllChats();
              if (onCloseMobile) onCloseMobile();
            }}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg border transition-all cursor-pointer text-[0.75rem] font-mono group shadow-sm hover:brightness-110"
            style={{
              backgroundColor: `${currentTheme.colors.neonEmerald}15`,
              borderColor: `${currentTheme.colors.neonEmerald}44`,
              color: currentTheme.colors.neonEmerald,
            }}
            title="Open Unified Single-File Chat Archive & Exporter"
          >
            <div className="flex items-center gap-2">
              <FileText className="w-3.5 h-3.5" style={{ color: currentTheme.colors.neonEmerald }} />
              <span className="font-bold">Catch All Chats</span>
            </div>
            <span
              className="text-[0.6rem] font-bold px-1.5 py-0.5 rounded border uppercase"
              style={{
                backgroundColor: `${currentTheme.colors.neonEmerald}20`,
                borderColor: `${currentTheme.colors.neonEmerald}40`,
                color: currentTheme.colors.neonEmerald,
              }}
            >
              1 FILE
            </span>
          </button>
        )}

        {/* Candidate Profile Box */}
        <div
          className="rounded-xl p-3 relative overflow-hidden border transition-colors shadow-sm"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span
              className="font-mono text-[0.58rem] uppercase tracking-[0.2em] font-bold"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Active Candidate
            </span>
            <span
              className="w-2 h-2 rounded-full animate-pulse shadow-sm"
              style={{
                backgroundColor: currentTheme.colors.neonEmerald,
                boxShadow: `0 0 8px ${currentTheme.colors.neonEmerald}`,
              }}
            />
          </div>
          <div
            className="text-[0.88rem] font-bold truncate"
            style={{ color: currentTheme.colors.ink }}
          >
            {selectedCandidate ? selectedCandidate.member.name : 'Sarah Johnson'}
          </div>
          <div
            className="font-mono text-[0.65rem] truncate mt-0.5"
            style={{ color: currentTheme.colors.inkMuted }}
          >
            {selectedCandidate ? selectedCandidate.member.jobRole : 'Senior Data Engineer'}
          </div>
          <div
            className="font-mono text-[0.6rem] mt-1 flex items-center justify-between"
            style={{ color: currentTheme.colors.inkFaint }}
          >
            <span>ID: {selectedCandidate ? selectedCandidate.member.id : 'CAN-01'}</span>
            <span
              className="font-semibold"
              style={{ color: currentTheme.colors.neonPurple }}
            >
              Ready
            </span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside
        id="app-sidebar-desktop"
        className="hidden lg:flex w-[250px] flex-col border-r shrink-0 select-none backdrop-blur-xl relative z-20 transition-colors"
        style={{
          backgroundColor: `${currentTheme.colors.bgSurface}f5`,
          borderColor: currentTheme.colors.borderDark,
          color: currentTheme.colors.ink,
        }}
      >
        {sidebarContent}
      </aside>

      {/* Mobile/Tablet Off-Canvas Sliding Drawer Overlay */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex"
          aria-modal="true"
          role="dialog"
        >
          {/* Backdrop Dimmer */}
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />

          {/* Drawer Panel */}
          <aside
            id="app-sidebar-mobile"
            className="relative w-[280px] max-w-[85vw] h-full flex flex-col border-r shadow-2xl z-10 animate-in slide-in-from-left duration-200"
            style={{
              backgroundColor: currentTheme.colors.bgSurface,
              borderColor: currentTheme.colors.borderDark,
              color: currentTheme.colors.ink,
            }}
          >
            {sidebarContent}
          </aside>
        </div>
      )}
    </>
  );
};



