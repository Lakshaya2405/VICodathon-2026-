import React from 'react';
import { Terminal, Code2, ShieldCheck, Sparkles, Cpu } from 'lucide-react';
import { useTheme } from '../theme/ThemeContext';

export const TechSpecView: React.FC = () => {
  const { currentTheme } = useTheme();

  return (
    <div
      id="tech-spec-view"
      className="flex-1 rounded-xl p-8 overflow-y-auto space-y-8 select-none backdrop-blur-xl shadow-xl relative z-10 border transition-colors"
      style={{
        backgroundColor: `${currentTheme.colors.bgSurface}ee`,
        borderColor: currentTheme.colors.borderDark,
      }}
    >
      {/* Virtual Background Watermark */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.03] select-none z-0">
        <span
          className="font-display text-[15vw] font-black tracking-[0.2em] uppercase -rotate-6"
          style={{ color: currentTheme.colors.neonCyan }}
        >
          NOVA MIND
        </span>
      </div>

      {/* Title */}
      <div
        className="border-b pb-5 relative z-10"
        style={{ borderColor: currentTheme.colors.borderDark }}
      >
        <span
          className="font-mono text-[0.62rem] uppercase tracking-[0.2em] font-bold block mb-1"
          style={{ color: currentTheme.colors.neonCyan }}
        >
          Technical Architecture Specification
        </span>
        <h2
          className="font-display text-[1.65rem] font-bold tracking-tight"
          style={{ color: currentTheme.colors.ink }}
        >
          AI Technical Interview Agent Protocol & Grounding Specification
        </h2>
        <p
          className="font-mono text-[0.7rem] mt-1"
          style={{ color: currentTheme.colors.inkMuted }}
        >
          API Contract • State Machine • Dynamic Grounding Engine • Evaluation Trace
        </p>
      </div>

      {/* Core Endpoint */}
      <section className="space-y-4 relative z-10">
        <h3
          className="font-mono text-[0.68rem] uppercase tracking-[0.2em] font-bold"
          style={{ color: currentTheme.colors.neonMagenta }}
        >
          1. API Contract (POST /api/interview)
        </h3>
        <p
          className="font-sans text-[0.95rem] leading-relaxed"
          style={{ color: currentTheme.colors.inkMuted }}
        >
          The interviewer communicates through a single stateful, JSON-RPC compliant endpoint:{' '}
          <code
            className="font-mono text-[0.8rem] px-2 py-0.5 rounded border"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: `${currentTheme.colors.neonCyan}40`,
              color: currentTheme.colors.neonCyan,
            }}
          >
            POST /api/interview
          </code>
          .
        </p>

        {/* Start Request */}
        <div
          className="border rounded-xl p-4 shadow-md transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div
            className="font-mono text-[0.65rem] uppercase font-bold mb-2"
            style={{ color: currentTheme.colors.neonEmerald }}
          >
            // Step 1: Start Interview Request
          </div>
          <pre
            className="font-mono text-[0.75rem] overflow-x-auto leading-relaxed"
            style={{ color: currentTheme.colors.neonCyan }}
          >{`{
  "sessionId": "abc-123",
  "candidate": {
    "member": {
      "id": "CAND-001",
      "name": "Sarah Johnson",
      "jobRole": "Senior Data Engineer",
      "yearsExperience": 6
    },
    "missions": [ ... ]
  }
}`}</pre>
        </div>

        {/* Conversation Turn */}
        <div
          className="border rounded-xl p-4 shadow-md transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div
            className="font-mono text-[0.65rem] uppercase font-bold mb-2"
            style={{ color: currentTheme.colors.neonCyan }}
          >
            // Step 2: Message Turn Request
          </div>
          <pre
            className="font-mono text-[0.75rem] overflow-x-auto leading-relaxed"
            style={{ color: currentTheme.colors.neonPurple }}
          >{`{
  "sessionId": "abc-123",
  "message": "Sentence transformers generate dense embeddings with cosine similarity metric."
}`}</pre>
        </div>

        {/* Response */}
        <div
          className="border rounded-xl p-4 shadow-md transition-colors"
          style={{
            backgroundColor: currentTheme.colors.bgCard,
            borderColor: currentTheme.colors.borderDark,
          }}
        >
          <div
            className="font-mono text-[0.65rem] uppercase font-bold mb-2"
            style={{ color: currentTheme.colors.neonMagenta }}
          >
            // Step 3: End Response with Structured Feedback
          </div>
          <pre
            className="font-mono text-[0.75rem] overflow-x-auto leading-relaxed"
            style={{ color: currentTheme.colors.neonEmerald }}
          >{`{
  "reply": "Interview completed.",
  "done": true,
  "feedback": {
    "summary": "Candidate demonstrated strong understanding of hybrid retrieval...",
    "strengths": ["Clear explanation of vector embeddings", "Solid SQL query router design"],
    "gaps": ["Did not address latency trade-offs in re-ranking"],
    "next": ["Practice load testing containerized FastAPI endpoints"]
  }
}`}</pre>
        </div>
      </section>

      {/* Rules */}
      <section className="space-y-4 relative z-10">
        <h3
          className="font-mono text-[0.68rem] uppercase tracking-[0.2em] font-bold"
          style={{ color: currentTheme.colors.neonAmber }}
        >
          2. Mandatory Interview Engine Guarantees
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className="p-5 rounded-xl border transition-all shadow-md"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <strong
              className="font-display text-[1.1rem] block mb-1"
              style={{ color: currentTheme.colors.neonCyan }}
            >
              Minimum 8 Questions
            </strong>
            <span
              className="font-sans text-[0.82rem] leading-relaxed block"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              The interviewer conducts a comprehensive multi-turn session with at least 8 questions before generating final feedback.
            </span>
          </div>
          <div
            className="p-5 rounded-xl border transition-all shadow-md"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <strong
              className="font-display text-[1.1rem] block mb-1"
              style={{ color: currentTheme.colors.neonMagenta }}
            >
              Minimum 4 Curriculum Days
            </strong>
            <span
              className="font-sans text-[0.82rem] leading-relaxed block"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              Ensures broad technical coverage across vector embeddings, vector databases, hybrid retrieval, RAG, prompt engineering, multi-agent frameworks, MCP, and Kubernetes.
            </span>
          </div>
          <div
            className="p-5 rounded-xl border transition-all shadow-md"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <strong
              className="font-display text-[1.1rem] block mb-1"
              style={{ color: currentTheme.colors.neonEmerald }}
            >
              Curriculum Grounding
            </strong>
            <span
              className="font-sans text-[0.82rem] leading-relaxed block"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              All questions and evaluation criteria are strictly grounded in curriculum.json tools and learning objectives.
            </span>
          </div>
          <div
            className="p-5 rounded-xl border transition-all shadow-md"
            style={{
              backgroundColor: currentTheme.colors.bgCard,
              borderColor: currentTheme.colors.borderDark,
            }}
          >
            <strong
              className="font-display text-[1.1rem] block mb-1"
              style={{ color: currentTheme.colors.neonPurple }}
            >
              Candidate Personalization
            </strong>
            <span
              className="font-sans text-[0.82rem] leading-relaxed block"
              style={{ color: currentTheme.colors.inkMuted }}
            >
              Opening questions, warm-up topics, and follow-ups are dynamically shaped by candidate background and completed missions.
            </span>
          </div>
        </div>
      </section>

      {/* Single-File Chat & Telemetry Exporter Specification */}
      <section className="space-y-4 relative z-10">
        <h3
          className="font-mono text-[0.68rem] uppercase tracking-[0.2em] font-bold"
          style={{ color: currentTheme.colors.neonCyan }}
        >
          3. Single-File Chat & Telemetry Export Endpoints
        </h3>
        <p
          className="font-sans text-[0.95rem] leading-relaxed"
          style={{ color: currentTheme.colors.inkMuted }}
        >
          All candidate interview turns, evaluation traces, curriculum day groundings, and rubric scores are consolidated into single self-contained files via dedicated streaming endpoints:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div
            className="p-4 rounded-xl border"
            style={{ backgroundColor: currentTheme.colors.bgCard, borderColor: currentTheme.colors.borderDark }}
          >
            <span className="font-mono text-[0.65rem] font-bold block mb-1" style={{ color: currentTheme.colors.neonCyan }}>
              GET /api/chats/all
            </span>
            <span className="font-sans text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
              Returns full JSON of all aggregated sessions, conversation turns, and rubric metrics.
            </span>
          </div>

          <div
            className="p-4 rounded-xl border"
            style={{ backgroundColor: currentTheme.colors.bgCard, borderColor: currentTheme.colors.borderDark }}
          >
            <span className="font-mono text-[0.65rem] font-bold block mb-1" style={{ color: currentTheme.colors.neonPurple }}>
              GET /api/chats/single-file
            </span>
            <span className="font-sans text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
              Streams raw single file text or markdown with query param <code>?format=markdown|json|txt</code>.
            </span>
          </div>

          <div
            className="p-4 rounded-xl border"
            style={{ backgroundColor: currentTheme.colors.bgCard, borderColor: currentTheme.colors.borderDark }}
          >
            <span className="font-mono text-[0.65rem] font-bold block mb-1" style={{ color: currentTheme.colors.neonEmerald }}>
              GET /api/chats/export
            </span>
            <span className="font-sans text-[0.78rem]" style={{ color: currentTheme.colors.inkMuted }}>
              Downloads direct attachment with <code>Content-Disposition</code> and timestamped filename.
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
