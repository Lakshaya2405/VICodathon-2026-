import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppTheme } from './themeTypes';
import { THEME_PRESETS } from './themePresets';
import { applyThemeToDOM, generateThemeFromPrompt, loadSavedTheme, saveTheme } from './themeEngine';

interface ThemeContextValue {
  currentTheme: AppTheme;
  presets: AppTheme[];
  setTheme: (theme: AppTheme) => void;
  selectPreset: (presetId: string) => void;
  generateAndApplyTheme: (promptText: string) => AppTheme;
  cycleNextTheme: () => void;
  resetToDefaultTheme: () => void;
  isThemeModalOpen: boolean;
  setIsThemeModalOpen: (open: boolean) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTheme, setCurrentThemeState] = useState<AppTheme>(loadSavedTheme);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);

  // Apply to DOM on mount and whenever theme changes
  useEffect(() => {
    applyThemeToDOM(currentTheme);
    saveTheme(currentTheme);
  }, [currentTheme]);

  const setTheme = (theme: AppTheme) => {
    setCurrentThemeState(theme);
  };

  const selectPreset = (presetId: string) => {
    const found = THEME_PRESETS.find((p) => p.id === presetId);
    if (found) {
      setCurrentThemeState(found);
    }
  };

  const generateAndApplyTheme = (promptText: string): AppTheme => {
    const generated = generateThemeFromPrompt(promptText);
    setCurrentThemeState(generated);
    return generated;
  };

  const cycleNextTheme = () => {
    const currentIndex = THEME_PRESETS.findIndex((p) => p.id === currentTheme.id);
    const nextIndex = (currentIndex + 1) % THEME_PRESETS.length;
    setCurrentThemeState(THEME_PRESETS[nextIndex]);
  };

  const resetToDefaultTheme = () => {
    setCurrentThemeState(THEME_PRESETS[0]);
  };

  return (
    <ThemeContext.Provider
      value={{
        currentTheme,
        presets: THEME_PRESETS,
        setTheme,
        selectPreset,
        generateAndApplyTheme,
        cycleNextTheme,
        resetToDefaultTheme,
        isThemeModalOpen,
        setIsThemeModalOpen,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export function useTheme(): ThemeContextValue {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
