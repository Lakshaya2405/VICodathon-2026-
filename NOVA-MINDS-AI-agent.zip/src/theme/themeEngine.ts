import { AppTheme, BackgroundPattern, ThemeColors } from './themeTypes';
import { THEME_PRESETS } from './themePresets';

const THEME_STORAGE_KEY = 'nova_mind_active_theme_v1';
const CUSTOM_THEMES_KEY = 'nova_mind_custom_themes_v1';

/**
 * Apply the theme colors and styling directly to the document root and CSS custom variables
 */
export function applyThemeToDOM(theme: AppTheme) {
  if (typeof document === 'undefined') return;

  const root = document.documentElement;
  const { colors, mode } = theme;

  // Set dark or light class
  if (mode === 'light') {
    root.classList.remove('dark');
    root.classList.add('light');
  } else {
    root.classList.remove('light');
    root.classList.add('dark');
  }

  // Inject CSS custom properties
  root.style.setProperty('--bg', colors.bg);
  root.style.setProperty('--bg-surface', colors.bgSurface);
  root.style.setProperty('--bg-card', colors.bgCard);
  root.style.setProperty('--bg-card-hover', colors.bgCardHover);
  root.style.setProperty('--border-dark', colors.borderDark);
  root.style.setProperty('--border-bright', colors.borderBright);
  root.style.setProperty('--ink', colors.ink);
  root.style.setProperty('--ink-muted', colors.inkMuted);
  root.style.setProperty('--ink-faint', colors.inkFaint);
  root.style.setProperty('--neon-cyan', colors.neonCyan);
  root.style.setProperty('--neon-magenta', colors.neonMagenta);
  root.style.setProperty('--neon-purple', colors.neonPurple);
  root.style.setProperty('--neon-emerald', colors.neonEmerald);
  root.style.setProperty('--neon-amber', colors.neonAmber);
  root.style.setProperty('--primary-glow', colors.primaryGlow);
  root.style.setProperty('--secondary-glow', colors.secondaryGlow);
  root.style.setProperty('--watermark-opacity', theme.colors.watermarkOpacity.toString());
  root.style.setProperty('--watermark-color', theme.colors.watermarkColor);
}

/**
 * Load initial theme from localStorage or fallback to default
 */
export function loadSavedTheme(): AppTheme {
  if (typeof window === 'undefined') return THEME_PRESETS[0];

  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as AppTheme;
      if (parsed && parsed.colors && parsed.name) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to parse saved theme from localStorage:', e);
  }

  return THEME_PRESETS[0];
}

/**
 * Save theme to localStorage
 */
export function saveTheme(theme: AppTheme) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(theme));
  } catch (e) {
    console.warn('Failed to save theme to localStorage:', e);
  }
}

/**
 * Helper to generate harmonious theme from natural language user request
 */
export function generateThemeFromPrompt(promptText: string): AppTheme {
  const text = promptText.toLowerCase().trim();

  // Determine if user asked for a light mode
  const isLight =
    text.includes('light') ||
    text.includes('day') ||
    text.includes('white') ||
    text.includes('paper') ||
    text.includes('clean bright') ||
    text.includes('parchment') ||
    text.includes('cream');

  // Determine primary palette vibe
  let primary = '#00f0ff';
  let secondary = '#ff007f';
  let tertiary = '#a855f7';
  let quaternary = '#00ff9d';
  let quinary = '#ffbe0b';
  let bg = isLight ? '#f8fafc' : '#07070a';
  let bgSurface = isLight ? '#ffffff' : '#0c0d15';
  let bgCard = isLight ? '#f1f5f9' : '#121422';
  let bgCardHover = isLight ? '#e2e8f0' : '#181b2e';
  let borderDark = isLight ? '#cbd5e1' : '#222538';
  let borderBright = isLight ? '#94a3b8' : '#363b58';
  let pattern: BackgroundPattern = 'cyber-grid';
  let title = 'Dynamic AI Theme';

  // 1. Forest / Emerald / Nature / Moss
  if (text.includes('forest') || text.includes('green') || text.includes('nature') || text.includes('moss') || text.includes('emerald') || text.includes('botanical')) {
    primary = '#10b981';
    secondary = '#059669';
    tertiary = '#34d399';
    quaternary = '#84cc16';
    quinary = '#f59e0b';
    bg = isLight ? '#f0fdf4' : '#040d07';
    bgSurface = isLight ? '#ffffff' : '#08170d';
    bgCard = isLight ? '#dcfce7' : '#0e2415';
    bgCardHover = isLight ? '#bbf7d0' : '#153620';
    borderDark = isLight ? '#86efac' : '#1a4729';
    borderBright = isLight ? '#4ade80' : '#2d6d40';
    pattern = 'hex-mesh';
    title = 'Emerald Moss & Canopy';
  }
  // 2. Sunset / Amber / Gold / Warm / Coffee / Autumn
  else if (text.includes('sunset') || text.includes('gold') || text.includes('amber') || text.includes('warm') || text.includes('coffee') || text.includes('autumn') || text.includes('caramel') || text.includes('fire') || text.includes('lava') || text.includes('magma')) {
    primary = '#f59e0b';
    secondary = '#ef4444';
    tertiary = '#f97316';
    quaternary = '#10b981';
    quinary = '#fbbf24';
    bg = isLight ? '#fffbeb' : '#0e0906';
    bgSurface = isLight ? '#ffffff' : '#18100a';
    bgCard = isLight ? '#fef3c7' : '#22160d';
    bgCardHover = isLight ? '#fde68a' : '#2e1f13';
    borderDark = isLight ? '#fcd34d' : '#3e2617';
    borderBright = isLight ? '#fbbf24' : '#5e3922';
    pattern = 'aurora-waves';
    title = 'Solar Ember & Caramel';
  }
  // 3. Purple / Lavender / Nebula / Deep Space / Galaxy / Violet / Synth
  else if (text.includes('purple') || text.includes('lavender') || text.includes('nebula') || text.includes('galaxy') || text.includes('space') || text.includes('violet') || text.includes('amethyst') || text.includes('cosmic')) {
    primary = '#c084fc';
    secondary = '#f43f5e';
    tertiary = '#a855f7';
    quaternary = '#38bdf8';
    quinary = '#fbbf24';
    bg = isLight ? '#faf5ff' : '#090514';
    bgSurface = isLight ? '#ffffff' : '#110b24';
    bgCard = isLight ? '#f3e8ff' : '#1a1136';
    bgCardHover = isLight ? '#e9d5ff' : '#25194a';
    borderDark = isLight ? '#d8b4fe' : '#352466';
    borderBright = isLight ? '#c084fc' : '#52389d';
    pattern = 'aurora-waves';
    title = 'Deep Cosmic Nebula';
  }
  // 4. Crimson / Blood / Ruby / Cyberpunk Red / Ferrari
  else if (text.includes('red') || text.includes('crimson') || text.includes('ruby') || text.includes('blood') || text.includes('gothic') || text.includes('ferrari') || text.includes('rose') || text.includes('scarlet')) {
    primary = '#ff0055';
    secondary = '#f43f5e';
    tertiary = '#fb7185';
    quaternary = '#00f0ff';
    quinary = '#fbbf24';
    bg = isLight ? '#fff1f2' : '#0d0406';
    bgSurface = isLight ? '#ffffff' : '#17080b';
    bgCard = isLight ? '#ffe4e6' : '#240d12';
    bgCardHover = isLight ? '#fecdd3' : '#33131a';
    borderDark = isLight ? '#fda4af' : '#471a24';
    borderBright = isLight ? '#fb7185' : '#6e2838';
    pattern = 'cyber-grid';
    title = 'Crimson Pulse & Ruby';
  }
  // 5. Ocean / Aquamarine / Cobalt / Deep Sea / Cyan / Ice
  else if (text.includes('ocean') || text.includes('blue') || text.includes('sea') || text.includes('aqua') || text.includes('cobalt') || text.includes('glacier') || text.includes('ice') || text.includes('water')) {
    primary = '#00e5ff';
    secondary = '#0091ea';
    tertiary = '#64b5f6';
    quaternary = '#00e676';
    quinary = '#ffd600';
    bg = isLight ? '#f0f9ff' : '#030a12';
    bgSurface = isLight ? '#ffffff' : '#061424';
    bgCard = isLight ? '#e0f2fe' : '#0b2038';
    bgCardHover = isLight ? '#bae6fd' : '#112c4d';
    borderDark = isLight ? '#7dd3fc' : '#1c416e';
    borderBright = isLight ? '#38bdf8' : '#2a5e9e';
    pattern = 'dot-matrix';
    title = 'Deep Oceanic Trench';
  }
  // 6. Monochrome / High Contrast / Minimal / Carbon / Titanium
  else if (text.includes('mono') || text.includes('minimal') || text.includes('carbon') || text.includes('titanium') || text.includes('contrast') || text.includes('stealth') || text.includes('black and white')) {
    primary = isLight ? '#000000' : '#ffffff';
    secondary = '#00f0ff';
    tertiary = '#a1a1aa';
    quaternary = '#00ff9d';
    quinary = '#f59e0b';
    bg = isLight ? '#ffffff' : '#000000';
    bgSurface = isLight ? '#f4f4f5' : '#09090b';
    bgCard = isLight ? '#e4e4e7' : '#121215';
    bgCardHover = isLight ? '#d4d4d8' : '#1c1c21';
    borderDark = isLight ? '#a1a1aa' : '#27272a';
    borderBright = isLight ? '#71717a' : '#3f3f46';
    pattern = 'minimal-clean';
    title = 'Titanium Stealth Mono';
  }
  // 7. Vaporwave / Pastel / Cyberpop / Neon Tokyo
  else if (text.includes('vapor') || text.includes('pastel') || text.includes('candy') || text.includes('tokyo') || text.includes('sakura') || text.includes('anime')) {
    primary = '#f472b6';
    secondary = '#38bdf8';
    tertiary = '#c084fc';
    quaternary = '#34d399';
    quinary = '#fde047';
    bg = isLight ? '#fdf2f8' : '#0e0814';
    bgSurface = isLight ? '#ffffff' : '#180e22';
    bgCard = isLight ? '#fce7f3' : '#231532';
    bgCardHover = isLight ? '#fbcfe8' : '#301c44';
    borderDark = isLight ? '#f9a8d4' : '#41255c';
    borderBright = isLight ? '#f472b6' : '#603788';
    pattern = 'dot-matrix';
    title = 'Vaporwave Dreamscape';
  }

  const ink = isLight ? '#0f172a' : '#f8fafc';
  const inkMuted = isLight ? '#475569' : '#94a3b8';
  const inkFaint = isLight ? '#64748b' : '#64748b';

  const themeId = `custom-${Date.now().toString(36)}`;
  
  const colors: ThemeColors = {
    bg,
    bgSurface,
    bgCard,
    bgCardHover,
    borderDark,
    borderBright,
    ink,
    inkMuted,
    inkFaint,
    neonCyan: primary,
    neonMagenta: secondary,
    neonPurple: tertiary,
    neonEmerald: quaternary,
    neonAmber: quinary,
    primaryGlow: `${primary}66`,
    secondaryGlow: `${secondary}55`,
    watermarkOpacity: isLight ? 0.03 : 0.04,
    watermarkColor: primary,
  };

  return {
    id: themeId,
    name: title,
    description: `Dynamically synthesized from: "${promptText}"`,
    mode: isLight ? 'light' : 'dark',
    category: 'custom',
    pattern,
    glowIntensity: isLight ? 0.4 : 0.85,
    colors,
    isCustom: true,
    promptSource: promptText,
  };
}
