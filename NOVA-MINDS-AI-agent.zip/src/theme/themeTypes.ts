export type ThemeMode = 'dark' | 'light';

export interface ThemeColors {
  // Backgrounds
  bg: string;
  bgSurface: string;
  bgCard: string;
  bgCardHover: string;
  
  // Borders
  borderDark: string;
  borderBright: string;
  
  // Typography
  ink: string;
  inkMuted: string;
  inkFaint: string;
  
  // 5 Neon Accents
  neonCyan: string;     // Primary electric accent
  neonMagenta: string;  // Secondary electric accent
  neonPurple: string;   // Tertiary electric accent
  neonEmerald: string;  // Quaternary / Success accent
  neonAmber: string;    // Quinary / Warning accent

  // Ambient glows and shadows
  primaryGlow: string;
  secondaryGlow: string;
  watermarkOpacity: number;
  watermarkColor: string;
}

export type BackgroundPattern = 'cyber-grid' | 'dot-matrix' | 'hex-mesh' | 'minimal-clean' | 'aurora-waves';

export interface AppTheme {
  id: string;
  name: string;
  description: string;
  mode: ThemeMode;
  category: 'cyber' | 'retro' | 'minimal' | 'nature' | 'custom';
  pattern: BackgroundPattern;
  glowIntensity: number; // 0 to 1
  colors: ThemeColors;
  isCustom?: boolean;
  promptSource?: string;
}
