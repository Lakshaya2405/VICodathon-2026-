/**
 * Core types for AI Technical Interview Agent
 */

export interface CandidateMember {
  id: string;
  name: string;
  jobRole: string;
  yearsExperience: number;
  education: string;
  status: string;
}

export interface CandidateMission {
  day: number;
  title: string;
  passed?: boolean;
  attempts?: number;
  skipped?: boolean;
}

export interface CandidateSignals {
  commitDays: number;
  missionsCompleted: number;
  missionsFirstTry: number;
}

export interface CandidateProfile {
  member: CandidateMember;
  missions: CandidateMission[];
  signals: CandidateSignals;
}

export interface CurriculumDay {
  day: number;
  title: string;
  type: string;
  tools: string[];
  objectives: string[];
}

export interface CurriculumModule {
  n: number;
  title: string;
  days: [number, number];
}

export interface CurriculumData {
  cohort: string;
  modules: CurriculumModule[];
  days: CurriculumDay[];
}

export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export type QuestionType =
  | 'warmup'
  | 'conceptual'
  | 'explanation'
  | 'debugging'
  | 'scenario'
  | 'design'
  | 'trade-off'
  | 'project-based'
  | 'production';

export interface AnswerEvaluation {
  topic: string;
  curriculumDay: number;
  question: string;
  answer: string;
  correctness: number; // 0.0 to 1.0
  depth: number; // 0.0 to 1.0
  clarity: number; // 0.0 to 1.0
  practicalUnderstanding: number; // 0.0 to 1.0
  confidence: number; // 0.0 to 1.0
  score: number; // 0 to 10
  missingConcepts: string[];
  misconceptions: string[];
  followUpNeeded: boolean;
  suggestedFollowUp?: string;
  recommendedDifficulty: DifficultyLevel;
  critique: string;
}

export interface FinalFeedback {
  summary: string;
  strengths: string[];
  gaps: string[];
  next: string[];
  detailedScores?: {
    overallScore: number;
    technicalScore: number;
    conceptualDepthScore: number;
    problemSolvingScore: number;
    practicalUnderstandingScore: number;
    communicationScore: number;
    engineeringJudgmentScore: number;
  };
  topicsMastered?: string[];
  topicsNeedingReview?: string[];
}

export interface ConversationTurn {
  role: 'interviewer' | 'candidate';
  content: string;
  timestamp: number;
  curriculumDay?: number;
  topic?: string;
  questionType?: QuestionType;
  difficulty?: DifficultyLevel;
  evaluation?: AnswerEvaluation;
}

export interface InterviewSessionState {
  sessionId: string;
  candidate: CandidateProfile;
  status: 'in_progress' | 'completed';
  questionCount: number;
  minimumQuestions: number;
  minimumCurriculumDays: number;
  curriculumDaysCovered: number[];
  topicsCovered: string[];
  currentTopic: string | null;
  currentDay: number | null;
  currentQuestionType: QuestionType;
  difficulty: DifficultyLevel;
  conversationHistory: ConversationTurn[];
  answerEvaluations: AnswerEvaluation[];
  strengths: string[];
  weaknesses: string[];
  followUpCount: number;
  isCurrentFollowUp: boolean;
  currentQuestion: string | null;
  lastCandidateAnswer: string | null;
  feedback: FinalFeedback | null;
  preferredLanguage?: string;
  startTime: number;
  updatedAt: number;
}

export interface StartInterviewRequestBody {
  sessionId: string;
  candidate: CandidateProfile;
  preferredLanguage?: string;
}

export interface TurnInterviewRequestBody {
  sessionId: string;
  message: string;
  preferredLanguage?: string;
}

export type InterviewApiRequestBody = StartInterviewRequestBody | TurnInterviewRequestBody;

export interface InterviewApiResponse {
  reply: string;
  done: boolean;
  sessionId?: string;
  feedback?: FinalFeedback;
  preferredLanguage?: string;
  metadata?: {
    questionCount: number;
    curriculumDaysCovered: number[];
    currentDifficulty: DifficultyLevel;
    currentTopic: string | null;
    currentDay: number | null;
    isFollowUp: boolean;
    preferredLanguage?: string;
    latestEvaluation?: {
      score: number;
      correctness: number;
      depth: number;
      missingConcepts: string[];
      critique: string;
    };
  };
}
