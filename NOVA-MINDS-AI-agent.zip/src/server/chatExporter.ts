import { InterviewSessionState, ConversationTurn } from './types';

export class ChatExporterService {
  /**
   * Generates a single consolidated Markdown file capturing all interview sessions and chats.
   */
  public static generateMarkdown(sessions: InterviewSessionState[]): string {
    const timestamp = new Date().toISOString();
    const totalSessions = sessions.length;
    const totalTurns = sessions.reduce((sum, s) => sum + s.conversationHistory.length, 0);
    const totalEvaluations = sessions.reduce((sum, s) => sum + s.answerEvaluations.length, 0);

    let md = `# NOVA MIND — Complete Technical Interview Conversations & Telemetry Archive\n\n`;
    md += `> **Generated:** ${timestamp}\n`;
    md += `> **Total Candidate Sessions:** ${totalSessions}\n`;
    md += `> **Total Conversation Turns:** ${totalTurns}\n`;
    md += `> **Total Answer Evaluations:** ${totalEvaluations}\n`;
    md += `> **Format:** Unified Single-File Chat Transcript\n\n`;
    md += `---\n\n`;

    md += `## Table of Contents\n\n`;
    sessions.forEach((s, idx) => {
      md += `${idx + 1}. [Session: ${s.candidate.member.name} (${s.candidate.member.id}) — ${s.candidate.member.jobRole}](#session-${s.sessionId})\n`;
    });
    md += `\n---\n\n`;

    sessions.forEach((s, sessionIndex) => {
      const avgScore =
        s.answerEvaluations.length > 0
          ? (s.answerEvaluations.reduce((sum, e) => sum + e.score, 0) / s.answerEvaluations.length).toFixed(1)
          : 'N/A';

      md += `## Session ${sessionIndex + 1}: ${s.candidate.member.name} <a id="session-${s.sessionId}"></a>\n\n`;
      md += `### Candidate Metadata\n`;
      md += `- **Candidate ID:** \`${s.candidate.member.id}\`\n`;
      md += `- **Candidate Name:** ${s.candidate.member.name}\n`;
      md += `- **Job Role & Experience:** ${s.candidate.member.jobRole} (${s.candidate.member.yearsExperience} years experience)\n`;
      md += `- **Session ID:** \`${s.sessionId}\`\n`;
      md += `- **Session Status:** \`${s.status}\`\n`;
      md += `- **Difficulty Trajectory:** \`${s.difficulty}\`\n`;
      md += `- **Questions Asked:** ${s.questionCount} / minimum 8\n`;
      md += `- **Curriculum Days Covered:** ${s.curriculumDaysCovered.map((d) => `Day ${d}`).join(', ') || 'None'}\n`;
      md += `- **Topics Covered:** ${s.topicsCovered.join(', ') || 'None'}\n`;
      md += `- **Average Evaluation Score:** ${avgScore} / 10\n`;
      md += `- **Cohort Signals:** ${s.candidate.signals.missionsCompleted}/31 Missions Completed, ${s.candidate.signals.missionsFirstTry} 1st-try passes, ${s.candidate.signals.commitDays} commit days\n\n`;

      md += `### Complete Conversation Transcript\n\n`;

      if (s.conversationHistory.length === 0) {
        md += `*No conversation turns recorded in this session yet.*\n\n`;
      } else {
        s.conversationHistory.forEach((turn, turnIdx) => {
          const turnNumber = turnIdx + 1;
          const turnTime = new Date(turn.timestamp).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          });

          if (turn.role === 'interviewer') {
            md += `#### Turn ${turnNumber}: 🧠 Interviewer (NOVA MIND Agent) [${turnTime}]\n`;
            if (turn.curriculumDay) {
              md += `> **Grounding:** Day ${turn.curriculumDay} • *${turn.topic || 'Core Concept'}* | **Type:** \`${turn.questionType || 'standard'}\` | **Calibrated Difficulty:** \`${turn.difficulty || s.difficulty}\`\n\n`;
            }
            md += `${turn.content}\n\n`;
          } else {
            md += `#### Turn ${turnNumber}: 👤 Candidate (${s.candidate.member.name}) [${turnTime}]\n\n`;
            md += `\`\`\`text\n${turn.content}\n\`\`\`\n\n`;
          }

          if (turn.evaluation) {
            md += `##### Turn Evaluation & Real-Time Rubric\n`;
            md += `- **Score:** **${turn.evaluation.score} / 10**\n`;
            md += `- **Correctness:** ${Math.round(turn.evaluation.correctness * 100)}%\n`;
            md += `- **Technical Depth:** ${Math.round(turn.evaluation.depth * 100)}%\n`;
            md += `- **Clarity:** ${Math.round(turn.evaluation.clarity * 100)}%\n`;
            md += `- **Practical Understanding:** ${Math.round(turn.evaluation.practicalUnderstanding * 100)}%\n`;
            md += `- **Interviewer Critique:** *"${turn.evaluation.critique}"*\n`;
            if (turn.evaluation.missingConcepts.length > 0) {
              md += `- **Missing Concepts Identified:** ${turn.evaluation.missingConcepts.map((c) => `\`${c}\``).join(', ')}\n`;
            }
            if (turn.evaluation.misconceptions.length > 0) {
              md += `- **Misconceptions Flagged:** ${turn.evaluation.misconceptions.map((m) => `\`${m}\``).join(', ')}\n`;
            }
            md += `\n`;
          }
        });
      }

      if (s.feedback) {
        md += `### Final Synthesis & Evaluation Report\n\n`;
        md += `**Executive Summary:**\n${s.feedback.summary}\n\n`;

        md += `**Demonstrated Strengths:**\n`;
        s.feedback.strengths.forEach((st) => (md += `- ✅ ${st}\n`));
        md += `\n`;

        md += `**Technical Knowledge Gaps & Areas for Improvement:**\n`;
        s.feedback.gaps.forEach((gp) => (md += `- ⚠️ ${gp}\n`));
        md += `\n`;

        md += `**Recommended Next Growth Steps:**\n`;
        s.feedback.next.forEach((nx) => (md += `- 🚀 ${nx}\n`));
        md += `\n`;

        if (s.feedback.detailedScores) {
          md += `**Curriculum Rubric Breakdown:**\n`;
          md += `| Evaluation Dimension | Score (1-10) |\n`;
          md += `| :--- | :--- |\n`;
          md += `| Overall Technical Proficiency | ${s.feedback.detailedScores.overallScore} / 10 |\n`;
          md += `| Domain Technical Depth | ${s.feedback.detailedScores.technicalScore} / 10 |\n`;
          md += `| Conceptual Understanding | ${s.feedback.detailedScores.conceptualDepthScore} / 10 |\n`;
          md += `| Problem Solving & Architecture | ${s.feedback.detailedScores.problemSolvingScore} / 10 |\n`;
          md += `| Practical Implementation Understanding | ${s.feedback.detailedScores.practicalUnderstandingScore} / 10 |\n`;
          md += `| Communication Clarity | ${s.feedback.detailedScores.communicationScore} / 10 |\n`;
          md += `| Engineering Judgment & Trade-offs | ${s.feedback.detailedScores.engineeringJudgmentScore} / 10 |\n\n`;
        }
      }

      md += `---\n\n`;
    });

    md += `*End of NOVA MIND Single-File Unified Interview Archive*\n`;
    return md;
  }

  /**
   * Generates a single consolidated JSON archive of all chats and sessions.
   */
  public static generateJson(sessions: InterviewSessionState[]): string {
    const archive = {
      archiveMetadata: {
        title: 'NOVA MIND All Chats Unified Archive',
        exportedAt: new Date().toISOString(),
        totalSessions: sessions.length,
        totalTurns: sessions.reduce((sum, s) => sum + s.conversationHistory.length, 0),
        totalEvaluations: sessions.reduce((sum, s) => sum + s.answerEvaluations.length, 0),
        version: '3.8',
      },
      sessions: sessions.map((s) => ({
        sessionId: s.sessionId,
        candidate: s.candidate,
        status: s.status,
        questionCount: s.questionCount,
        curriculumDaysCovered: s.curriculumDaysCovered,
        topicsCovered: s.topicsCovered,
        difficulty: s.difficulty,
        startTime: s.startTime,
        updatedAt: s.updatedAt,
        conversationHistory: s.conversationHistory,
        answerEvaluations: s.answerEvaluations,
        feedback: s.feedback,
      })),
    };

    return JSON.stringify(archive, null, 2);
  }

  /**
   * Generates a clean plain-text log format suitable for command-line reading or piping.
   */
  public static generatePlainText(sessions: InterviewSessionState[]): string {
    let txt = `================================================================================\n`;
    txt += `  NOVA MIND — COMPLETE TECHNICAL INTERVIEW TRANSCRIPT LOG\n`;
    txt += `  Exported: ${new Date().toISOString()}\n`;
    txt += `  Total Sessions: ${sessions.length}\n`;
    txt += `================================================================================\n\n`;

    sessions.forEach((s, idx) => {
      txt += `--------------------------------------------------------------------------------\n`;
      txt += `SESSION #${idx + 1}: ${s.candidate.member.name} (${s.candidate.member.id})\n`;
      txt += `Role: ${s.candidate.member.jobRole} (${s.candidate.member.yearsExperience} yrs exp)\n`;
      txt += `Session ID: ${s.sessionId} | Status: ${s.status} | Questions: ${s.questionCount}\n`;
      txt += `--------------------------------------------------------------------------------\n\n`;

      s.conversationHistory.forEach((turn, turnIdx) => {
        const roleStr = turn.role === 'interviewer' ? 'INTERVIEWER [NOVA MIND]' : `CANDIDATE [${s.candidate.member.name}]`;
        const timeStr = new Date(turn.timestamp).toLocaleTimeString();
        txt += `[Turn ${turnIdx + 1}] ${roleStr} (${timeStr})\n`;
        if (turn.curriculumDay) {
          txt += `Grounding: Day ${turn.curriculumDay} (${turn.topic || ''}) | Type: ${turn.questionType || ''} | Diff: ${turn.difficulty || ''}\n`;
        }
        txt += `----------------------------------------------------------------\n`;
        txt += `${turn.content}\n\n`;

        if (turn.evaluation) {
          txt += `>> EVALUATION: Score ${turn.evaluation.score}/10 | Correctness ${Math.round(turn.evaluation.correctness * 100)}% | Depth ${Math.round(turn.evaluation.depth * 100)}%\n`;
          txt += `>> CRITIQUE: "${turn.evaluation.critique}"\n\n`;
        }
      });

      if (s.feedback) {
        txt += `>> FINAL SYNTHESIS:\n`;
        txt += `Summary: ${s.feedback.summary}\n`;
        txt += `Strengths: ${s.feedback.strengths.join('; ')}\n`;
        txt += `Gaps: ${s.feedback.gaps.join('; ')}\n`;
        txt += `Next Steps: ${s.feedback.next.join('; ')}\n\n`;
      }

      txt += `\n`;
    });

    return txt;
  }
}
