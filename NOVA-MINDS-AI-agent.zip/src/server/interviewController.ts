import {
  InterviewApiRequestBody,
  InterviewApiResponse,
  StartInterviewRequestBody,
  TurnInterviewRequestBody,
  ConversationTurn,
  CandidateProfile,
} from './types';
import { interviewStateManager } from './interviewState';
import { InterviewerService } from './interviewer';
import { EvaluatorService } from './evaluator';
import { FeedbackGeneratorService } from './feedbackGenerator';
import { CandidateService } from './candidateService';

export class InterviewController {
  public static async handleInterview(
    body: any
  ): Promise<{ status: number; data: InterviewApiResponse | { error: string } }> {
    if (!body || typeof body !== 'object' || Object.keys(body).length === 0) {
      return {
        status: 400,
        data: { error: 'Invalid request body. Expected non-empty JSON object.' },
      };
    }

    const preferredLanguage =
      typeof body.preferredLanguage === 'string' && body.preferredLanguage.trim()
        ? body.preferredLanguage.trim()
        : typeof body.language === 'string' && body.language.trim()
        ? body.language.trim()
        : typeof body.lang === 'string' && body.lang.trim()
        ? body.lang.trim()
        : undefined;

    // Extract sessionId or auto-generate
    let sessionId: string =
      typeof body.sessionId === 'string' && body.sessionId.trim()
        ? body.sessionId.trim()
        : typeof body.session_id === 'string' && body.session_id.trim()
        ? body.session_id.trim()
        : '';

    // Check if candidate payload or candidate ID was passed
    const candidateInput =
      body.candidate || body.candidateId || body.candidate_id || body.member;

    // Check if message / answer was passed
    const rawMessage =
      body.message !== undefined
        ? body.message
        : body.answer !== undefined
        ? body.answer
        : body.response !== undefined
        ? body.response
        : body.text !== undefined
        ? body.text
        : body.content !== undefined
        ? body.content
        : null;

    // Case 1: Start Interview (candidate provided)
    if (candidateInput) {
      if (!sessionId) {
        const cId =
          typeof candidateInput === 'string'
            ? candidateInput
            : candidateInput.member?.id || 'candidate';
        sessionId = `session_${cId}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      }
      return this.handleStart(sessionId, candidateInput, preferredLanguage);
    }

    // If no candidate is provided, sessionId is strictly required to find an existing session
    if (!sessionId) {
      return {
        status: 400,
        data: { error: 'Missing required field: sessionId (or candidate to start a new interview).' },
      };
    }

    // Case 2: Conversation Turn (message/answer provided)
    if (rawMessage !== null && rawMessage !== undefined) {
      const messageStr = String(rawMessage).trim();
      return this.handleTurn(sessionId, messageStr, preferredLanguage);
    }

    // Case 3: Session exists and candidate wants the current/pending question
    const existingSession = interviewStateManager.getSession(sessionId);
    if (existingSession) {
      if (existingSession.status === 'completed' && existingSession.feedback) {
        return {
          status: 200,
          data: {
            reply: 'Interview completed.',
            done: true,
            sessionId,
            feedback: existingSession.feedback,
            metadata: {
              questionCount: existingSession.questionCount,
              curriculumDaysCovered: existingSession.curriculumDaysCovered,
              currentDifficulty: existingSession.difficulty,
              currentTopic: existingSession.currentTopic,
              currentDay: existingSession.currentDay,
              isFollowUp: false,
            },
          },
        };
      }

      return {
        status: 200,
        data: {
          reply: existingSession.currentQuestion || 'Please continue your technical answer.',
          done: false,
          sessionId,
          metadata: {
            questionCount: existingSession.questionCount,
            curriculumDaysCovered: existingSession.curriculumDaysCovered,
            currentDifficulty: existingSession.difficulty,
            currentTopic: existingSession.currentTopic,
            currentDay: existingSession.currentDay,
            isFollowUp: existingSession.isCurrentFollowUp,
          },
        },
      };
    }

    return {
      status: 400,
      data: {
        error:
          'Invalid request format. Must provide "candidate" to start or "message"/"answer" with "sessionId" to continue.',
      },
    };
  }

  private static async handleStart(
    sessionId: string,
    candidateInput: any,
    preferredLanguage?: string
  ): Promise<{ status: number; data: InterviewApiResponse }> {
    let resolvedCandidate: CandidateProfile | undefined;

    if (typeof candidateInput === 'string') {
      resolvedCandidate = CandidateService.getCandidateById(candidateInput);
      if (!resolvedCandidate) {
        resolvedCandidate = CandidateService.getAllCandidates().find(
          (c) =>
            c.member.id.toLowerCase() === candidateInput.toLowerCase() ||
            c.member.name.toLowerCase().includes(candidateInput.toLowerCase())
        );
      }
    } else if (candidateInput && typeof candidateInput === 'object') {
      if (candidateInput.member && candidateInput.missions) {
        resolvedCandidate = candidateInput as CandidateProfile;
      } else if (candidateInput.id || candidateInput.candidateId) {
        const id = candidateInput.id || candidateInput.candidateId;
        resolvedCandidate = CandidateService.getCandidateById(id);
      }
    }

    // Fallback to first candidate in database if not found
    if (!resolvedCandidate) {
      resolvedCandidate = CandidateService.getAllCandidates()[0];
    }

    // Create session in state manager
    const session = interviewStateManager.createSession(sessionId, resolvedCandidate);
    if (preferredLanguage) {
      session.preferredLanguage = preferredLanguage;
    }

    // Generate personalized opening grounded in candidate's completed days and seniority
    const opening = await InterviewerService.generateOpening(session.candidate, session.preferredLanguage);

    // Update session with question 1
    session.questionCount = 1;
    session.currentDay = opening.day;
    session.currentTopic = opening.topic;
    session.currentQuestion = opening.question;
    session.isCurrentFollowUp = false;
    session.curriculumDaysCovered = [opening.day];
    session.topicsCovered = [opening.topic];

    // Record turn in history
    const interviewerTurn: ConversationTurn = {
      role: 'interviewer',
      content: opening.question,
      timestamp: Date.now(),
      curriculumDay: opening.day,
      topic: opening.topic,
      questionType: 'warmup',
      difficulty: session.difficulty,
    };
    interviewStateManager.addTurn(sessionId, interviewerTurn);

    // Combined opening greeting + technical question
    const replyText = `${opening.greeting} ${opening.question}`;

    const response: InterviewApiResponse = {
      reply: replyText,
      done: false,
      sessionId,
      preferredLanguage: session.preferredLanguage,
      metadata: {
        questionCount: session.questionCount,
        curriculumDaysCovered: session.curriculumDaysCovered,
        currentDifficulty: session.difficulty,
        currentTopic: session.currentTopic,
        currentDay: session.currentDay,
        isFollowUp: false,
        preferredLanguage: session.preferredLanguage,
      },
    };

    return { status: 200, data: response };
  }

  private static async handleTurn(
    sessionId: string,
    candidateMessage: string,
    preferredLanguage?: string
  ): Promise<{ status: number; data: InterviewApiResponse | { error: string } }> {
    const session = interviewStateManager.getSession(sessionId);
    if (!session) {
      return {
        status: 404,
        data: {
          error: `Interview session "${sessionId}" not found. Please start the interview with a candidate payload first.`,
        },
      };
    }

    if (preferredLanguage) {
      session.preferredLanguage = preferredLanguage;
    }

    if (session.status === 'completed' && session.feedback) {
      return {
        status: 200,
        data: {
          reply: 'Interview completed.',
          done: true,
          feedback: session.feedback,
        },
      };
    }

    // Record candidate's answer in history
    const candidateTurn: ConversationTurn = {
      role: 'candidate',
      content: candidateMessage,
      timestamp: Date.now(),
    };
    interviewStateManager.addTurn(sessionId, candidateTurn);
    session.lastCandidateAnswer = candidateMessage;

    // 1. Evaluate candidate answer against current question and topic
    const currentQuestion = session.currentQuestion || 'Tell me about your AI project architecture.';
    const currentDay = session.currentDay || 7;
    const currentTopic = session.currentTopic || 'Embeddings Explained';

    const evaluation = await EvaluatorService.evaluateAnswer(
      session,
      currentQuestion,
      candidateMessage,
      currentDay,
      currentTopic,
      session.difficulty
    );

    interviewStateManager.recordEvaluation(sessionId, evaluation);
    interviewStateManager.markCurriculumDayCovered(sessionId, currentDay, currentTopic);

    // Check completion criteria:
    // Minimum 8 questions asked AND minimum 4 curriculum days covered
    const hasMetMinimumQuestions = session.questionCount >= 8;
    const hasMetCurriculumDays = session.curriculumDaysCovered.length >= 4;

    if (hasMetMinimumQuestions && hasMetCurriculumDays) {
      // Generate final feedback
      const feedback = await FeedbackGeneratorService.generateFinalFeedback(session);
      interviewStateManager.setFeedback(sessionId, feedback);

      const finalResponse: InterviewApiResponse = {
        reply: 'Interview completed.',
        done: true,
        sessionId,
        feedback: {
          summary: feedback.summary,
          strengths: feedback.strengths,
          gaps: feedback.gaps,
          next: feedback.next,
          detailedScores: feedback.detailedScores,
        },
        metadata: {
          questionCount: session.questionCount,
          curriculumDaysCovered: session.curriculumDaysCovered,
          currentDifficulty: session.difficulty,
          currentTopic: session.currentTopic,
          currentDay: session.currentDay,
          isFollowUp: false,
          latestEvaluation: {
            score: evaluation.score,
            correctness: evaluation.correctness,
            depth: evaluation.depth,
            missingConcepts: evaluation.missingConcepts,
            critique: evaluation.critique,
          },
        },
      };

      return { status: 200, data: finalResponse };
    }

    // 2. Generate next question adaptively (follow-up or new curriculum day)
    const nextQ = await InterviewerService.generateNextQuestion(session);

    // Update state for next question
    session.questionCount += 1;
    session.currentDay = nextQ.day;
    session.currentTopic = nextQ.topic;
    session.currentQuestion = nextQ.question;
    session.currentQuestionType = nextQ.questionType;
    session.isCurrentFollowUp = nextQ.isFollowUp;
    session.difficulty = nextQ.difficulty;

    if (!session.curriculumDaysCovered.includes(nextQ.day)) {
      session.curriculumDaysCovered.push(nextQ.day);
    }
    if (!session.topicsCovered.includes(nextQ.topic)) {
      session.topicsCovered.push(nextQ.topic);
    }

    // Record interviewer's new question
    const nextTurn: ConversationTurn = {
      role: 'interviewer',
      content: nextQ.question,
      timestamp: Date.now(),
      curriculumDay: nextQ.day,
      topic: nextQ.topic,
      questionType: nextQ.questionType,
      difficulty: nextQ.difficulty,
      evaluation,
    };
    interviewStateManager.addTurn(sessionId, nextTurn);

    const response: InterviewApiResponse = {
      reply: nextQ.question,
      done: false,
      sessionId,
      metadata: {
        questionCount: session.questionCount,
        curriculumDaysCovered: session.curriculumDaysCovered,
        currentDifficulty: session.difficulty,
        currentTopic: session.currentTopic,
        currentDay: session.currentDay,
        isFollowUp: nextQ.isFollowUp,
        latestEvaluation: {
          score: evaluation.score,
          correctness: evaluation.correctness,
          depth: evaluation.depth,
          missingConcepts: evaluation.missingConcepts,
          critique: evaluation.critique,
        },
      },
    };

    return { status: 200, data: response };
  }
}
