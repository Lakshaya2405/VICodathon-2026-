import { GoogleGenAI } from '@google/genai';

let genAIInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }

  if (!genAIInstance) {
    genAIInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  return genAIInstance;
}

export function getPreferredModel(): string {
  return process.env.GEMINI_MODEL || 'gemini-3.6-flash';
}

const FALLBACK_MODELS = ['gemini-3.6-flash', 'gemini-flash-latest', 'gemini-3.1-flash-lite'];

export async function generateContentWithGemini(
  prompt: string,
  systemInstruction?: string,
  temperature: number = 0.7
): Promise<string | null> {
  const ai = getGeminiClient();
  if (!ai) {
    return null;
  }

  const primaryModel = getPreferredModel();
  const modelsToTry = [primaryModel, ...FALLBACK_MODELS.filter((m) => m !== primaryModel)];

  for (const model of modelsToTry) {
    try {
      const config: any = {
        temperature,
      };
      if (systemInstruction) {
        config.systemInstruction = systemInstruction;
      }

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config,
      });

      const text = response.text;
      if (text && text.trim().length > 0) {
        return text.trim();
      }
    } catch (error: any) {
      const errorMsg = error?.message || String(error);
      const isQuotaOrRateLimit =
        error?.status === 429 ||
        error?.code === 429 ||
        errorMsg.includes('429') ||
        errorMsg.includes('RESOURCE_EXHAUSTED') ||
        errorMsg.includes('Quota exceeded') ||
        errorMsg.includes('rate-limit');

      if (isQuotaOrRateLimit) {
        // Quota exceeded for this specific model - try next fallback model or deterministic fallback
        continue;
      }

      // For other unexpected errors, log concise warning
      console.warn(`[GeminiClient] (${model}) generation note:`, errorMsg.slice(0, 180));
      break;
    }
  }

  // Gracefully return null so deterministic curriculum/evaluator engine takes over seamlessly
  return null;
}

