import {
  CandidateProfile,
  DifficultyLevel,
  InterviewSessionState,
  QuestionType,
  AnswerEvaluation,
} from './types';
import { CurriculumService } from './curriculumService';
import { CandidateService } from './candidateService';
import { generateContentWithGemini } from './geminiClient';

interface GeneratedQuestion {
  question: string;
  day: number;
  topic: string;
  questionType: QuestionType;
  difficulty: DifficultyLevel;
  isFollowUp: boolean;
}

export class InterviewerService {
  /**
   * Generates a deeply personalized welcome greeting and first technical question
   * tailored to the candidate's exact background, seniority, and cohort mission signals.
   */
  public static async generateOpening(
    candidate: CandidateProfile,
    preferredLanguage?: string
  ): Promise<{ greeting: string; question: string; day: number; topic: string }> {
    const insight = CandidateService.analyzeCandidate(candidate);

    // Pick first topic from completed days or key core foundational day
    const startingDayNumber = insight.recommendedOpeningTopics[0] || 7;
    const dayData = CurriculumService.getDay(startingDayNumber) || {
      day: 7,
      title: 'Embeddings Explained',
      tools: ['Sentence Transformers', 'OpenAI Embeddings'],
      objectives: ['Understand how text is converted into vector embeddings'],
      type: 'AI_CORE',
    };

    const candidateRole = candidate.member.jobRole;
    const candidateName = candidate.member.name;
    const yearsExp = candidate.member.yearsExperience;

    // Seniority-aware personalization
    const isSenior = yearsExp >= 5 || candidateRole.toLowerCase().includes('senior') || candidateRole.toLowerCase().includes('principal');

    let openingQuestion = '';
    let greeting = `Welcome, ${candidateName}. We are ready to begin your technical interview.`;

    const lang = (preferredLanguage || 'en').toLowerCase();

    if (lang === 'es') {
      greeting = `Bienvenido(a), ${candidateName}. Estamos listos para comenzar tu evaluación técnica de IA.`;
      if (isSenior) {
        openingQuestion = `Bienvenido ${candidateName}. Con tu experiencia como ${candidateRole} (${yearsExp} años de experiencia), profundicemos directamente en arquitectura técnica. En el Día ${dayData.day} (${dayData.title}), convertiste documentos no estructurados en embeddings vectoriales. ¿Podrías explicar los compromisos de dimensionalidad en tu modelo de embedding (ej. Sentence Transformers vs APIs comerciales), cómo seleccionaste la estrategia de chunking y overlap, y la métrica de distancia elegida para búsqueda por similitud?`;
      } else {
        openingQuestion = `Bienvenido ${candidateName}. Comencemos tu entrevista técnica. Revisando tu progreso en la cohorte como ${candidateRole}, iniciemos con el Día ${dayData.day} (${dayData.title}). ¿Podrías explicarme cómo convertiste texto sin procesar en embeddings vectoriales densos y cómo funciona la búsqueda de similitud semántica internamente?`;
      }
    } else if (lang === 'fr') {
      greeting = `Bienvenue, ${candidateName}. Nous sommes prêts à débuter votre évaluation technique en IA.`;
      if (isSenior) {
        openingQuestion = `Bienvenue ${candidateName}. Avec votre parcours en tant que ${candidateRole} (${yearsExp} ans d'expérience), abordons directement l'architecture technique. Au Jour ${dayData.day} (${dayData.title}), vous avez converti des documents non structurés en plongements vectoriels (embeddings). Pourriez-vous expliquer les compromis de dimensionnalité de votre modèle d'embedding (ex. Sentence Transformers vs API cloud), le choix du découpage (chunking) et du recouvrement, ainsi que la métrique de distance pour la recherche sémantique ?`;
      } else {
        openingQuestion = `Bienvenue ${candidateName}. Débutons votre entretien technique. En observant votre progression dans la cohorte comme ${candidateRole}, commençons par le Jour ${dayData.day} (${dayData.title}). Pourriez-vous m'expliquer comment vous avez converti du texte brut en vecteurs denses et le fonctionnement de la recherche par similarité sémantique ?`;
      }
    } else if (lang === 'de') {
      greeting = `Willkommen, ${candidateName}. Wir sind bereit für Ihr technisches KI-Interview.`;
      if (isSenior) {
        openingQuestion = `Willkommen ${candidateName}. Mit Ihrem Hintergrund als ${candidateRole} (${yearsExp} Jahre Erfahrung) steigen wir direkt in die technische Architektur ein. An Tag ${dayData.day} (${dayData.title}) haben Sie unstrukturierte Dokumente in Vektoreinbettungen (Embeddings) umgewandelt. Können Sie die dimensionalen Trade-offs Ihres Embedding-Modells (z. B. Sentence Transformers vs. Cloud-APIs), Ihre Chunking- & Overlap-Strategie und die gewählte Distanzmetrik für die Vektorsuche erläutern?`;
      } else {
        openingQuestion = `Willkommen ${candidateName}. Beginnen wir Ihr technisches Interview. An Tag ${dayData.day} (${dayData.title}) haben Sie mit Vektoreinbettungen gearbeitet. Können Sie erklären, wie Rohdaten in dichte Vektoren konvertiert werden und wie die semantische Ähnlichkeitssuche intern funktioniert?`;
      }
    } else if (lang === 'hi') {
      greeting = `नमस्ते, ${candidateName}। हम आपके तकनीकी साक्षात्कार के लिए तैयार हैं।`;
      openingQuestion = `नमस्ते ${candidateName}। आपके ${candidateRole} के अनुभव के साथ, आइए तकनीकी आर्किटेक्चर पर चर्चा करें। Day ${dayData.day} (${dayData.title}) पर, आपने टेक्स्ट को वेक्टर एम्बेडिंग्स (Vector Embeddings) में बदला था। क्या आप बता सकते हैं कि आपने चंकिंग (Chunking) और ओवरलैप कैसे चुना, और ChromaDB में समानता खोज (Cosine Similarity Search) कैसे काम करती है?`;
    } else if (lang === 'zh') {
      greeting = `欢迎你，${candidateName}。我们已准备好开始技术面试评估。`;
      openingQuestion = `欢迎 ${candidateName}。作为拥有 ${yearsExp} 年经验的 ${candidateRole}，让我们直接深入系统技术架构。在 Day ${dayData.day} (${dayData.title}) 中，你将非结构化文档转换为稠密向量嵌入 (Vector Embeddings)。能否解释你在嵌入模型维度、分块与重叠 (Chunking & Overlap) 策略以及向量相似度距离度量上的技术权衡？`;
    } else if (lang === 'ja') {
      greeting = `ようこそ、${candidateName}さん。技術面接評価を開始します。`;
      openingQuestion = `ようこそ ${candidateName}さん。${candidateRole}としての経験（${yearsExp}年）を踏まえ、技術アーキテクチャについて伺います。Day ${dayData.day} (${dayData.title}) では、文書をベクトル埋め込み（Vector Embeddings）に変換しました。チャンク分割とオーバーラップの設計、および類似度検索（Cosine Similarity）の選定理由について詳しく教えてください。`;
    } else if (isSenior) {
      openingQuestion = `Welcome ${candidateName}. With your background as a ${candidateRole} (${yearsExp} years of experience), let's dive straight into technical architecture. On Day ${dayData.day} (${dayData.title}), you converted unstructured documents into vector embeddings. Could you explain the dimensional trade-offs of your embedding model (e.g. Sentence Transformers vs commercial APIs), how you chose your chunking & overlap strategy, and the distance metric selected for similarity search?`;
    } else {
      openingQuestion = `Welcome ${candidateName}. Let's begin your technical interview. Looking at your cohort progress as a ${candidateRole}, let's start with Day ${dayData.day} (${dayData.title}). Could you walk me through how you converted raw text into dense vector embeddings and how semantic similarity search works under the hood?`;
    }

    return {
      greeting,
      question: openingQuestion,
      day: dayData.day,
      topic: dayData.title,
    };
  }

  /**
   * Generates the next question adaptively based on candidate progress,
   * previous evaluation, curriculum coverage, and difficulty trajectory.
   */
  public static async generateNextQuestion(
    session: InterviewSessionState
  ): Promise<GeneratedQuestion> {
    const latestEval = session.answerEvaluations[session.answerEvaluations.length - 1];
    const candidateInsight = CandidateService.analyzeCandidate(session.candidate);

    // Track how many questions and days covered so far
    const questionsAsked = session.questionCount;
    const currentDifficulty = this.calibrateDifficulty(session);

    // Check if we should ask an intelligent follow-up
    // Follow up when:
    // 1) Latest answer was partial/had missing concepts or was exceptionally strong and warrants a deeper trade-off probe
    // 2) We haven't done consecutive follow-ups without expanding curriculum days
    // 3) We have sufficient headroom to guarantee 4 distinct curriculum days before reaching 8 questions
    const needsNewCurriculumDay =
      (session.questionCount >= 5 && session.curriculumDaysCovered.length < 3) ||
      (session.questionCount >= 7 && session.curriculumDaysCovered.length < 4);

    const shouldFollowUp =
      !needsNewCurriculumDay &&
      latestEval &&
      !session.isCurrentFollowUp &&
      (latestEval.followUpNeeded || latestEval.score >= 8.2 || latestEval.score <= 4.8);

    if (shouldFollowUp && latestEval) {
      const followUp = await this.generateFollowUpQuestion(
        session,
        latestEval,
        currentDifficulty
      );
      if (followUp) {
        return followUp;
      }
    }

    // Otherwise, plan next curriculum topic to ensure at least 4 distinct days
    const targetDayNumber = this.selectNextCurriculumDay(session, candidateInsight);
    const dayData = CurriculumService.getDay(targetDayNumber)!;

    // Determine question type based on interview phase & performance
    const questionType = this.selectQuestionType(session, questionsAsked, currentDifficulty);

    // Generate question via Gemini or specialized deterministic engine
    const questionText = await this.craftQuestion(
      session,
      dayData.day,
      dayData.title,
      dayData.objectives,
      dayData.tools,
      questionType,
      currentDifficulty
    );

    return {
      question: questionText,
      day: dayData.day,
      topic: dayData.title,
      questionType,
      difficulty: currentDifficulty,
      isFollowUp: false,
    };
  }

  /**
   * Dynamically calibrates difficulty based on candidate rolling performance
   */
  public static calibrateDifficulty(session: InterviewSessionState): DifficultyLevel {
    const evals = session.answerEvaluations;
    if (evals.length === 0) {
      const years = session.candidate.member.yearsExperience;
      return years >= 5 ? 'medium' : 'easy';
    }

    const recentEvals = evals.slice(-2);
    const avgRecentScore = recentEvals.reduce((sum, e) => sum + e.score, 0) / recentEvals.length;

    if (avgRecentScore >= 8.2 && recentEvals.length >= 2) {
      return 'hard';
    }
    if (avgRecentScore <= 4.8 && recentEvals.length >= 2) {
      return 'easy';
    }
    if (avgRecentScore >= 6.5) {
      return 'medium';
    }

    return session.difficulty || 'medium';
  }

  private static selectNextCurriculumDay(
    session: InterviewSessionState,
    candidateInsight: any
  ): number {
    const covered = new Set(session.curriculumDaysCovered);
    const coreDays = [7, 8, 10, 11, 12, 13, 16, 18, 20, 21, 22, 23, 27, 28, 29, 31];

    // 1. Prefer candidate completed days that haven't been covered yet
    for (const day of candidateInsight.completedDays) {
      if (!covered.has(day) && coreDays.includes(day)) {
        return day;
      }
    }

    // 2. Try any candidate completed day
    for (const day of candidateInsight.completedDays) {
      if (!covered.has(day)) {
        return day;
      }
    }

    // 3. Try standard core days
    for (const day of coreDays) {
      if (!covered.has(day)) {
        return day;
      }
    }

    // If all core days covered, select a high-impact synthesis day (Day 22 Multi-agent, Day 23 MCP, Day 31 Capstone)
    const synthesisDays = [22, 23, 28, 31, 10, 12, 16, 18];
    for (const day of synthesisDays) {
      if (day !== session.currentDay) {
        return day;
      }
    }

    return 31;
  }

  private static selectQuestionType(
    session: InterviewSessionState,
    questionCount: number,
    difficulty: DifficultyLevel
  ): QuestionType {
    if (questionCount <= 1) return 'conceptual';
    if (questionCount <= 3) return difficulty === 'hard' ? 'debugging' : 'explanation';
    if (questionCount <= 5) return difficulty === 'hard' ? 'design' : 'scenario';
    if (questionCount <= 7) return 'trade-off';
    return 'production';
  }

  private static async generateFollowUpQuestion(
    session: InterviewSessionState,
    evalResult: AnswerEvaluation,
    difficulty: DifficultyLevel
  ): Promise<GeneratedQuestion | null> {
    const topic = evalResult.topic;
    const day = evalResult.curriculumDay;
    const candidate = session.candidate;
    const candidateName = candidate.member.name;

    // Build context of previous candidate statements
    const prevTurn = session.conversationHistory.filter((t) => t.role === 'candidate').slice(-1)[0];
    const candidateSnippet = prevTurn ? prevTurn.content.slice(0, 180) : '';

    const prompt = `You are a Principal AI Technical Interviewer conducting a realistic technical interview.
Candidate: ${candidateName} (${candidate.member.jobRole}, ${candidate.member.yearsExperience} yrs exp).
Topic: Day ${day} (${topic}).
Candidate's previous statement: "${candidateSnippet}"
Evaluation Score: ${evalResult.score}/10
Detected Missing Concepts: ${JSON.stringify(evalResult.missingConcepts)}
Detected Misconceptions: ${JSON.stringify(evalResult.misconceptions)}
Current Difficulty: ${difficulty}

Generate ONE crisp, natural follow-up question that directly tests:
1. If the candidate was strong (score >= 8): Probe deeper architectural trade-offs, latency budgets, or edge-case failure modes.
2. If the candidate had missing concepts (score 5-7.9): Probe the specific missing mechanism smoothly.
3. If the candidate was weak/incorrect (score < 5): Offer a subtle diagnostic hint and ask for the step-by-step data flow.

Make it sound conversational, professional, and authentic to a top-tier tech interview.
Return ONLY the single question text.`;

    const systemPrompt = 'You are a Principal AI Engineering Interviewer. Be crisp, technical, and realistic.';
    const geminiQuestion = await generateContentWithGemini(prompt, systemPrompt, 0.4);

    let questionText = geminiQuestion;
    if (!questionText) {
      // Deterministic intelligent follow-up logic with conversational transition
      if (evalResult.score >= 8.0) {
        questionText = `That's a solid explanation of ${topic}. Let's take that a step further into production scale: suppose your system experiences 10x query traffic and retrieval latency spikes by 400ms. What specific bottlenecks in tokenization, vector indexing, or database connection pooling would you profile first?`;
      } else if (evalResult.score >= 5.0 && evalResult.missingConcepts.length > 0) {
        questionText = `You covered the core ideas of ${topic}. How specifically did you handle ${evalResult.missingConcepts[0]} in your implementation, and what trade-offs did you encounter?`;
      } else {
        questionText = `Let's clarify the underlying mechanics of ${topic}: could you walk me through the step-by-step data flow from the raw input request to the final model response?`;
      }
    }

    return {
      question: questionText,
      day,
      topic,
      questionType: evalResult.score >= 8 ? 'trade-off' : 'explanation',
      difficulty,
      isFollowUp: true,
    };
  }

  private static async craftQuestion(
    session: InterviewSessionState,
    day: number,
    topic: string,
    objectives: string[],
    tools: string[],
    questionType: QuestionType,
    difficulty: DifficultyLevel
  ): Promise<string> {
    const candidate = session.candidate;
    const candidateName = candidate.member.name;
    const candidateRole = candidate.member.jobRole;
    const yearsExp = candidate.member.yearsExperience;
    const attempts = CandidateService.getMissionAttempts(candidate, day);

    // Provide previous conversation summary for continuity
    const previousTopics = session.topicsCovered.slice(-2).join(', ');

    const preferredLang = session.preferredLanguage || 'en';

    const prompt = `You are a Principal AI Technical Interviewer conducting a realistic technical interview.
Candidate: ${candidateName} (${candidateRole}, ${yearsExp} yrs exp).
Target Curriculum Day: Day ${day} - ${topic}
Day Objectives: ${JSON.stringify(objectives)}
Day Tools: ${JSON.stringify(tools)}
Question Type: ${questionType}
Difficulty: ${difficulty}
Candidate Preferred Language: ${preferredLang}
Candidate Mission Attempts on this Day: ${attempts}
Previous topics discussed: ${previousTopics || 'None'}
Questions asked so far: ${session.questionCount}
Curriculum Days Covered so far: ${session.curriculumDaysCovered.join(', ')}

Generate ONE crisp, realistic technical question that:
1. Directly tests Day ${day} (${topic}) concepts from the curriculum.
2. Incorporates natural transitions referencing earlier discussion when appropriate.
3. Matches the question type (${questionType}) and calibrated difficulty (${difficulty}).
4. Sounds like an experienced Principal/Staff engineer conducting an authentic interview.
5. If Preferred Language is not English (e.g. es, fr, de, hi, zh, ja), formulate the question naturally in that language while preserving key technical terms (e.g. ChromaDB, HNSW, FastAPI, embeddings).
6. Avoids fluff, introductory rambling, or sycophantic praise.

Return ONLY the single question text.`;

    const systemPrompt = `You are an authoritative, fair, and experienced technical interviewer. Language: ${preferredLang}.`;
    const geminiQuestion = await generateContentWithGemini(prompt, systemPrompt, 0.5);

    if (geminiQuestion) {
      return geminiQuestion;
    }

    // Deterministic curated question bank grounded in curriculum.json
    return this.getCuratedQuestion(day, topic, questionType, difficulty, candidateRole);
  }

  public static getCuratedQuestion(
    day: number,
    topic: string,
    type: QuestionType,
    difficulty: DifficultyLevel,
    candidateRole?: string
  ): string {
    const questionBank: Record<number, Record<string, string>> = {
      7: {
        conceptual: 'What are vector embeddings under the hood, and why do dense vector representations outperform traditional sparse BM25 keyword matching for semantic search in healthcare records?',
        explanation: 'Walk me through how you generated sentence transformer embeddings for your knowledge base chunks and how you verified the clustering quality using dimensionality reduction.',
        trade_off: 'What are the architectural trade-offs between local open-source embedding models (like all-MiniLM-L6-v2) versus cloud API embeddings regarding latency, throughput, cost, and data privacy?',
        debugging: 'If two semantically unrelated clinical documents produce an unexpectedly high cosine similarity score (e.g. >0.92), what potential causes in tokenization, pooling layers, or embedding normalizations would you investigate?',
      },
      8: {
        conceptual: 'What role does a vector database play in a RAG pipeline, and how does HNSW (Hierarchical Navigable Small World) indexing differ fundamentally from relational B-tree indexing?',
        explanation: 'In your mission on Day 8, you compared ChromaDB and Pinecone. What differences did you observe between local embedded storage and cloud-managed vector databases?',
        trade_off: 'Why might you choose an embedded database like ChromaDB over a distributed cluster like Milvus or Pinecone for a localized healthcare prototype?',
        debugging: 'If metadata filtering in ChromaDB causes queries to return zero results despite relevant documents existing in the collection, how would you diagnose the query filter syntax and payload indexing?',
      },
      10: {
        conceptual: 'On Day 10, you built a hybrid retrieval engine. How does combining structured SQL queries with semantic vector search improve retrieval precision for healthcare plans and claims?',
        explanation: 'Explain the complete query routing logic you implemented: how does the system decide whether a query needs SQL lookup, vector search, or both?',
        trade_off: 'What deduplication and re-ranking trade-offs did you make when merging results returned from SQLite with those from ChromaDB?',
        design: 'How would you design a retrieval engine that handles 100,000 healthcare policies with both structured claim limits and unstructured medical coverage guidelines?',
      },
      11: {
        conceptual: 'What is Retrieval-Augmented Generation (RAG), and what mechanisms prevent the LLM from hallucinating answers not grounded in retrieved context?',
        explanation: 'Explain your end-to-end RAG pipeline from user query ingestion, document retrieval, prompt augmentation, to LLM generation.',
        trade_off: 'What are the trade-offs between passing many smaller retrieved chunks versus a few large chunks to the LLM context window?',
        debugging: 'Suppose your RAG pipeline returns accurate retrieved chunks, but the generated response contradicts the context. How would you debug your prompt and temperature settings?',
      },
      12: {
        conceptual: 'On Day 12, you studied prompt engineering. What are the key differences between zero-shot, few-shot, and chain-of-thought prompting in production chatbots?',
        explanation: 'How did you structure the system prompt for your healthcare chatbot to enforce compliance, clinical tone, and refusal of out-of-domain medical queries?',
        trade_off: 'What are the latency and token cost implications of adding extensive few-shot examples into every user query prompt?',
        debugging: 'If a user attempts prompt injection to bypass healthcare advice guardrails, what specific system prompt delimiters or validation layers would you apply?',
      },
      13: {
        conceptual: 'How does LLM function calling work under the hood, and how do Pydantic schemas enforce type safety on structured model outputs?',
        explanation: 'Describe a specific tool schema you defined for the healthcare chatbot (e.g. checking claim status or deductible amounts) and how the tool execution loop ran.',
        trade_off: 'When would you use function calling with automatic tool execution versus multi-agent delegation for multi-step tasks?',
        debugging: 'What error handling do you implement when the LLM generates invalid JSON arguments that fail Pydantic model validation?',
      },
      16: {
        conceptual: 'On Day 16, you built the FastAPI backend for the chatbot. How did you structure the session-based conversation state and history endpoints?',
        explanation: 'Explain how your FastAPI `/chat` endpoint coordinates retrieval, function calling, and conversation memory before returning a response.',
        trade_off: 'What are the pros and cons of storing conversation history in SQLite versus an in-memory Redis cache for production concurrency?',
        design: 'Design a stateless FastAPI architecture that can serve thousands of concurrent chat sessions while maintaining persistent conversation context.',
      },
      18: {
        conceptual: 'How do Server-Sent Events (SSE) and StreamingResponse in FastAPI deliver real-time LLM token streams to the client interface?',
        explanation: 'Walk through how your backend handles streaming token generation and how client connection drops or timeouts are handled gracefully.',
        trade_off: 'What are the trade-offs between WebSockets and Server-Sent Events (SSE) for AI chatbot streaming responses?',
        debugging: 'If streaming responses stutter or buffer unexpectedly across reverse proxies like Nginx, what HTTP headers and chunking settings would you configure?',
      },
      20: {
        conceptual: 'Why is context window and token limit management critical for multi-turn conversations, and how does conversation summarization work?',
        explanation: 'How did you implement context window management to ensure older messages are summarized without losing critical user preferences or policy details?',
        trade_off: 'What are the trade-offs between a sliding context window (discarding oldest messages) versus recursive summarization for long medical consultations?',
        design: 'Design a token-aware memory manager that dynamically balances retrieved RAG chunks, chat history, and system instructions within a fixed token budget.',
      },
      21: {
        conceptual: 'What is the ReAct (Reasoning + Acting) paradigm in LangChain agents, and how does the Thought-Action-Observation loop function?',
        explanation: 'How did you convert your standalone healthcare functions into reusable LangChain tools, and how did you verify that the agent selects the right tool?',
        trade_off: 'When does an agentic ReAct loop introduce excessive latency or cost compared to deterministic rule-based routing?',
        debugging: 'If an agent gets trapped in an infinite tool invocation loop, what max iterations or stopping conditions should be configured?',
      },
      22: {
        conceptual: 'On Day 22, you implemented Multi-Agent Orchestration with CrewAI or LangGraph. How does a multi-agent system divide complex workflows among specialized agents?',
        explanation: 'Describe the router agent and specialist agents you designed for the healthcare domain (e.g. billing specialist, claims specialist, triage agent).',
        trade_off: 'What are the communication overhead and state synchronization trade-offs of multi-agent architectures versus a single monolithic agent with many tools?',
        design: 'How would you architect a multi-agent workflow where a coordinator agent supervises both a RAG researcher agent and a compliance validator agent before responding to a patient?',
      },
      23: {
        conceptual: 'What is the Model Context Protocol (MCP), and how does standardizing tools and resources via JSON-RPC benefit LLM application architectures?',
        explanation: 'Walk me through the MCP server you built on Day 23: what tools did you expose, and how did an MCP client like Claude Desktop or Cline interact with it?',
        trade_off: 'What are the architectural advantages of decoupling tool implementations into MCP servers rather than hardcoding them into a specific agent framework?',
        debugging: 'How do you handle schema negotiation errors or connection drops between an MCP host client and your MCP tool server?',
      },
      27: {
        conceptual: 'What are the core security vulnerabilities in LLM applications (prompt injection, data poisoning, PII leakage), and how do input/output guardrails mitigate them?',
        explanation: 'How did you implement guardrail checks and regex sanitization in your healthcare chatbot to prevent unauthorized medical advice or PHI exposure?',
        trade_off: 'What is the latency trade-off of running dual LLM verification guardrails (one model checking safety of another model) on every user turn?',
        debugging: 'If an adversarial jailbreak query bypasses system instructions by encoding instructions in Base64 or roleplay prompts, how do you defend against it?',
      },
      28: {
        conceptual: 'On Day 28, you containerized your chatbot with Docker and deployed to Kubernetes. What key elements are needed in a production container definition for an AI backend?',
        explanation: 'Explain how you configured Kubernetes deployments, services, environment secrets, and liveness/readiness health probes for the FastAPI chatbot.',
        trade_off: 'What are the resource allocation trade-offs (CPU vs memory vs GPU) when scaling containerized LLM inference backends versus API proxy services?',
        debugging: 'If your Kubernetes Pod is crashing with OOMKilled errors during high-volume vector search, how would you diagnose and resolve the issue?',
      },
      29: {
        conceptual: 'What metrics are critical for observing a production AI chatbot (latency, token usage, retrieval precision, error rates), and how do Prometheus and Grafana collect them?',
        explanation: 'How did you implement structured logging throughout your retrieval and LLM pipeline to trace query failures and tool execution metrics?',
        trade_off: 'What are the cost and performance trade-offs of logging full prompt/response payloads versus logging only metadata and hashes?',
        debugging: 'If your Grafana dashboard reveals a sudden 30% drop in retrieval relevance scores, what telemetry would you inspect first to find the root cause?',
      },
      31: {
        conceptual: 'For your Day 31 Capstone Project, you presented a complete enterprise healthcare chatbot. What was the overarching architecture of the system?',
        explanation: 'Explain how your capstone integrated hybrid retrieval, multi-agent orchestration, MCP tools, and containerized deployment into a unified solution.',
        trade_off: 'Looking back at your capstone, what major architectural trade-off or technology choice would you change if you were redesigning it for 100x user scale today?',
        production: 'How would you deploy, secure, and monitor your capstone system to meet HIPAA compliance and 99.9% uptime SLAs in a real healthcare provider environment?',
      },
    };

    const dayGroup = questionBank[day] || questionBank[10];
    const key = type === 'trade-off' ? 'trade_off' : type;
    return (
      dayGroup[key] ||
      dayGroup.explanation ||
      dayGroup.conceptual ||
      `On Day ${day} (${topic}), could you explain how you designed your system and what technical challenges you encountered during implementation?`
    );
  }
}
