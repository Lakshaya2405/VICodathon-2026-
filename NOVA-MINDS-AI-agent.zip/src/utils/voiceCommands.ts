import { SUPPORTED_LANGUAGES, SupportedLanguage, getLanguageById } from '../data/languages';
import { CandidateProfile } from '../server/types';

export type VoiceCommandAction =
  | { type: 'SUBMIT_ANSWER'; text?: string }
  | { type: 'NEXT_QUESTION' }
  | { type: 'REPEAT_QUESTION' }
  | { type: 'EXPLAIN_CONCEPT' }
  | { type: 'SWITCH_CANDIDATE'; candidateId?: string; candidateName?: string }
  | { type: 'SWITCH_LANGUAGE'; language: SupportedLanguage }
  | { type: 'VIEW_FEEDBACK' }
  | { type: 'CATCH_ALL_CHATS' }
  | { type: 'OPEN_SCRATCHPAD' }
  | { type: 'TOGGLE_VOICE' }
  | { type: 'AUTO_SIMULATE' }
  | { type: 'CLEAR_INPUT' }
  | { type: 'SWITCH_THEME'; themeId?: string }
  | { type: 'UNKNOWN_COMMAND'; rawText: string };

export interface RecognizedCommandResult {
  isCommand: boolean;
  action?: VoiceCommandAction;
  matchedCommand?: string;
  confidence: number;
  displayText: string;
}

export function parseVoiceCommand(
  rawTranscript: string,
  currentLanguage: SupportedLanguage,
  candidates: CandidateProfile[] = []
): RecognizedCommandResult {
  const text = rawTranscript.trim();
  const lower = text.toLowerCase();

  // Strip prefixes like "command:", "please", "hey agent", "alexa", "siri", "ok agent"
  const cleaned = lower
    .replace(/^(command[: ]+|please |agent |interviewer |ai |por favor |s'il vous plaît |bitte )+/gi, '')
    .trim();

  // 1. Check Language Switch Commands
  for (const lang of SUPPORTED_LANGUAGES) {
    const langNames = [
      lang.name.toLowerCase(),
      lang.nativeName.toLowerCase(),
      lang.id.toLowerCase(),
    ];
    for (const lName of langNames) {
      if (
        cleaned.includes(`switch language to ${lName}`) ||
        cleaned.includes(`change language to ${lName}`) ||
        cleaned.includes(`cambiar idioma a ${lName}`) ||
        cleaned.includes(`changer langue ${lName}`) ||
        cleaned.includes(`sprache ${lName}`) ||
        cleaned.includes(`bhasha ${lName}`) ||
        cleaned.includes(`speak ${lName}`) ||
        cleaned.includes(`parler ${lName}`) ||
        cleaned.includes(`hablar ${lName}`) ||
        cleaned === `language ${lName}` ||
        cleaned === `idioma ${lName}` ||
        cleaned === lName
      ) {
        return {
          isCommand: true,
          action: { type: 'SWITCH_LANGUAGE', language: lang },
          matchedCommand: `Switch Language → ${lang.nativeName}`,
          confidence: 0.95,
          displayText: `Switching language to ${lang.flag} ${lang.nativeName}`,
        };
      }
    }
  }

  // 2. Check Candidate Switch Commands
  for (const c of candidates) {
    const cName = c.member.name.toLowerCase();
    const firstName = cName.split(' ')[0];
    if (
      cleaned.includes(`switch candidate to ${cName}`) ||
      cleaned.includes(`switch candidate to ${firstName}`) ||
      cleaned.includes(`candidate ${firstName}`) ||
      cleaned.includes(`candidato ${firstName}`) ||
      cleaned.includes(`candidat ${firstName}`) ||
      cleaned.includes(`select ${firstName}`)
    ) {
      return {
        isCommand: true,
        action: { type: 'SWITCH_CANDIDATE', candidateId: c.member.id, candidateName: c.member.name },
        matchedCommand: `Switch Candidate → ${c.member.name}`,
        confidence: 0.92,
        displayText: `Switching candidate to ${c.member.name} (${c.member.jobRole})`,
      };
    }
  }

  // Check general next candidate
  if (
    cleaned.includes('next candidate') ||
    cleaned.includes('siguiente candidato') ||
    cleaned.includes('prochain candidat') ||
    cleaned.includes('nächster kandidat') ||
    cleaned.includes('अगला उम्मीदवार')
  ) {
    return {
      isCommand: true,
      action: { type: 'SWITCH_CANDIDATE' },
      matchedCommand: 'Next Candidate',
      confidence: 0.9,
      displayText: 'Switching to next candidate in roster',
    };
  }

  // 3. Check Commands in Current Language + English Fallback
  const allCmds = {
    ...currentLanguage.commands,
  };

  // Helper matching function
  const matchesAny = (list: string[]): boolean => {
    return list.some((cmd) => cleaned === cmd.toLowerCase() || cleaned.startsWith(`${cmd.toLowerCase()} `) || cleaned.endsWith(` ${cmd.toLowerCase()}`));
  };

  // SUBMIT ANSWER
  if (matchesAny(allCmds.submit) || cleaned === 'submit' || cleaned === 'send' || cleaned === 'enviar' || cleaned === 'soumettre' || cleaned === 'bhejo') {
    return {
      isCommand: true,
      action: { type: 'SUBMIT_ANSWER' },
      matchedCommand: 'Submit Answer',
      confidence: 0.95,
      displayText: 'Submitting candidate response to AI evaluation engine...',
    };
  }

  // NEXT QUESTION / SKIP
  if (matchesAny(allCmds.nextQuestion) || cleaned === 'next' || cleaned === 'skip' || cleaned === 'siguiente' || cleaned === 'suivant') {
    return {
      isCommand: true,
      action: { type: 'NEXT_QUESTION' },
      matchedCommand: 'Next Question',
      confidence: 0.9,
      displayText: 'Advancing to next curriculum milestone question...',
    };
  }

  // REPEAT QUESTION
  if (matchesAny(allCmds.repeatQuestion) || cleaned.includes('repeat') || cleaned.includes('repetir') || cleaned.includes('répéter')) {
    return {
      isCommand: true,
      action: { type: 'REPEAT_QUESTION' },
      matchedCommand: 'Repeat Question',
      confidence: 0.92,
      displayText: 'Reading technical question aloud again...',
    };
  }

  // EXPLAIN CONCEPT / CLARIFY
  if (matchesAny(allCmds.explainConcept) || cleaned.includes('explain') || cleaned.includes('clarify') || cleaned.includes('hint') || cleaned.includes('explicar')) {
    return {
      isCommand: true,
      action: { type: 'EXPLAIN_CONCEPT' },
      matchedCommand: 'Explain Concept / Hint',
      confidence: 0.9,
      displayText: 'Requesting conceptual clarification & rubric hint...',
    };
  }

  // VIEW FEEDBACK / REPORT
  if (matchesAny(allCmds.viewFeedback) || cleaned.includes('feedback') || cleaned.includes('report') || cleaned.includes('reporte') || cleaned.includes('rapport')) {
    return {
      isCommand: true,
      action: { type: 'VIEW_FEEDBACK' },
      matchedCommand: 'View Evaluation Report',
      confidence: 0.95,
      displayText: 'Opening comprehensive candidate evaluation report...',
    };
  }

  // CATCH ALL CHATS
  if (matchesAny(allCmds.catchAllChats) || cleaned.includes('export chats') || cleaned.includes('catch all') || cleaned.includes('transcripts')) {
    return {
      isCommand: true,
      action: { type: 'CATCH_ALL_CHATS' },
      matchedCommand: 'Catch All Chats (1-File)',
      confidence: 0.95,
      displayText: 'Opening single-file unified chat transcript exporter...',
    };
  }

  // OPEN / CLOSE SCRATCHPAD
  if (matchesAny(allCmds.openScratchpad) || cleaned.includes('scratchpad') || cleaned.includes('code editor') || cleaned.includes('bloc de notas')) {
    return {
      isCommand: true,
      action: { type: 'OPEN_SCRATCHPAD' },
      matchedCommand: 'Toggle Technical Scratchpad',
      confidence: 0.9,
      displayText: 'Toggling code scratchpad canvas...',
    };
  }

  // TOGGLE VOICE / MUTE
  if (matchesAny(allCmds.toggleVoice) || cleaned.includes('mute') || cleaned.includes('unmute') || cleaned.includes('toggle voice') || cleaned.includes('silenciar')) {
    return {
      isCommand: true,
      action: { type: 'TOGGLE_VOICE' },
      matchedCommand: 'Toggle Voice Readout',
      confidence: 0.95,
      displayText: 'Toggling speech synthesis voice readout...',
    };
  }

  // AUTO SIMULATE
  if (matchesAny(allCmds.autoSimulate) || cleaned.includes('simulate') || cleaned.includes('auto simulate') || cleaned.includes('simular')) {
    return {
      isCommand: true,
      action: { type: 'AUTO_SIMULATE' },
      matchedCommand: 'Run Full Simulation',
      confidence: 0.92,
      displayText: 'Launching automated 8-turn interview simulation...',
    };
  }

  // CLEAR INPUT
  if (matchesAny(allCmds.clearInput) || cleaned.includes('clear answer') || cleaned.includes('borrar respuesta') || cleaned.includes('effacer')) {
    return {
      isCommand: true,
      action: { type: 'CLEAR_INPUT' },
      matchedCommand: 'Clear Input Draft',
      confidence: 0.95,
      displayText: 'Clearing answer input draft...',
    };
  }

  // SWITCH THEME
  if (matchesAny(allCmds.switchTheme) || cleaned.includes('theme') || cleaned.includes('tema') || cleaned.includes('thème')) {
    return {
      isCommand: true,
      action: { type: 'SWITCH_THEME' },
      matchedCommand: 'Cycle Theme Preset',
      confidence: 0.88,
      displayText: 'Cycling to next visual theme preset...',
    };
  }

  // If none matched, it is spoken content/technical answer text!
  return {
    isCommand: false,
    confidence: 1.0,
    displayText: rawTranscript,
  };
}
