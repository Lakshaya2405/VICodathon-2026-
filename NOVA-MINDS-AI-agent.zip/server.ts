import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { InterviewController } from './src/server/interviewController';
import { CandidateService } from './src/server/candidateService';
import { CurriculumService } from './src/server/curriculumService';
import { interviewStateManager } from './src/server/interviewState';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Official Technical Spec Endpoint: POST /api/interview
app.post('/api/interview', async (req, res) => {
  try {
    const result = await InterviewController.handleInterview(req.body);
    res.status(result.status).json(result.data);
  } catch (error: any) {
    console.error('Error handling /api/interview:', error);
    res.status(500).json({ error: error?.message || 'Internal Server Error' });
  }
});

// Helper endpoints for frontend explorer
app.get('/api/candidates', (req, res) => {
  res.json(CandidateService.getAllCandidates());
});

app.get('/api/curriculum', (req, res) => {
  res.json(CurriculumService.getCurriculum());
});

app.get('/api/sessions', (req, res) => {
  res.json(interviewStateManager.getAllSessions());
});

// Catch all chats unified endpoints
app.get('/api/chats/all', (req, res) => {
  const sessions = interviewStateManager.getAllSessions();
  res.json({
    title: 'NOVA MIND All Chats Unified Archive',
    totalSessions: sessions.length,
    totalTurns: interviewStateManager.getAllTurnCount(),
    sessions,
  });
});

app.get('/api/chats/single-file', (req, res) => {
  const format = (req.query.format as string) || 'markdown';
  if (format === 'json') {
    res.type('application/json').send(interviewStateManager.getUnifiedJson());
  } else if (format === 'txt') {
    res.type('text/plain').send(interviewStateManager.getUnifiedPlainText());
  } else {
    res.type('text/markdown').send(interviewStateManager.getUnifiedMarkdown());
  }
});

app.get('/api/chats/export', (req, res) => {
  const format = (req.query.format as string) || 'markdown';
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');

  if (format === 'json') {
    res.setHeader('Content-Disposition', `attachment; filename="all-interview-chats-${timestamp}.json"`);
    res.type('application/json').send(interviewStateManager.getUnifiedJson());
  } else if (format === 'txt') {
    res.setHeader('Content-Disposition', `attachment; filename="all-interview-chats-${timestamp}.txt"`);
    res.type('text/plain').send(interviewStateManager.getUnifiedPlainText());
  } else {
    res.setHeader('Content-Disposition', `attachment; filename="all-interview-chats-${timestamp}.md"`);
    res.type('text/markdown').send(interviewStateManager.getUnifiedMarkdown());
  }
});

app.get('/api/session/:sessionId', (req, res) => {
  const session = interviewStateManager.getSession(req.params.sessionId);
  if (!session) {
    return res.status(404).json({ error: 'Session not found' });
  }
  res.json(session);
});

// Serve static frontend files in production
const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found' });
  }
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[AI Technical Interview Agent] Server listening on http://0.0.0.0:${PORT}`);
});
